# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Octane Converter Advanced",
    "author" : "Adam Zorian Radziszewski ", 
    "description" : "",
    "blender" : (4, 0, 0),
    "version" : (0, 0, 1),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "www.azrtsudio.nl", 
    "category" : "Material" 
}


import bpy
import bpy.utils.previews
from bpy.props import StringProperty
import math


addon_keymaps = {}
_icons = None
class SNA_PT_OCTANE_MATERIAL_CONVERTER_AE697(bpy.types.Panel):
    bl_label = 'Octane Material Converter'
    bl_idname = 'SNA_PT_OCTANE_MATERIAL_CONVERTER_AE697'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Material Converter'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.convert_7ac2f', text='Convert To Octane Materials ', icon_value=15, emboss=True, depress=False)


class SNA_OT_Convert_7Ac2F(bpy.types.Operator):
    bl_idname = "sna.convert_7ac2f"
    bl_label = "Convert"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Original_file_path = bpy.data.filepath
        #current_directory = os.path.dirname(current_file_name)
        bpy.ops.wm.save_as_mainfile(filepath=Original_file_path)
        # Set the View Transform to Raw
        bpy.context.scene.view_settings.view_transform = 'Raw'
        bpy.context.scene.view_settings.look = 'None'
        # Set the render engine to Octane
        bpy.data.scenes["Scene"].render.engine = "octane"
        #addon_dir = os.path.dirname(__file__)
        #shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        #if not bpy.data.node_groups.get("[OCTANE_HELPER_NODE_GROUP]"):
            #bpy.ops.wm.append(filename="[OCTANE_HELPER_NODE_GROUP]", directory=shaders_path)
        # Get a list of all collections in the Blender file
        collections = bpy.data.collections

        def label_nodes_from_base_color():
            # Iteruj przez wszystkie materiały
            for material in bpy.data.materials:
                # Pomiń materiał "Dots Stroke"
                if material.name == "Dots Stroke":
                    continue
                if not material.use_nodes:
                    print(f"Material '{material.name}' does not use nodes.")
                    continue
                # Pobierz drzewo węzłów
                node_tree = material.node_tree
                # Znajdź węzeł Principled BSDF
                principled_bsdf = None
                for node in node_tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        principled_bsdf = node
                        break
                if not principled_bsdf:
                    print(f"No Principled BSDF node found in the material '{material.name}'.")
                    continue
                # Definicje prefiksów
                input_prefix_map = {
                    "Base Color": "Diffuse",
                    "Specular IOR Level": "Specular"
                }
                # Iteracja przez wszystkie wejścia do Principled BSDF
                for input_name, input in principled_bsdf.inputs.items():
                    if input.is_linked:
                        link = input.links[0]
                        label_prefix = input_prefix_map.get(input_name, input_name)
                        set_labels_recursive(link.from_node, label_prefix)

        def set_labels_recursive(node, label_prefix):
            # Specjalne traktowanie dla ShaderNodeMix
            if node.bl_idname == 'ShaderNodeMix':
                node.label = f"{label_prefix} {node.bl_idname}"
                for i, input_name in enumerate(['A', 'B']):
                    if node.inputs[6 + i].is_linked:
                        link = node.inputs[6 + i].links[0]
                        new_label_prefix = f"{label_prefix} {input_name}"
                        set_labels_recursive(link.from_node, new_label_prefix)
                return
            # Ustaw etykietę
            node.label = f"{label_prefix} {node.bl_idname}"
            print(f"Setting label for {node.bl_idname}: {node.label}")
            # Przechodź przez podłączone węzły
            for input in node.inputs:
                if input.is_linked:
                    link = input.links[0]
                    set_labels_recursive(link.from_node, label_prefix)
        # Użyj funkcji na wszystkich materiałach oprócz "Dots Stroke"
        label_nodes_from_base_color()
        # Iterate over the collections
        for collection in collections:
            # Replace "Cycles" with "Octane" in the collection name
            collection.name = collection.name.replace("Cycles", "Octane")
        # Get all materials in the scene
        #materials = bpy.data.materials
        materials = [mat for mat in bpy.data.materials if mat.name != "Dots Stroke"]
        # Iterate over all materials
        for mat in materials:
            # Get the material's node tree
            nodes = mat.node_tree
            if nodes is not None:
                # Iterate over all nodes in the node tree
                for node in nodes.nodes:
                    # Check if the node is a Principled BSDF node
                    if node.type == "BSDF_PRINCIPLED":
                        # Check if the base color input is not connected
                        if not node.inputs["Base Color"].is_linked:
                            # Create a new Octane RGB Color node
                            octane_rgb_color_node = nodes.nodes.new("OctaneRGBColor")
                            # Set the color of the Octane RGB Color node to the same color as the base color of the Principled BSDF node
                            octane_rgb_color_node.a_value = node.inputs["Base Color"].default_value[:3]
                            # Set the label of the Octane RGB Color node to "Base Color"
                            octane_rgb_color_node.label = "Diffuse Color"
                            # Set the location of the Octane RGB Color node to be 1650 units to the right of the original location of the Principled BSDF node
                            octane_rgb_color_node.location = (node.location[0] + 1650, node.location[1])
        # Iterate over all materials
        for mat in materials:
            # Get the material's node tree
            nodes = mat.node_tree
            if nodes is not None:
                # Iterate over all nodes in the node tree
                for node in nodes.nodes:
                    # Check if the node is a Cycles Image Texture node
                     if node.type == 'TEX_IMAGE' and node.image is not None:
                        # Check if an Octane Image Texture node with the same image already exists
                        existing_node = None
                        for n in nodes.nodes:
                            if n.type == 'OctaneRGBImage' and n.image == node.image:
                                existing_node = n
                                break
                        if existing_node:
                            # If the node already exists, skip to the next one
                            print(f"Octane Image Texture node for image '{node.image.name}' already exists.")
                            continue
                        # Create a new Octane Image Texture node
                        octane_image_texture_node = nodes.nodes.new("OctaneRGBImage")
                        # Copy the image, colorspace, and projection settings from the Cycles node
                        octane_image_texture_node.image = node.image
                        # Set the location of the Octane texture node to be 1650 units to the right of the original location of the Cycles texture node
                        octane_image_texture_node.location = (node.location[0] +1650, node.location[1])
                        # Define a list of keywords to check for
                        keywords = ["normal", "gloss", "reflec", "rough", "opacity", "height"]
                        # Check if any keyword is in the image name (case-insensitive)
                        if node.image.name and any(keyword in node.image.name.lower() for keyword in keywords):
                            octane_image_texture_node.inputs[2].default_value = 1.0
                        else:
                            octane_image_texture_node.inputs[2].default_value = 2.2
                        if "gloss" in node.image.name:
                            octane_image_texture_node.inputs[3].default_value = True
                        # Pobierz oryginalną etykietę z val_to_rgb
                        original_label = node.label
                        # Zamień ostatnią część etykiety (bl_idname) na 'Octane'
                        if original_label:
                            parts = original_label.split(' ')
                            if parts:
                                # Zakładamy, że ostatni element to bl_idname
                                parts[-1] = 'Texture Octane'
                                new_label = ' '.join(parts)
                                octane_image_texture_node.label = new_label
        for mat in materials:
            # Get the material's node tree
            nodes = mat.node_tree
            if nodes is not None:
                # Iterate over all nodes in the node tree
                for node in nodes.nodes:
                    if node.bl_idname == "ShaderNodeHueSaturation":
                        Octane_color_correction = nodes.nodes.new("OctaneColorCorrection")
                        Octane_color_correction.location = (node.location[0] +1650, node.location[1])
                        Octane_color_correction.inputs[1].default_value = node.inputs[2].default_value
                        Octane_color_correction.inputs[3].default_value = node.inputs[0].default_value + 0.5
                        Octane_color_correction.inputs[4].default_value = (node.inputs[1].default_value * 100)  + 100
                        Octane_color_correction.inputs[9].default_value = node.inputs[3].default_value
                        # Pobierz oryginalną etykietę z val_to_rgb
                        original_label = node.label
                        # Zamień ostatnią część etykiety (bl_idname) na 'Octane'
                        if original_label:
                            parts = original_label.split(' ')
                            if parts:
                                # Zakładamy, że ostatni element to bl_idname
                                parts[-1] = ' Collor Correction Octane'
                                new_label = ' '.join(parts)
                                Octane_color_correction.label = new_label
                    elif node.bl_idname == "ShaderNodeMix":
                        Octane_mix = nodes.nodes.new("OctaneMixTexture")
                        Octane_mix.location = (node.location[0] +1650, node.location[1])
                        # Zamień ostatnią część etykiety (bl_idname) na 'Octane'
                        original_label = node.label
                        if original_label:
                            parts = original_label.split(' ')
                            if parts:
                                # Zakładamy, że ostatni element to bl_idname
                                parts[-1] = 'Mix Octane'
                                new_label = ' '.join(parts)
                                Octane_mix.label = new_label
        #Przeniesienie COlorramp
        node_gradient = "OctaneGradientMap"
        # Iterate over all materials
        for mat in bpy.data.materials:
            # Get the material's node tree
            Colorramp = mat.node_tree
            if Colorramp:
                # Get all ShaderNodeValToRGB nodes in the material's node tree
                val_to_rgb_nodes = [node for node in Colorramp.nodes if node.bl_idname.startswith("ShaderNodeValToRGB")]
                # Iterate over all ShaderNodeValToRGB nodes
                for val_to_rgb in val_to_rgb_nodes:
                    node_c = val_to_rgb.color_ramp
                    color_ramp_Cycles_Location = val_to_rgb.location
                    num_elements = len(node_c.elements)
                    # Create a new Octane Gradient Map node if one doesn't exist
                    octane_image_texture_node = None  
                    for node_oG in Colorramp.nodes:
                        if node_gradient in node_oG.bl_idname and node_oG.name.startswith("Gradient Tex" + val_to_rgb.name.split(".")[-1]):
                            octane_image_texture_node = node_oG
                            break
                    if not octane_image_texture_node:
                        octane_image_texture_node = Colorramp.nodes.new(node_gradient)
                        octane_image_texture_node.name = "Gradient Tex" + val_to_rgb.name.split(".")[-1]
                        octane_image_texture_node.location = (val_to_rgb.location[0] + 1650, val_to_rgb.location[1]) 
                        # Pobierz oryginalną etykietę z val_to_rgb
                        original_label = val_to_rgb.label
                        # Zamień ostatnią część etykiety (bl_idname) na 'Octane'
                        if original_label:
                            parts = original_label.split(' ')
                            if parts:
                                # Zakładamy, że ostatni element to bl_idname
                                parts[-1] = 'Gradient Octane'
                                new_label = ' '.join(parts)
                                octane_image_texture_node.label = new_label
                        # Sprawdzenie
                        print(octane_image_texture_node.label)
                        octane_helper = bpy.data.node_groups.get(".[OCTANE_HELPER_NODE_GROUP]")
                        #if octane_helper:
                           # node_gradient = "OctaneGradientMap"
                        octane_elements = True
                        if node_gradient == "OctaneGradientMap":
                            octane_name = octane_image_texture_node.color_ramp_name
                            ramp_items = octane_helper.nodes[octane_name].color_ramp.elements
                            for i in range(num_elements):
                                elements = node_c.elements[i]
                                if i >= len(ramp_items):
                                    ramp_items.new(elements.position)
                                ramp_items[i].position = elements.position
                                ramp_items[i].color = elements.color
                                ramp_items[i].position = elements.position
                                ramp_items[i].color = elements.color
        import os
        Albedo = ("Albedo", "Diffuse", "Color", "diff")
        Reflection = ("Reflection", "Specular", "reflect", "refl", "spec")
        RGH = ("Glossiness", "Roughness", "RGH", "gloss")
        Metal = ("Gold", "Chrome", "Metal", "alum", "brass", "steel")
        Normal_names = ("Normal", "nrm", "nor")
        Bumps_maps = ("Bump", "bump")
        szklo = ("glass", "water", "milk", "juice")
        Trans = ("Transmission", "Translucency", "trans")
        Opacity = ("Opacity", "alpha")
        Displacement = ("Displacement", "disp")
        Fabrics_inputs = ("wool", "fabric")
        Nazwy_front =("_f_", "_F_", "front", "Front")
        Nazwy_Back =("_b_", "_B_", "Back", "back")
        #Dodawanie z Addonu
        addon_dir = os.path.dirname(__file__)
        shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        bpy.ops.wm.append(filename="AM268_001_Octane", directory=shaders_path)
        bpy.ops.wm.append(filename="AM266_001_Octane_Glass", directory=shaders_path)
        bpy.ops.wm.append(filename="AM268_001_Octane_Transmission", directory=shaders_path)
        tree_node_group = bpy.data.node_groups["AM268_001_Octane"]
        blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        new_group_name = blend_file_name[:9]
        # Ustawianie grupy Base
        node_tree = bpy.data.node_groups["AM268_001_Octane"]
        node_tree.name = new_group_name + "_Octane"
        #Ustawianie grupy glass:
        node_tree_glass = bpy.data.node_groups["AM266_001_Octane_Glass"]
        node_tree_glass.name = new_group_name + "_Octane_Glass"
        #Ustawienie grupy Transmission:
        node_tree_trans = bpy.data.node_groups["AM268_001_Octane_Transmission"]
        node_tree_trans.name = new_group_name + "_Octane_Transmission"
        for material in bpy.data.materials:
            #print(material.name)
            if not "Dots Stroke" in material.name:
                #print("Moj materail to: ", material.name)
                nodetree= material.node_tree
                if nodetree:
                    for node in nodetree.nodes:
                        Octane_Basic_Exists = False
                        for node1 in nodetree.nodes:
                            if "Octane" in node1.name:
                                if "Octane_Basic" in node1.label:
                                    Octane_Basic_Exists = True
                                    break
                        if not Octane_Basic_Exists:
                            group_node = nodetree.nodes.new("ShaderNodeGroup")
                            group_node.node_tree = node_tree.copy()
                            group_node.name = node_tree.name
                            group_node.label = "Octane_Basic"
                            group_node.location.x += 2650
                            Octane_out_exist = False
                            for node2 in nodetree.nodes:
                                if "Octane_Output" in node2.label:
                                    output_node = node2
                                    Octane_out_exist = True
                                    break
                            if not Octane_out_exist:
                                output_node = material.node_tree.nodes.new("ShaderNodeOutputMaterial")
                                output_node.label = "Octane_Output"
                                output_node.location.x += 2900
                            nodetree.links.new(group_node.outputs[0], output_node.inputs[0])
                            group_node.inputs[9].default_value = True
                            for node3 in nodetree.nodes:
                                if "mix_mat_oct" in node3.name or "Oct_Two_Side" in node3.name or "Back_Side" in node3.label or "First_Side" in node3.label or "Octane_Glass" in node3.label:
                                    nodetree.nodes.remove(node3)
                            Octane_out_exist = True
                        break
                    for node in nodetree.nodes:
                        if "Octane_Basic" in node.label:
                            group_oct_basic = node
                            for node in nodetree.nodes:
                                if node.label == "Base Color":
                                    nodetree.links.new(node.outputs[0], group_oct_basic.inputs[0])
                                if node.bl_idname == "OctaneRGBImage":
                                    for tekstura in Albedo:
                                        if tekstura.lower() in node.last_image_name.lower():
                                            node.inputs[2].default_value = 2.2
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[0])
                                    for tekstura in Reflection:
                                        if tekstura.lower() in node.last_image_name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[1])
                                    for tekstura in RGH:
                                        if tekstura.lower() in node.last_image_name.lower():
                                            node.inputs[2].default_value =1.0
                                            node.inputs[3].default_value = True
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[2])
                                            if "gloss" in node.last_image_name.lower():
                                                node.inputs[3].default_value = True                                        
                                    for tekstura in Normal_names:
                                        if tekstura.lower() in node.last_image_name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[3])
                                    for tekstura in Bumps_maps:
                                        if tekstura.lower() in node.last_image_name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[4])
                                    for tekstura_o in Opacity:
                                        if tekstura_o.lower() in node.last_image_name.lower():
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[6])
                                    for tekstura_d in Displacement:
                                        if tekstura_d.lower() in node.last_image_name.lower():
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[5])
                                            node.inputs[2].default_value = 1
                                            group_oct_basic.inputs[11].default_value = 0.01
                                        else:
                                            group_oct_basic.inputs[11].default_value = 0.001
                        for node_r in nodetree.nodes:
                            if "Octane_Basic" in node_r.label:
                                group_oct_basic = node_r
                                for node in nodetree.nodes:
                                    if node.bl_idname == "OctaneRGBImage":
                                        for Tekstur_metal in Metal:
                                            if Tekstur_metal.lower() in node.last_image_name.lower():
                                                group_oct_basic.inputs[8].default_value = 1
                                                for tekstura in Reflection:
                                                    if tekstura.lower() in node.last_image_name.lower():
                                                        node.inputs[2].default_value = 2.2
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[0])
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[1])
                                                for tekstura in RGH:
                                                    if tekstura.lower() in node.last_image_name.lower():
                                                        node.inputs[2].default_value =1.0
                                                        node.inputs[3].default_value = True
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[2])
                                                        if "gloss" in node.last_image_name.lower():
                                                            node.inputs[3].default_value = True  
                                                for tekstura in Normal_names:
                                                    if tekstura.lower() in node.last_image_name.lower():
                                                        node.inputs[2].default_value = 1
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[3])
                                                for tekstura in Bumps_maps:
                                                    if tekstura.lower() in node.last_image_name.lower():
                                                        node.inputs[2].default_value = 1
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[6])
                                                for tekstura_o in Opacity:
                                                    if tekstura_o.lower() in node.last_image_name.lower():
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[5])
        for material in bpy.data.materials:
            if not "Dots Stroke" in material.name:
                nodetree= material.node_tree
                if nodetree:
                    for node in nodetree.nodes:
                        if node.bl_idname == "OctaneRGBImage":
                            for tekstura_glass in szklo:
                                if tekstura_glass.lower() in node.last_image_name.lower():
                                    Material_Octane = False
                                    for node1 in nodetree.nodes:
                                        print(node1.name)
                                        #print(nodetree.nodes.name)
                                        if "Octane" in node1.name:
                                            print("To jest moj node :", node1.name)
                                            nodetree.nodes.remove(node1)
                                            Material_Octane = False
                                            break
                                    if not Material_Octane:
                                        group_node = material.node_tree.nodes.new("ShaderNodeGroup")
                                        group_node.node_tree = node_tree_glass.copy()
                                        group_node.name = node_tree_glass.name
                                        group_node.location.x += 1650
                                        Octane_out_exist = False
                                        for node2 in nodetree.nodes:
                                            if "Octane_Output" in node2.label:
                                                output_node = node2
                                                Octane_out_exist = True
                                                break
                                        if not Octane_out_exist:
                                            output_node = material.node_tree.nodes.new("ShaderNodeOutputMaterial")
                                            output_node.label = "Octane_Output"
                                            output_node.location.x += 2000
                                    material.node_tree.links.new(group_node.outputs[0], output_node.inputs[0])
                                    group_node.inputs[8].default_value = True
                                    for node3 in nodetree.nodes:
                                        if "mix_mat_oct" in node3.name or "Oct_Two_Side" in node3.name or "Back_Side" in node3.label or "First_Side" in node3.label:
                                            nodetree.nodes.remove(node3)
                                    Material_Octane = True
                                break
                            for node in nodetree.nodes:
                                if "Octane_Glass" in node.label:
                                    print("Tego noda szukam:  ",node.name)
                                    group_node = node
                                    for node in nodetree.nodes:
                                        if node.bl_idname == "OctaneRGBImage":
                                            for tekstura in Albedo:
                                                if tekstura.lower() in node.last_image_name.lower():
                                                    node.inputs[2].default_value = 2.2
                                                    nodetree.links.new(node.outputs[0], group_node.inputs[0])
                                            for tekstura in Reflection:
                                                if tekstura.lower() in node.last_image_name.lower():
                                                    node.inputs[2].default_value = 1
                                                    nodetree.links.new(node.outputs[0], group_node.inputs[2])
                                            for tekstura in RGH:
                                                if tekstura.lower() in node.last_image_name.lower():
                                                    node.inputs[2].default_value =1.0
                                                    nodetree.links.new(node.outputs[0], group_oct_glass.inputs[3])
                                                    if "gloss" in node.last_image_name.lower():
                                                        node.inputs[3].default_value = True
                                            for tekstura in Normal_names:
                                                if tekstura.lower() in node.last_image_name.lower():
                                                    node.inputs[2].default_value = 1
                                                    nodetree.links.new(node.outputs[0], group_node.inputs[4])
                                            for tekstura in Bumps_maps:
                                                if tekstura.lower() in node.last_image_name.lower():
                                                    node.inputs[2].default_value = 1
                                                    nodetree.links.new(node.outputs[0], group_node.inputs[5])
                                            for tekstura_o in Opacity:
                                                if tekstura_o.lower() in node.last_image_name.lower():
                                                    nodetree.links.new(node.outputs[0], group_node.inputs[6])
        #Dodanie Trans
        for material in bpy.data.materials:
            #print(material.name)
            if not "Dots Stroke" in material.name:
                #print("Moj materail to: ", material.name)
                nodetree= material.node_tree
                if nodetree:
                    for node in nodetree.nodes:
                        if node.bl_idname == "OctaneRGBImage":
                            for tekstura_tt in Trans:
                                #print("to jest moje Trans ", Trans)
                                #print("a to znajduje", tekstura_tt)               
                                if tekstura_tt.lower() in node.last_image_name.lower():
                                    Material_Octane = False
                                    for node1 in nodetree.nodes:
                                        print(node1.name)
                                        if "Octane" in node1.name:
                                            if "First_Side" in node1.label:
                                                group_oct_trans = node1
                                                Material_Octane = True
                                                break
                                            else:
                                                nodetree.nodes.remove(node1)
                                                First_Side = False
                                    if not Material_Octane:
                                        group_oct_trans = material.node_tree.nodes.new("ShaderNodeGroup")
                                        group_oct_trans.node_tree = node_tree_trans.copy()
                                        group_oct_trans.name = node_tree_trans.name
                                        group_oct_trans.label = "First_Side"
                                        group_oct_trans.location.x += 1950
                                    Material_Octane = True
                                    Octane_out_exist = False
                                    for node2 in nodetree.nodes:
                                        if "Octane_Output" in node2.label:
                                            out_oct = node2
                                            Octane_out_exist = True
                                            break
                                    if not Octane_out_exist:
                                        out_oct = material.node_tree.nodes.new("ShaderNodeOutputMaterial")
                                        out_oct.label = "Octane_Output"
                                        out_oct.location.x += 2500
                                        Octane_out_exist = True
                                    nodetree.links.new(group_oct_trans.outputs[0], out_oct.inputs[0])
                                    group_oct_trans.inputs[9].default_value = 1.0
                                    for node_front in nodetree.nodes:
                                        if node_front.bl_idname == "OctaneRGBImage":
                                            if "back" in node_front.last_image_name.lower() or "front" in node_front.last_image_name.lower():
                                                print("moje teksturey to ;", node_front.last_image_name)
                                                Back_oct = False
                                                for node_back in nodetree.nodes:
                                                    if "Back_Side" in node_back.label:
                                                       group_node_back = node_back
                                                       Back_oct = True
                                                       break
                                                if not Back_oct:
                                                    group_node_back = nodetree.nodes.new(type='ShaderNodeGroup')
                                                    group_node_back.name = node_tree_trans.name + "_back"
                                                    group_node_back.label = "Back_Side"
                                                    group_node_back.node_tree = node_tree_trans.copy()
                                                    group_node_back.location = 1950, -464
                                                    Back_oct = True 
                                                Mix_mat = False
                                                for node1 in nodetree.nodes:
                                                    if "mix_mat_oct" in node1.name:
                                                        node_mix = node1
                                                        Mix_mat = True
                                                        break
                                                if not Mix_mat:
                                                    node_mix = nodetree.nodes.new("OctaneMixMaterial")
                                                    node_mix.name = "mix_mat_oct"
                                                    node_mix.location = 2200, -75
                                                OCT_double = False
                                                for node2 in nodetree.nodes:
                                                    if "Oct_Two_Side" in node2.name:
                                                        oct_2_side = node2
                                                        OCT_double = True
                                                        break
                                                if not OCT_double:
                                                    oct_2_side = nodetree.nodes.new("OctanePolygonSide")
                                                    oct_2_side.name = "Oct_Two_Side"
                                                    oct_2_side.location = 1880, 162
                                                    oct_2_side.inputs[0].default_value = True
                                                nodetree.links.new(node_mix.outputs[0],out_oct.inputs[0])
                                                nodetree.links.new(node_mix.inputs[1],group_oct_trans.outputs[0])
                                                nodetree.links.new(node_mix.inputs[2],group_node_back.outputs[0])
                                                nodetree.links.new(node_mix.inputs[0],oct_2_side.outputs[0]) 
                                                for node_t in nodetree.nodes:
                                                    if node_t.bl_idname == "OctaneRGBImage":
                                                        for tekstura in Albedo:
                                                            if tekstura.lower() in node_t.last_image_name.lower() and not "back" in node_t.last_image_name.lower():
                                                                nodetree.links.new(node_t.outputs[0],group_oct_trans.inputs[0])
                                                                nodetree.links.new(node_t.outputs[0],group_oct_trans.inputs[1])
                                                                print("moja tekstura_diffuse to :", node_t.last_image_name)
                                                                group_oct_trans.inputs[3].default_value = 1.3
                                                                group_oct_trans.inputs[4].default_value = 0.5
                                                                Albedo_back_exists = False
                                                                for node_t2 in nodetree.nodes:
                                                                    if node_t2.bl_idname == "OctaneRGBImage":
                                                                        for tekstura2 in Albedo:
                                                                            if tekstura2.lower() in node_t2.last_image_name.lower() and "back" in node_t2.last_image_name.lower():
                                                                                Albedo_back = node_t2
                                                                                Albedo_back_exists = True
                                                                                break
                                                                if not Albedo_back_exists:
                                                                    Albedo_back = node_t
                                                                nodetree.links.new(Albedo_back.outputs[0],group_node_back.inputs[0])
                                                                nodetree.links.new(Albedo_back.outputs[0],group_node_back.inputs[1])
                                                                group_node_back.inputs[3].default_value = 1.3
                                                                group_node_back.inputs[4].default_value = 0.5
                                                                break                #break
                                                for node_t2 in nodetree.nodes:
                                                    if node_t2.bl_idname == "OctaneRGBImage":
                                                        for tekstur_tr in Trans:
                                                            if tekstur_tr.lower() in node_t2.last_image_name.lower() and not "back" in node_t2.last_image_name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[1])
                                                                Transmission_back = False
                                                                for node_t3 in nodetree.nodes:
                                                                    if node_t3.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_tr in Trans:
                                                                            if tekstur_tr.lower() in node_t3.last_image_name.lower() and "back" in node_t3.last_image_name.lower():
                                                                                node_trans_back = node_t3
                                                                                Transmission_back = True
                                                                                break
                                                                if not Transmission_back:
                                                                    node_trans_back = node_t2
                                                                nodetree.links.new(node_trans_back.outputs[0], group_node_back.inputs[1])
                                                                group_oct_trans.inputs[3].default_value = 1.0
                                                                group_oct_trans.inputs[4].default_value = 0.0
                                                                group_node_back.inputs[3].default_value = 1.0
                                                                group_node_back.inputs[4].default_value = 0.0
                                                        for tkstur_r in Reflection:
                                                            if tkstur_r.lower() in node_t2.last_image_name.lower() and not "back" in node_t2.last_image_name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[5])
                                                                node_t2.inputs[2].default_value = 1
                                                                Reflection_back = False
                                                                for node_rb in nodetree.nodes:
                                                                    if node_rb.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_r2 in Trans:
                                                                            if tekstur_r2.lower() in node_rb.last_image_name.lower() and "back" in node_rb.last_image_name.lower():
                                                                                node_reflect_back = node_rb
                                                                                Reflection_back = True
                                                                                break
                                                                if not Reflection_back:
                                                                    node_reflect_back = node_t2
                                                                nodetree.links.new(node_reflect_back.outputs[0], group_node_back.inputs[5])
                                                        for tekstur_roug in RGH:
                                                            if tekstur_roug.lower() in node_t2.last_image_name.lower() and not "back" in node_t2.last_image_name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[6])
                                                                node_t2.inputs[2].default_value = 1
                                                                if "gloss" in node_t2.last_image_name.lower():
                                                                    node_t2.inputs[3].default_value = True
                                                                Roughness_back = False
                                                                for node_rb in nodetree.nodes:
                                                                    if node_rb.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_r2 in Trans:
                                                                            if tekstur_r2.lower() in node_rb.last_image_name.lower() and "back" in node_rb.last_image_name.lower():
                                                                                node_roughness_back = node_rb
                                                                                Roughness_back = True
                                                                                break
                                                                if not Roughness_back:
                                                                    node_roughness_back = node_t2
                                                                nodetree.links.new(node_roughness_back.outputs[0], group_node_back.inputs[6])
                                                        for tkstur_n in Normal_names:
                                                            if tkstur_n.lower() in node_t2.last_image_name.lower() and not "back" in node_t2.last_image_name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[7])
                                                                node_t2.inputs[2].default_value = 1
                                                                Normal_back = False
                                                                for node_nb in nodetree.nodes:
                                                                    if node_nb.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_n2 in Trans:
                                                                            if tekstur_n2.lower() in node_nb.last_image_name.lower() and "back" in node_nb.last_image_name.lower():
                                                                                node_normal_back = node_nb
                                                                                Normal_back = True
                                                                                break
                                                                if not Normal_back:
                                                                    node_normal_back = node_t2
                                                                nodetree.links.new(node_normal_back.outputs[0], group_node_back.inputs[7])
                                                        for tkstur_b in Bumps_maps:
                                                            if tkstur_b.lower() in node_t2.last_image_name.lower() and not "back" in node_t2.last_image_name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[8])
                                                                node_t2.inputs[2].default_value = 1
                                                                Bump_back = False
                                                                for node_bb in nodetree.nodes:
                                                                    if node_bb.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_n2 in Trans:
                                                                            if tekstur_n2.lower() in node_bb.last_image_name.lower() and "back" in node_bb.last_image_name.lower():
                                                                                node_bump_back = node_bb
                                                                                Bump_back = True
                                                                                break
                                                                if not Bump_back:
                                                                    node_bump_back = node_t2
                                                                nodetree.links.new(node_bump_back.outputs[0], group_node_back.inputs[8])
                                                        for tkstur_o in Opacity:
                                                            if tkstur_o.lower() in node_t2.last_image_name.lower() and not "back" in node_t2.last_image_name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[12])
                                                                node_t2.inputs[2].default_value = 1
                                                                Opacity_back = False
                                                                for node_ob in nodetree.nodes:
                                                                    if node_ob.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_n2 in Trans:
                                                                            if tekstur_n2.lower() in node_ob.last_image_name.lower() and "back" in node_ob.last_image_name.lower():
                                                                                node_opacity_back = node_ob
                                                                                Opacity_back = True
                                                                                break
                                                                if not Opacity_back:
                                                                    node_opacity_back = node_t2
                                                                nodetree.links.new(node_opacity_back.outputs[0], group_node_back.inputs[12])
                                                        for tkstur_D in Displacement:
                                                            if tkstur_D.lower() in node_t2.last_image_name.lower() and not "back" in node_t2.last_image_name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[13])
                                                                node_t2.inputs[2].default_value = 1
                                                                group_oct_trans.inputs[14].default_value = 0.01
                                                                Disp_back = False
                                                                for node_db in nodetree.nodes:
                                                                    if node_db.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_n2 in Trans:
                                                                            if tekstur_n2.lower() in node_db.last_image_name.lower() and "back" in node_db.last_image_name.lower():
                                                                                node_disp_back = node_db
                                                                                Disp_back = True
                                                                                break
                                                                if not Disp_back:
                                                                    node_disp_back = node_t2
                                                                nodetree.links.new(node_disp_back.outputs[0], group_node_back.inputs[12])
                                                                group_node_back.inputs[14].default_value = 0.01
                                                            else:
                                                                group_oct_trans.inputs[14].default_value = 0.001
                                            else:
                                                 for node_1s in nodetree.nodes:
                                                     if node_1s.bl_idname == "OctaneRGBImage":
                                                        for tekstura in Albedo:
                                                            if tekstura.lower() in node_1s.last_image_name.lower() and not "back" in node_1s.last_image_name.lower():
                                                                nodetree.links.new(node_1s.outputs[0], group_oct_trans.inputs[0])
                                                                nodetree.links.new(node_1s.outputs[0], group_oct_trans.inputs[1])
                                                                group_oct_trans.inputs[3].default_value = 1.5
                                                                group_oct_trans.inputs[4].default_value = 0.5
                                                                break    #break
                                                        for tekstura_tr in Trans:
                                                            if tekstura_tr.lower() in node_1s.last_image_name.lower():
                                                                node_1s.inputs[2].default_value = 2.2
                                                                nodetree.links.new(node_1s.outputs[0], group_oct_trans.inputs[1])
                                                                group_oct_trans.inputs[3].default_value = 1.0
                                                                group_oct_trans.inputs[4].default_value = 0.0
                                                        for tekstura_re in Reflection:
                                                            if tekstura_re.lower() in node_1s.last_image_name.lower():
                                                                node_1s.inputs[2].default_value = 1
                                                                nodetree.links.new(node_1s.outputs[0], group_oct_trans.inputs[5])
                                                        for tekstura in RGH:
                                                            if tekstura.lower() in node_1s.last_image_name.lower():
                                                                node_1s.inputs[2].default_value = 1
                                                                node_1s.inputs[3].default_value = False
                                                                nodetree.links.new(node_1s.outputs[0], group_oct_trans.inputs[6])
                                                                if "gloss" in node_1s.last_image_name.lower():
                                                                    node_1s.inputs[3].default_value = True                                    
                                                        for tekstura_no in Normal_names:
                                                            if tekstura_no.lower() in node_1s.last_image_name.lower():
                                                                node_1s.inputs[2].default_value = 1
                                                                nodetree.links.new(node.outputs[0], group_oct_trans.inputs[7])
                                                        for tekstura_bu in Bumps_maps:
                                                            if tekstura_bu.lower() in node_1s.last_image_name.lower():
                                                                node_1s.inputs[2].default_value = 1
                                                                nodetree.links.new(node.outputs[0], group_oct_trans.inputs[8])
                                                        for tekstura_o in Opacity:
                                                            if tekstura_o.lower() in node_1s.last_image_name.lower():
                                                                nodetree.links.new(node_1s.outputs[0], group_oct_trans.inputs[12])
                                                        for tekstura_d in Displacement:
                                                            if tekstura_d.lower() in node_1s.last_image_name.lower():
                                                                node_1s.inputs[2].default_value = 1
                                                                nodetree.links.new(node_1s.outputs[0], group_oct_trans.inputs[13])
                                                                group_oct_trans.inputs[14].default_value = 0.01
                                                            else:
                                                                group_oct_trans.inputs[14].default_value = 0.001
                                                        for node_m in nodetree.nodes:
                                                            if "Back_Side" in node_m.label or "Oct_Two_Side" in node_m.name or "mix_mat_oct" in node_m.name:
                                                                nodetree.nodes.remove(node_m)
                                                        for node_n in nodetree.nodes:
                                                            if "First_Side" in node_n.label:
                                                                Shader = node_n
                                                                for node_n1 in nodetree.nodes:
                                                                    if "Octane_Output" in node_n1.label:
                                                                        Output_1 = node_n1
                                                                        nodetree.links.new(Shader.outputs[0], Output_1.inputs[0])                                                                                                      
        import math

        def connect_nodes_by_prefix():
            for material in bpy.data.materials:
                if material.name != "Dots Stroke":
                    node_tree = material.node_tree
                    if node_tree:
                        nodes = node_tree.nodes
                        links = node_tree.links
                        # Find all unique prefixes
                        prefixes = set()
                        for node in nodes:
                            if node.bl_idname.startswith("Octane"):
                                for prefix in ["Diffuse A", "Diffuse B", "Roughness A", "Roughness B", "Metallic A", "Metallic B", "Specular A", "Specular B", "Normal A", "Normal B", "IOR"]:
                                    if prefix in node.label:
                                        prefixes.add(prefix)
                                        break
                        # Connect nodes for each prefix
                        for prefix in prefixes:
                            matching_nodes = [node for node in nodes if node.bl_idname.startswith("Octane") and prefix in node.label]
                            matching_nodes.sort(key=lambda n: n.location[0])
                            # Connect nodes
                            for i in range(len(matching_nodes) - 1):
                                current_node = matching_nodes[i]
                                next_node = matching_nodes[i + 1]
                                if current_node.outputs and next_node.inputs:
                                    current_output = current_node.outputs[0]
                                    next_input = next_node.inputs[0]  # Default to 1st input
                                    # Special case for nodes with "Gradient Octane" in the label
                                    if "Gradient Octane" in next_node.label:
                                        next_input = next_node.inputs[2]  # Connect to 3rd input (index 2)
                                    links.new(current_output, next_input)
                                    print(f"Connecting '{current_node.label}' output to '{next_node.label}' input")
                            # Find the "Mix" node and connect the last node with the prefix to its input socket
                            mix_node_label = f"{prefix.replace(' A', '').replace(' B', '')} Mix Octane"
                            mix_node = next((node for node in nodes if node.label == mix_node_label), None)
                            if mix_node and matching_nodes:
                                last_node = matching_nodes[-1]
                                suffix = " A" if " A" in last_node.label else " B" if " B" in last_node.label else ""
                                input_socket = 1 if suffix == " A" else 2 if suffix == " B" else 0
                                if last_node.outputs:
                                    links.new(last_node.outputs[0], mix_node.inputs[input_socket])
                                    print(f"Connecting '{last_node.label}' output to '{mix_node_label}' input [{input_socket}]")

        def connect_nodes_without_prefix():
            for material in bpy.data.materials:
                if material.name != "Dots Stroke":
                    node_tree = material.node_tree
                    if node_tree:
                        nodes = node_tree.nodes
                        links = node_tree.links
                        # Find nodes without " A " and " B " in the label
                        non_prefixed_nodes = [node for node in nodes if node.bl_idname.startswith("Octane") and not any(prefix in node.label for prefix in [" A", " B"])]
                        # Create a dictionary to store prefix to node mapping
                        prefix_to_node = {}
                        for node in non_prefixed_nodes:
                            # Extract the prefix (first word of the label)
                            prefix = node.label.split(' ')[0]
                            prefix_to_node[prefix] = node
                        # Connect nodes based on the prefix
                        for node in non_prefixed_nodes:
                            prefix = node.label.split(' ')[0]
                            # Find the next node with the same prefix
                            next_node = prefix_to_node.get(prefix, None)
                            if next_node and next_node != node:
                                if node.outputs and next_node.inputs:
                                    current_output = node.outputs[0]
                                    next_input = next_node.inputs[0]  # Default to 1st input
                                    # Special case for nodes with "Gradient Octane" in the label
                                    if "Gradient Octane" in next_node.label:
                                        next_input = next_node.inputs[2]  # Connect to 3rd input (index 2)
                                    links.new(current_output, next_input)
                                    print(f"Connecting '{node.label}' output to '{next_node.label}' input")
                                # Update the prefix_to_node mapping to avoid connecting the same nodes
                                prefix_to_node[prefix] = None

        def connect_to_closest_octane_group_node():
            # Słownik przypisujący prefiksy do nazw wejść grupy Octane
            prefix_to_input_name = {
                "Diffuse": "Albedo",
                "Specular": "Reflection",
                "Metallic": "Metallic",
                "Normal": "Normal",
                "Roughness": "Roughness",
                "Displacement": "Displacement",
                "Bump": "Bump",
                "Transmission": "Transmission",
            }
            for material in bpy.data.materials:
                if material.name != "Dots Stroke":
                    node_tree = material.node_tree
                    if node_tree:
                        nodes = node_tree.nodes
                        links = node_tree.links
                        # Find the Octane group node
                        octane_group_node = next((node for node in nodes if node.bl_idname == 'ShaderNodeGroup' and 'Octane' in node.name), None)
                        if not octane_group_node:
                            print(f"No 'Octane' group node found in material '{material.name}'.")
                            continue
                        # Create a dictionary to store inputs of the group node
                        group_node_inputs = {input.name: input for input in octane_group_node.inputs}
                        # Find all nodes that are not the Octane group node
                        other_nodes = [node for node in nodes if node != octane_group_node]
                        # Create a list of nodes to connect, sorted by distance to the Octane group node

                        def distance(node):
                            return math.sqrt((node.location.x - octane_group_node.location.x) ** 2 +
                                             (node.location.y - octane_group_node.location.y) ** 2)
                        sorted_nodes = sorted(other_nodes, key=distance)
                        # Connect nodes to group node inputs based on prefix and distance
                        for node in sorted_nodes:
                            if node.label:
                                # Find the appropriate input name in the group node based on the node's label prefix
                                for prefix, input_name in prefix_to_input_name.items():
                                    if prefix in node.label:
                                        if input_name in group_node_inputs:
                                            input_socket = group_node_inputs[input_name]
                                            if not input_socket.is_linked and node.outputs:
                                                current_output = node.outputs[0]
                                                links.new(current_output, input_socket)
                                                print(f"Connecting '{node.label}' output to '{octane_group_node.name}' group's '{input_name}' input")
                                                break  # Stop once connected to an available input
        # Use the functions
        connect_nodes_by_prefix()
        connect_nodes_without_prefix()
        connect_to_closest_octane_group_node()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Cycles_Glass_9Fedc(bpy.types.Operator):
    bl_idname = "sna.cycles_glass_9fedc"
    bl_label = "Cycles_glass"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        protected_materials = [m for m in bpy.data.materials if getattr(m, "protect_cycles", False)]
        protected_material_names = [m.name for m in protected_materials]
        # Get the directory of the current blend file
        current_blend_file_dir = os.path.dirname(bpy.data.filepath)
        #Dodawanie grupy z Addonu:
        addon_dir = os.path.dirname(__file__)
        shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        bpy.ops.wm.append(filename="AM251_010_Cycles_Solid_glass", directory=shaders_path)
        #Dodawanie grupy z Realitviepath:
        #relative_path = os.path.join(current_blend_file_dir, "shaders/Shaders.blend/NodeTree")
        #bpy.ops.wm.append(filename="AM251_010_Cycles_Solid_glass", directory=relative_path)
        # Get the appended tree node group
        tree_node_group = bpy.data.node_groups["AM251_010_Cycles_Solid_glass"]
        # Get the name of the blend file
        blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        new_group_name = blend_file_name[:9]
        # Get the NodeTree to be added to materials
        node_tree = bpy.data.node_groups["AM251_010_Cycles_Solid_glass"]
        # Set the new name of the node tree
        node_tree.name = new_group_name + "_Cycles_Solid_glass"
        active_material = bpy.context.object.active_material
        if not "Dots Stroke" in active_material.name:
            nodetree = active_material.node_tree
            if nodetree:
                for node0 in nodetree.nodes:
                    Cycles_glass_Exists = False
                    for node1 in nodetree.nodes:
                        if "Cycles" in node1.name:
                            if "Cycles_Solid_glass" in node1.label:
                                group_node = node1
                                Cycles_glass_Exists = True
                                break
                            else:
                                nodetree.nodes.remove(node1)
                                Cycles_glass_Exists = False
                            break
                    if not Cycles_glass_Exists:
                        group_node = nodetree.nodes.new("ShaderNodeGroup")
                        group_node.node_tree = node_tree.copy()
                        group_node.name = node_tree.name
                        group_node.label = "Cycles_Solid_glass"
                        #for node3 in nodetree.nodes:
                            #if "mix_mat_oct" in node3.name or "Oct_Two_Side" in node3.name or "Back_Side" in node3.label or "First_Side" in node3.label or "Octane_Glass" in node3.label:
                                #nodetree.nodes.remove(node3)
                    break
                for node in nodetree.nodes:
                    if "Cycles_Solid_glass" in node.label:
                        group_cyc_glass = node
                        for node in nodetree.nodes:   
                            if node.type == "TEX_IMAGE":
                                #group_cyc_basic.inputs[5].default_value = 0
                                for tekstura in Albedo:
                                    if tekstura.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[0])
                                        group_cyc_glass.inputs[1].default_value = 0.01
                                for tekstura in Reflection:
                                    if tekstura.lower() in node.image.name.lower():
                                        node.image.colorspace_settings.name = 'Non-Color'
                                        nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[3])
                                for tekstura in RGH:
                                    if tekstura.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[4])
                                        group_cyc_glass.inputs[6].default_value = 0
                                        if "gloss" in node.image.name.lower():
                                            group_cyc_glass.inputs[6].default_value = 1
                                for tekstura in Bumps_maps:
                                    if tekstura.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[5])
                                        group_cyc_glass.inputs[10].default_value = 1 
                                        group_cyc_glass.inputs[19].default_value = 0.1
                                for tekstura in Normal_names:
                                    if tekstura.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[5])
                                        group_cyc_glass.inputs[10].default_value = 0
                                for tekstura_o in Opacity:
                                    if tekstura_o.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[8])
                                #for tekstura_d in Displacement:
                                    #if tekstura_d.lower() in node.image.name.lower():
                                        #nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[13])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Cycles_Trans_C703B(bpy.types.Operator):
    bl_idname = "sna.cycles_trans_c703b"
    bl_label = "Cycles_trans"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        # Get the directory of the current blend file
        current_blend_file_dir = os.path.dirname(bpy.data.filepath)
        #Dodawanie grupy z Addonu:
        addon_dir = os.path.dirname(__file__)
        shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        bpy.ops.wm.append(filename="AM266_001_Cycles_Transmission", directory=shaders_path)
        bpy.ops.wm.append(filename="AM266_003_Cycles_Transmission_Two_sided", directory=shaders_path)
        #Dodawanie grupy z Realitviepath:
        #relative_path = os.path.join(current_blend_file_dir, "shaders/Shaders.blend/NodeTree")
        #bpy.ops.wm.append(filename="AM266_001_Cycles_Transmission", directory=relative_path)
        #bpy.ops.wm.append(filename="AM266_003_Cycles_Transmission_Two_sided", directory=relative_path)
        # Get the appended tree node group
        tree_node_group = bpy.data.node_groups["AM266_001_Cycles_Transmission"]
        # Get the name of the blend file
        blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        new_group_name = blend_file_name[:9]
        # Get the NodeTree to be added to materials
        node_tree_trans = bpy.data.node_groups["AM266_001_Cycles_Transmission"]
        node_tree_trans.name = new_group_name + "_Cycles_Transmission"
        node_tree_two_sided = bpy.data.node_groups["AM266_003_Cycles_Transmission_Two_sided"]
        node_tree_two_sided.name = new_group_name + "_Cycles_Transmission_Two_sided"
        active_material = bpy.context.object.active_material
        if not "Dots Stroke" in active_material.name:
            nodetree = active_material.node_tree
            if nodetree:
                for node_tr in nodetree.nodes:
                    Cycles_Transission_Exists = False
                    for node1 in nodetree.nodes:
                        if "Cycles" in node1.name:
                            if "Cycles_Transission_One_Side" in node1.label:
                                group_node = node1
                                Cycles_Transission_Exists = True
                                break
                            else:
                                nodetree.nodes.remove(node1)
                                Cycles_Transission_Exists = False
                    if not Cycles_Transission_Exists:
                        group_node = nodetree.nodes.new("ShaderNodeGroup")
                        group_node.node_tree = node_tree_trans.copy()
                        group_node.name = node_tree_trans.name
                        group_node.label = "Cycles_Transission_One_Side"
                        group_node.location = 210, 160
                    Cycles_Transission_Exists = True
                    break
                for node_trans in nodetree.nodes:
                    if "Cycles_Transission_One_Side" in node_trans.label:
                        group_node = node_trans
                        for node_2s in nodetree.nodes:
                            if node_2s.type == "TEX_IMAGE":
                                for tekstura in Albedo:
                                    if tekstura.lower() in node_2s.image.name.lower():
                                        group_node.inputs[9].default_value = 1.5
                                        group_node.inputs[10].default_value = 1.5
                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[0])
                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[1])
                                for tekstura_t in Trans:
                                    if tekstura_t.lower() in node_2s.image.name.lower():
                                        group_node.inputs[9].default_value = 1.0
                                        group_node.inputs[10].default_value = 1.0
                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[1])
                                for tekstura_r in Reflection:
                                    if tekstura_r.lower() in node_2s.image.name.lower():
                                        node_2s.image.colorspace_settings.name = 'Non-Color'
                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[2])
                                for tekstura_g in RGH:
                                    if tekstura_g.lower() in node_2s.image.name.lower():
                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[3])
                                        group_node.inputs[12].default_value = 0.0  
                                        if "gloss" in node_2s.image.name.lower():
                                            group_node.inputs[12].default_value = 1.0 
                                for tekstura_b in Bumps_maps:
                                    if tekstura_b.lower() in node_2s.image.name.lower():
                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[4])
                                        group_node.inputs[16].default_value = 1.0 
                                for tekstura_n in Normal_names:
                                    if tekstura_n.lower() in node_2s.image.name.lower():
                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[4])
                                        group_node.inputs[16].default_value = 0.0    
                                for tekstura_o in Opacity:
                                    if tekstura_o.lower() in node_2s.image.name.lower():
                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[5]) 
                                for tekstura_d in Displacement:
                                    if tekstura_d.lower() in node_2s.image.name.lower():
                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[6]) 
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Luscore_Textures_Migrate_7Abe2(bpy.types.Operator):
    bl_idname = "sna.luscore_textures_migrate_7abe2"
    bl_label = "Luscore_Textures_Migrate"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        for material in bpy.data.materials:
            if hasattr(material, 'node_tree'):
                active_material = material
                c_nodes_tree = active_material.node_tree
                Luxcore_nd = active_material.luxcore.node_tree
                if hasattr(c_nodes_tree, 'nodes'):
                    c_nodes = c_nodes_tree.nodes
                    # reszta skryptu
                    map_colorspace = {"Filmic Log": 1, "Linear": 1,  "LinearAces": 1, "Linear ACEScg": 1, "Non-Color": 1, "Raw": 1, "XYZ": 1, "sRGB": 2.2, "Filmic sRGB": 2.2, "Generic Data": 1}
                    bpy.context.scene.render.engine = 'LUXCORE'
                    # LuxCore Material node tree creation
                    tree_name = "Nodes_" + active_material.name
                    if active_material.luxcore.node_tree:
                        print("------- Luxcore Material Exists Already !!! --------")
                        node_tree = active_material.luxcore.node_tree
                        lux_nodes = node_tree.nodes
                    else:
                        node_tree = bpy.data.node_groups.new(name=tree_name, type="luxcore_material_nodes")
                        active_material.luxcore.node_tree = node_tree
                        node_tree.use_fake_user = True
                        lux_nodes = node_tree.nodes
                    lux_obj = {'lux_nodes': lux_nodes, 'node_tree': node_tree}
                    counter = 0
                    for node in c_nodes:
                        if hasattr(node, 'image'):
                            node_c = node
                            Luxcore_tex_exists = False
                            if hasattr(Luxcore_nd, 'nodes'):
                                for node1 in Luxcore_nd.nodes:
                                    if "Imagemap" in node1.bl_idname:
                                        l_color = node1
                                        if hasattr(l_color, 'image') and l_color.image.name == node_c.image.name:
                                            Luxcore_tex_exists = True
                                            break
                            if not Luxcore_tex_exists:
                                cs = node.image.colorspace_settings.name
                                bpy.context.object.active_material.luxcore.use_cycles_nodes = False
                                l_color = lux_obj['lux_nodes'].new("LuxCoreNodeTexImagemap")
                                l_color.location = -240, counter * -500
                                counter += 1
                                l_color.image = node.image
                                filename = node.image.filepath
                                filename = os.path.basename(filename)
                                l_color.gamma = map_colorspace[cs] if cs in map_colorspace else 1
                                l_color.label = filename
                    bpy.context.object.active_material.luxcore.use_cycles_nodes = False
        for node_groups in bpy.data.node_groups:
            for node in node_groups.nodes:
               # print(node)
                if "Imagemap" in node.name:
                    node.label = node.image.name
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Luxcore_Transmission_E9Cf2(bpy.types.Operator):
    bl_idname = "sna.luxcore_transmission_e9cf2"
    bl_label = "Luxcore_Transmission"
    bl_description = "Creates Transmission Shader according to textures inputs"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Nazwy_Luxcore_mat =("Disney Material", "Matte Material", "Carpaint Material", "Glass Material", "Cloth Material", "Mix Material", "Velvet Material", "Glossy Translucent Material", "Glossy Material", "Metal Material", "Mirror Material")
        active_material = bpy.context.object.active_material
        if not "Dots Stroke" in active_material.name:
            if "luxcore" in active_material:
                node_tree = active_material.luxcore.node_tree
                #print(node_tree.nodes)
                material_exists = False
                if node_tree:
                    for node0 in node_tree.nodes:
                        for Material in Nazwy_Luxcore_mat:                
                            if Material in node0.name:
                                if "LuxCoreNodeMatGlossyTranslucent" in node0.bl_idname:
                                    new_node = node0
                                    material_exists = True
                                    break
                                else:
                                    print(Material)
                                    node_tree.nodes.remove(node0)
                                    material_exists = False
                                #break
                                #print(node.name)
                                if not material_exists:
                                    new_node = node_tree.nodes.new(type="LuxCoreNodeMatGlossyTranslucent")
                                    new_node.use_transform = True
                                    new_node.location = 400,-600
                                    material_exists = True
                                    break
                    output_exists = False
                    for node2 in node_tree.nodes:
                        if "LuxCoreNodeMatOutput" in node2.bl_idname:
                            new_output = node2
                            output_exists = True
                            break
                    if not output_exists:
                            new_output = node_tree.nodes.new(type="LuxCoreNodeMatOutput")
                            new_output.use_transform = True
                            new_output.location = 800,-800
                    node_tree.links.new(new_node.outputs[0], new_output.inputs[0])
                        #node_tree.links.new(new_node.inputs[15],new_node_bump.outputs[0])
                    if material_exists:
                        for node in node_tree.nodes:    
                            if "Glossy Translucent Material" in node.name:
                                group_inputs_Trans = [node.inputs[i] for i in range(len(node.inputs))]
                                node_trans = node
                                node_trans.use_ior = True
                                for node_A in node_tree.nodes:
                                    for tekstura in Albedo:
                                        if tekstura.lower() in node_A.label.lower():
                                            node_tree.links.new(node_A.outputs[0], group_inputs_Trans[0])
                                Use_transmission = False           
                                for node_t in node_tree.nodes:
                                    for tekstura_T in Trans:
                                        if tekstura_T.lower() in node_t.label.lower():
                                            node_tree.links.new(node_t.outputs[0], group_inputs_Trans[1])
                                            for node_inv in node_tree.nodes:
                                                if "Luxcore_HSV_trans" in node_inv.name:
                                                    node_tree.nodes.remove(node_inv)
                                                    Use_transmission = True 
                                                    break
                                if not Use_transmission:
                                    for node_AT in node_tree.nodes:
                                        for tekstura_AT in Albedo:
                                            if tekstura_AT.lower() in node_AT.label.lower():
                                                node_a = node_AT
                                                HSV = False
                                                for node_hsv in node_tree.nodes:
                                                    if "Luxcore_HSV_trans" in node_hsv.name:
                                                        new_hsv = node_hsv
                                                        HSV = True
                                                        break
                                                if not HSV:
                                                    new_hsv = node_tree.nodes.new(type="LuxCoreNodeTexHSV")
                                                    new_hsv.use_transform = True
                                                    new_hsv.name = "Luxcore_HSV_trans"
                                                    new_hsv.location = 150,-600
                                                    new_hsv.inputs[2].default_value = 1.3
                                                    new_hsv.inputs[3].default_value = 1.5
                                                    HSV = True
                                                node_tree.links.new(node_a.outputs[0], new_hsv.inputs[0])
                                                node_tree.links.new(new_hsv.outputs[0], group_inputs_Trans[1])
                                for node_two in node_tree.nodes:
                                    if any(x in node_two.label for x in["Front", "front", "back", "Back"]):
                                        node_trans.use_backface = True
                                for node_R in node_tree.nodes:
                                    for reflect in Reflection:
                                        if reflect.lower() in node_R.label.lower():
                                            node_tree.links.new(node_R.outputs[0], group_inputs_Trans[2])
                                            if "back" in node_R.label.lower():
                                                node_tree.links.new(node_R.outputs[0], group_inputs_Trans[8])
                                            else:
                                                node_tree.links.new(node_R.outputs[0], group_inputs_Trans[12])
                                for node in node_tree.nodes:       
                                        for Roug in RGH:
                                            if Roug.lower() in node.label.lower():
                                                Rough_new = node
                                                print(Rough_new)
                                                node_tree.links.new(Rough_new.outputs[0], group_inputs_Trans[6])
                                                for node in node_tree.nodes:
                                                    if "gloss" in node.label.lower():
                                                        Invert = False
                                                        for node in node_tree.nodes:
                                                            if "Invert_Luxcore" in node.name:
                                                                Invert_node = node
                                                                Invert = True
                                                                break
                                                        if not Invert:
                                                            Invert_node = node_tree.nodes.new(type="LuxCoreNodeTexInvert")
                                                            Invert_node.name = "Invert_Luxcore"                                            
                                                            Invert_node.use_transform = True
                                                            Invert_node.location = 200,-700
                                                        #print("Outputs invert to:",new_gloss.outputs)
                                                        node_tree.links.new(Invert_node.outputs[0], group_inputs_Trans[6])
                                                        node_tree.links.new(Rough_new.outputs[0], Invert_node.inputs[0])
                                                        if "back" in node.label.lower():
                                                            node_tree.links.new(Invert_node.outputs[0], group_inputs_Trans[12])
                                                    Invert = True
                                                if Roug.lower() in node.label.lower():
                                                    if "gloss" not in node.label.lower():
                                                        for node_inv in node_group.nodes:
                                                            if "Invert_Luxcore" in node_inv.name:
                                                                node_tree.nodes.remove(node_inv)
                                #Podlaczanie Bump/Normal:
                                use_normal = False
                                for noden in node_tree.nodes:
                                    for Normalki in Normal_names:
                                        if Normalki.lower() in noden.label.lower():
                                            if "Normal/Map" not in noden.label:
                                                noden.is_normal_map = True
                                                node_tree.links.new(noden.outputs[2], group_inputs_Trans[15])
                                                #node.is_normal_map = True
                                                use_normal = True
                                                for node_LB in node_tree.nodes:
                                                    if "Luxcore_Bump" in node_LB.name:
                                                        #print(node.name)
                                                       node_tree.nodes.remove(node_LB)
                                                break
                                    if not use_normal:
                                        for nodeb in node_tree.nodes:
                                            for Bumpik in Bumps_maps:
                                                if Bumpik.lower() in nodeb.label.lower():
                                                    #node_tree.links.new(nodeb.outputs[0], group_inputs_Trans[15])
                                                    Bum_Exists = False
                                                    for node_bump in node_tree.nodes:
                                                        if "LuxCoreNodeTexBump" in node_bump.bl_idname:
                                                            new_node_bump = node_bump
                                                            Bum_Exists = True
                                                            break
                                                    if not Bum_Exists:
                                                        new_node_bump = node_tree.nodes.new(type="LuxCoreNodeTexBump")
                                                        new_node_bump.use_transform = True
                                                        new_node_bump.name = "Luxcore_Bump"
                                                        new_node_bump.location = 150,-1000
                                                    node_tree.links.new(nodeb.outputs[0], new_node_bump.inputs[0])
                                                    node_tree.links.new(new_node_bump.outputs[0], group_inputs_Trans[15])    
                                #Podlaczenie Opacity:
                                for node_to in node_tree.nodes:       
                                    for Maska in Opacity:
                                        if Maska.lower() in node_to.label.lower():
                                            #print("Tekstura Opacity to:",node.label)
                                            node_tree.links.new(node_to.outputs[0], group_inputs_Trans[14])
                                            #break
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Luxcore_Glass_Creation_12D41(bpy.types.Operator):
    bl_idname = "sna.luxcore_glass_creation_12d41"
    bl_label = "Luxcore_Glass_Creation"
    bl_description = "Creates Glass materials according to texture inputs "
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Nazwy_Luxcore_mat =("Disney Material", "Matte Material", "Carpaint Material", "Glass Material", "Cloth Material", "Mix Material", "Velvet Material", "Glossy Translucent Material", "Glossy Material", "Metal Material", "Mirror Material")
        active_material = bpy.context.object.active_material
        if not "Dots Stroke" in active_material.name:
            if "luxcore" in active_material:
                node_tree_glass = active_material.luxcore.node_tree
                #print(node_tree_glass.nodes)
                material_glass_exists = False
                for node0 in node_tree_glass.nodes:
                    for Material in Nazwy_Luxcore_mat:                
                        if Material in node0.name:
                            if "LuxCoreNodeMatGlass" in node0.bl_idname:
                                new_node = node0
                                material_glass_exists = True
                                break
                            else:
                                node_tree_glass.nodes.remove(node0)
                                material_exists = False
                            #break
                            #print(node.name)
                            if not material_glass_exists:
                                new_node = node_tree_glass.nodes.new(type="LuxCoreNodeMatGlass")
                                new_node.use_transform = True
                                new_node.location = 400,-600
                                material_glass_exists = True
                                break
                output_exists = False
                for node2 in node_tree_glass.nodes:
                    if "LuxCoreNodeMatOutput" in node2.bl_idname:
                        new_output = node2
                        output_exists = True
                        break
                if not output_exists:
                    new_output = node_tree_glass.nodes.new(type="LuxCoreNodeMatOutput")
                    new_output.use_transform = True
                    new_output.name = "Luxcore_Output"
                    new_output.location = 800,-800
                    output_exists = True
                node_tree_glass.links.new(new_node.outputs[0], new_output.inputs[0])
                #material_exists = True
                if material_glass_exists:
                    for node in node_tree_glass.nodes:    
                        if "LuxCoreNodeMatGlass" in node.bl_idname:
                            group_inputs_glass = [node.inputs[i] for i in range(len(node.inputs))]
                            node_glass = node
                            for node_A in node_tree_glass.nodes:
                                for tekstura in Albedo:
                                    if tekstura.lower() in node_A.label.lower():
                                        node_tree_glass.links.new(node_A.outputs[0], group_inputs_glass[0])
                            for node_R in node_tree_glass.nodes:
                                for reflect in Reflection:
                                    if reflect.lower() in node_R.label.lower():
                                        node_tree_glass.links.new(node_R.outputs[0], group_inputs_glass[1])
                            for node in node_tree_glass.nodes:       
                                    for Roug in RGH:
                                        if Roug.lower() in node.label.lower():
                                            node_glass.rough = True
                                            Rough_new = node
                                            print(Rough_new)
                                            node_tree_glass.links.new(Rough_new.outputs[0], group_inputs_glass[6])
                                            for node in node_tree_glass.nodes:
                                                if "gloss" in node.label.lower():
                                                    Invert = False
                                                    for node in node_tree_glass.nodes:
                                                        if "Invert_Luxcore" in node.name:
                                                            Invert_node = node
                                                            Invert = True
                                                            break
                                                    if not Invert:
                                                        Invert_node = node_tree_glass.nodes.new(type="LuxCoreNodeTexInvert")
                                                        Invert_node.name = "Invert_Luxcore"                                            
                                                        Invert_node.use_transform = True
                                                        Invert_node.location = 200,-700
                                                    #print("Outputs invert to:",new_gloss.outputs)
                                                    node_tree_glass.links.new(Invert_node.outputs[0], group_inputs_glass[6])
                                                    node_tree_glass.links.new(Rough_new.outputs[0], Invert_node.inputs[0])
                                                    Invert = True
                                            if Roug.lower() in node.label.lower():
                                                if "gloss" not in node.label.lower():
                                                    for node_inv in node_group.nodes:
                                                        if "Invert_Luxcore" in node_inv.name:
                                                            node_tree_glass.nodes.remove(node_inv)
                            #Podlaczanie Bump/Normal:
                            use_glass_normal = False
                            for noden in node_tree_glass.nodes:
                                for Normalki in Normal_names:
                                    if Normalki.lower() in noden.label.lower():
                                        if "Normal/Map" not in noden.label:
                                            noden.is_normal_map = True
                                            node_tree_glass.links.new(noden.outputs[2], group_inputs_glass[9])
                                            #node.is_normal_map = True
                                            use_glass_normal = True
                                            for node_LB in node_tree_glass.nodes:
                                                if "LuxCoreNodeTexBump" in node_LB.bl_idname:
                                                    #print(node.name)
                                                   node_tree_glass.nodes.remove(node_LB)
                                            break
                                if not use_glass_normal:
                                    for nodeb in node_tree_glass.nodes:
                                        for Bumpik in Bumps_maps:
                                            if Bumpik.lower() in nodeb.label.lower():
                                                #node_tree_glass.links.new(nodeb.outputs[0], group_inputs_Trans[15])
                                                Bum_Exists = False
                                                for node_bump in node_tree_glass.nodes:
                                                    if "LuxCoreNodeTexBump" in node_bump.bl_idname:
                                                        new_node_bump = node_bump
                                                        Bum_Exists = True
                                                        break
                                                if not Bum_Exists:
                                                    new_node_bump = node_tree_glass.nodes.new(type="LuxCoreNodeTexBump")
                                                    new_node_bump.use_transform = True
                                                    new_node_bump.name = "Luxcore_Bump"
                                                    new_node_bump.location = 150,-1000
                                                node_tree_glass.links.new(nodeb.outputs[0], new_node_bump.inputs[0])
                                                node_tree_glass.links.new(new_node_bump.outputs[0], group_inputs_glass[9])
                            #Podlaczenie Opacity:
                            for node in node_tree_glass.nodes:       
                                for Maska in Opacity:
                                    if Maska.lower() in node.label.lower():
                                        #print("Tekstura Opacity to:",node.label)
                                        node_tree_glass.links.new(node.outputs[0], group_inputs_glass[8])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Octane_Metal_5F679(bpy.types.Operator):
    bl_idname = "sna.octane_metal_5f679"
    bl_label = "Octane_Metal"
    bl_description = "Octane_Metal"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Fabrics_inputs = bpy.context.window_manager.Cloth_textures.split(",")
        protected_materials = [m for m in bpy.data.materials if getattr(m, "protect_octane", False)]
        protected_material_names = [m.name for m in protected_materials]
        # Get the directory of the current blend file
        current_blend_file_dir = os.path.dirname(bpy.data.filepath)
        #Dodawanie z Addon Path
        addon_dir = os.path.dirname(__file__)
        shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        bpy.ops.wm.append(filename="AM268_001_Octane", directory=shaders_path)
        # Dodawanie z Realative path
        #relative_path = os.path.join(current_blend_file_dir, "shaders/Shaders.blend/NodeTree")
        #bpy.ops.wm.append(filename="AM268_001_Octane", directory=relative_path)
        # Get the appended tree node group
        tree_node_group = bpy.data.node_groups["AM268_001_Octane"]
        # Get the name of the blend file
        blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        new_group_name = blend_file_name[:9]
        # Get the NodeTree to be added to materials
        node_tree = bpy.data.node_groups["AM268_001_Octane"]
        # Set the new name of the node tree
        node_tree.name = new_group_name + "_Octane"
        active_material = bpy.context.object.active_material
        if not any (name in active_material.name for name in protected_material_names):
            if not "Dots Stroke" in active_material.name:
                nodetree = active_material.node_tree
                if nodetree:
                    for node0 in nodetree.nodes:
                        Octane_Basic_Exists = False
                        for node1 in nodetree.nodes:
                            if "Octane" in node1.name:
                                if "Octane_Basic" in node1.label:
                                    group_node = node1
                                    Octane_Basic_Exists = True
                                    break
                                else:
                                    nodetree.nodes.remove(node1)
                                    Octane_Basic_Exists = False
                                break
                        if not Octane_Basic_Exists:
                            group_node = nodetree.nodes.new("ShaderNodeGroup")
                            group_node.node_tree = node_tree.copy()
                            group_node.name = node_tree.name
                            group_node.label = "Octane_Basic"
                            group_node.location.x += 1650
                            Octane_out_exist = False
                            for node2 in nodetree.nodes:
                                if "Octane_Output" in node2.label:
                                    output_node = node2
                                    Octane_out_exist = True
                                    break
                            if not Octane_out_exist:
                                output_node = material.node_tree.nodes.new("ShaderNodeOutputMaterial")
                                output_node.label = "Octane_Output"
                                output_node.location.x += 2000
                            nodetree.links.new(group_node.outputs[0], output_node.inputs[0])
                            group_node.inputs[9].default_value = True
                            for node3 in nodetree.nodes:
                                if "mix_mat_oct" in node3.name or "Oct_Two_Side" in node3.name or "Back_Side" in node3.label or "First_Side" in node3.label or "Octane_Glass" in node3.label:
                                    nodetree.nodes.remove(node3)
                            Octane_out_exist = True
                        break
                    for node in nodetree.nodes:
                        if "Octane_Basic" in node.label:
                            group_oct_basic = node
                            for node in nodetree.nodes:
                                if node.bl_idname == "OctaneRGBImage":
                                    group_oct_basic.inputs[8].default_value = 1
                                    for tekstura in Albedo:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 2.2
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[0])
                                    for tekstura in Reflection:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 2.2
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[1])
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[0])
                                    for tekstura in RGH:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value =1.0
                                            node.inputs[3].default_value = True
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[2])
                                            if "gloss" in node.image.name.lower():
                                                node.inputs[3].default_value = True
                                    for tekstura in Normal_names:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[3])
                                    for tekstura in Bumps_maps:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[6])
                                    for tekstura_o in Opacity:
                                        if tekstura_o.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[5])
                                    for tekstura_d in Displacement:
                                        if tekstura_d.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[5])
                                            node.inputs[2].default_value = 1
                                            group_oct_basic.inputs[11].default_value = 0.01
                                        else:
                                            group_oct_basic.inputs[11].default_value = 0.001
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Luxcore1_70Fba(bpy.types.Operator):
    bl_idname = "sna.luxcore1_70fba"
    bl_label = "Luxcore1"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        for material in bpy.data.materials:
            if hasattr(material, 'node_tree'):
                active_material = material
                c_nodes_tree = active_material.node_tree
                Luxcore_nd = active_material.luxcore.node_tree
                if hasattr(c_nodes_tree, 'nodes'):
                    c_nodes = c_nodes_tree.nodes
                    # reszta skryptu
                    map_colorspace = {"Filmic Log": 1, "Linear": 1,  "LinearAces": 1, "Linear ACEScg": 1, "Non-Color": 1, "Raw": 1, "XYZ": 1, "sRGB": 2.2, "Filmic sRGB": 2.2, "Generic Data": 1}
                    bpy.context.scene.render.engine = 'LUXCORE'
                    # LuxCore Material node tree creation
                    tree_name = "Nodes_" + active_material.name
                    if active_material.luxcore.node_tree:
                        print("------- Luxcore Material Exists Already !!! --------")
                        node_tree = active_material.luxcore.node_tree
                        lux_nodes = node_tree.nodes
                    else:
                        node_tree = bpy.data.node_groups.new(name=tree_name, type="luxcore_material_nodes")
                        active_material.luxcore.node_tree = node_tree
                        node_tree.use_fake_user = True
                        lux_nodes = node_tree.nodes
                    lux_obj = {'lux_nodes': lux_nodes, 'node_tree': node_tree}
                    counter = 0
                    for node in c_nodes:
                        if hasattr(node, 'image'):
                            node_c = node
                            Luxcore_tex_exists = False
                            if hasattr(Luxcore_nd, 'nodes'):
                                for node1 in Luxcore_nd.nodes:
                                    if "Imagemap" in node1.bl_idname:
                                        l_color = node1
                                        if hasattr(l_color, 'image') and l_color.image.name == node_c.image.name:
                                            Luxcore_tex_exists = True
                                            break
                            if not Luxcore_tex_exists:
                                cs = node.image.colorspace_settings.name
                                bpy.context.object.active_material.luxcore.use_cycles_nodes = False
                                l_color = lux_obj['lux_nodes'].new("LuxCoreNodeTexImagemap")
                                l_color.location = -240, counter * -500
                                counter += 1
                                l_color.image = node.image
                                filename = node.image.filepath
                                filename = os.path.basename(filename)
                                l_color.gamma = map_colorspace[cs] if cs in map_colorspace else 1
                                l_color.label = filename
                    bpy.context.object.active_material.luxcore.use_cycles_nodes = False
        for node_groups in bpy.data.node_groups:
            for node in node_groups.nodes:
               # print(node)
                if "Imagemap" in node.name:
                    node.label = node.image.name
        import os
        interpolation_map = {'CONSTANT': 'none', 'B_SPLINE': 'linear', 'LINEAR': 'linear', 'EASE': 'cubic'}
        # Loop through all materials
        for material in bpy.data.materials:
            # Check if material has a node tree
            if hasattr(material, 'node_tree'):
                # Set active material
                active_material = material
                # Get Cycles node tree
                c_nodes_tree = active_material.node_tree
                # Get LuxCore node tree
                Luxcore_nd = active_material.luxcore.node_tree
                # Check if Cycles node tree has nodes
                if hasattr(c_nodes_tree, 'nodes'):
                    # Get Cycles nodes
                    c_nodes = c_nodes_tree.nodes
                    # Create LuxCore Material node tree
                    tree_name = "Nodes_" + active_material.name
                    # Check if LuxCore Material node tree already exists
                    if active_material.luxcore.node_tree:
                        print("------- Luxcore Material Exists Already !!! --------")
                        node_tree = active_material.luxcore.node_tree
                        lux_nodes = node_tree.nodes
                    else:
                        node_tree = bpy.data.node_groups.new(name=tree_name, type="luxcore_material_nodes")
                        active_material.luxcore.node_tree = node_tree
                        node_tree.use_fake_user = True
                        lux_nodes = node_tree.nodes
                    lux_obj = {'lux_nodes': lux_nodes, 'node_tree': node_tree}
                    counter = 0
                    val_to_rgb_nodes = [node for node in c_nodes_tree.nodes if node.bl_idname.startswith("ShaderNodeValToRGB")]
                    print(val_to_rgb_nodes)
                    for val_to_rgb_node in val_to_rgb_nodes:
                        node_c = val_to_rgb_node.color_ramp
                        Color_ramp_location = val_to_rgb_node.location
                        cycles_interpolation = node_c.interpolation
                        pos_1 = node_c.elements[0].position
                        color_1 = node_c.elements[0].color
                        pos_2 = node_c.elements[1].position
                        color_2 = node_c.elements[1].color
                        num_elements = len(node_c.elements)
                        # Check if ColorRamp has more than two color stops
                        if num_elements >= 2:
                            # Check if LuxCore ColorRamp node already exists
                            Luxcore_colorramp_exists = False
                            if hasattr(Luxcore_nd, 'nodes'):
                                for node1 in Luxcore_nd.nodes:
                                    if "ColorRampLux" in node1.name and node1.name.endswith(val_to_rgb_node.name.split(".")[-1]):
                                        ColorRampLux = node1
                                        Luxcore_colorramp_exists = True
                                        break
                            # If LuxCore ColorRamp node doesn't exist, create one
                            if not Luxcore_colorramp_exists:
                                bpy.context.object.active_material.luxcore.use_cycles_nodes = False
                                ColorRampLux = lux_obj['lux_nodes'].new("LuxCoreNodeTexBand")
                                ColorRampLux.name = "ColorRampLux." + val_to_rgb_node.name.split(".")[-1]
                                ColorRampLux.location = Color_ramp_location
                                ColorRampLux.interpolation = interpolation_map.get(cycles_interpolation, 'none')
                                #counter += 1
                            ColorRampLux.ramp_items[0].offset = pos_1
                            ColorRampLux.ramp_items[0].value = (color_1[0], color_1[1], color_1[2])
                            ColorRampLux.ramp_items[1].offset = pos_2
                            ColorRampLux.ramp_items[1].value = (color_2[0], color_2[1], color_2[2])
                            # Add input nodes to LuxCore ColorRamp node for each additional color stop
                            for i in range(2, num_elements):
                                element = node_c.elements[i]
                                ColorRampLux.add_item = False
                                ramp_item = ColorRampLux.ramp_items[-1]
                                ramp_item.offset = element.position
                                ramp_item.value = (element.color[0], element.color[1], element.color[2])
        import os
        # Loop through all materials
        for material in bpy.data.materials:
            # Check if material has a node tree
            if hasattr(material, 'node_tree'):
                # Set active material
                active_material = material
                # Get Cycles node tree
                c_nodes_tree = active_material.node_tree
                # Get LuxCore node tree
                Luxcore_nd = active_material.luxcore.node_tree
                # Check if Cycles node tree has nodes
                if hasattr(c_nodes_tree, 'nodes'):
                    # Get Cycles nodes
                    c_nodes = c_nodes_tree.nodes
                    # Create LuxCore Material node tree
                    tree_name = "Nodes_" + active_material.name
                    # Check if LuxCore Material node tree already exists
                    if active_material.luxcore.node_tree:
                        print("------- Luxcore Material Exists Already !!! --------")
                        node_tree = active_material.luxcore.node_tree
                        lux_nodes = node_tree.nodes
                    else:
                        node_tree = bpy.data.node_groups.new(name=tree_name, type="luxcore_material_nodes")
                        active_material.luxcore.node_tree = node_tree
                        node_tree.use_fake_user = True
                        lux_nodes = node_tree.nodes
                    lux_obj = {'lux_nodes': lux_nodes, 'node_tree': node_tree}
                    counter = 0
                    Cycles_principled_nodes = [node for node in c_nodes_tree.nodes if node.bl_idname.startswith("ShaderNodeBsdfPrincipled")]
                    #print(val_to_rgb_nodes)
                    for Cycles_principled in Cycles_principled_nodes:
                        node_c = Cycles_principled
                        new_shader = Cycles_principled.location
                        new_shader_Base_color = Cycles_principled.inputs[0].default_value
                        new_shader_Base_Subsurface = Cycles_principled.inputs[1].default_value
                        new_shader_Metallic = Cycles_principled.inputs[6].default_value
                        new_shader_Specualar = Cycles_principled.inputs[7].default_value
                        new_shader_Specualar_Tilt = Cycles_principled.inputs[8].default_value
                        new_shader_Roughness = Cycles_principled.inputs[9].default_value
                        new_shader_Anisotropic = Cycles_principled.inputs[10].default_value
                        new_shader_Sheen = Cycles_principled.inputs[12].default_value
                        new_shader_Sheen_tilt = Cycles_principled.inputs[13].default_value
                        new_shader_Clearcoat = Cycles_principled.inputs[14].default_value
                        new_shader_clearcoat_Rougness = Cycles_principled.inputs[15].default_value
                        new_shader_Transmission = Cycles_principled.inputs[17].default_value
                        new_shader_IOR = Cycles_principled.inputs[16].default_value
                        new_shader_opacity = Cycles_principled.inputs[21].default_value
                        if new_shader_Transmission == 0:
                            Disney_shader = False
                            if hasattr(Luxcore_nd, 'nodes'):
                                for node1 in Luxcore_nd.nodes:
                                    if "Disney Material" in node1.name:
                                        Disney = node1
                                        Disney_shader = True
                                        break
                                if not Disney_shader:
                                    bpy.context.object.active_material.luxcore.use_cycles_nodes = False 
                                    Disney = lux_obj['lux_nodes'].new("LuxCoreNodeMatDisney")
                                    Disney.location = new_shader
                                Disney.inputs[0].default_value = (new_shader_Base_color[0], new_shader_Base_color[1], new_shader_Base_color[2]) 
                                Disney.inputs[1].default_value = new_shader_Base_Subsurface
                                Disney.inputs[2].default_value = new_shader_Metallic  
                                Disney.inputs[3].default_value = new_shader_Specualar
                                Disney.inputs[4].default_value = new_shader_Specualar_Tilt
                                Disney.inputs[5].default_value = new_shader_Roughness
                                Disney.inputs[6].default_value = new_shader_Anisotropic
                                Disney.inputs[7].default_value = new_shader_Sheen
                                Disney.inputs[8].default_value = new_shader_Sheen_tilt
                                Disney.inputs[9].default_value = new_shader_Clearcoat
                                Disney.inputs[10].default_value = 1 - new_shader_clearcoat_Rougness
                                Disney.inputs[14].default_value = new_shader_opacity
                                #Luxcore_nd.linksnew 
                        if new_shader_Transmission != 0:
                            Glass_Shader = False
                            if hasattr(Luxcore_nd, 'nodes'):
                                for node_g in Luxcore_nd.nodes:
                                    if "LuxCoreNodeMatGlass" in node_g.bl_idname:
                                        Disney = node_g
                                        Glass_Shader = True
                                        break
                                if not Glass_Shader:
                                    bpy.context.object.active_material.luxcore.use_cycles_nodes = False 
                                    Disney = lux_obj['lux_nodes'].new("LuxCoreNodeMatGlass")
                                    Disney.location = new_shader
                                    Glass_Shader = True
                                    #break
                                Disney.inputs[0].default_value = (new_shader_Base_color[0], new_shader_Base_color[1], new_shader_Base_color[2]) 
                                Disney.inputs[1].default_value = (new_shader_Base_color[0], new_shader_Base_color[1], new_shader_Base_color[2])
                                Disney.inputs[2].default_value = new_shader_IOR
                                if new_shader_Roughness != 0:
                                    Disney.rough = True
                                    Disney.inputs[6].default_value = new_shader_Roughness
                        Luxcore_output = False
                        for node_do in Luxcore_nd.nodes:
                            if "LuxCoreNodeMatOutput" in node_do.bl_idname:
                                LDO = node_do
                                Luxcore_output = True
                                break
                        if not Luxcore_output:
                            LDO = lux_obj['lux_nodes'].new("LuxCoreNodeMatOutput")
                            LDO.location = new_shader.x + 500, new_shader.y -150 
                            Luxcore_output = True
                        if Luxcore_output:    
                            Luxcore_nd.links.new(Disney.outputs[0], LDO.inputs[0])
        import os
        # Loop through all materials
        for material in bpy.data.materials:
            # Check if material has a node tree
            if hasattr(material, 'node_tree'):
                # Set active material
                active_material = material
                # Get Cycles node tree
                c_nodes_tree = active_material.node_tree
                # Get LuxCore node tree
                Luxcore_nd = active_material.luxcore.node_tree
                # Check if Cycles node tree has nodes
                if hasattr(c_nodes_tree, 'nodes'):
                    # Get Cycles nodes
                    c_nodes = c_nodes_tree.nodes
                    # Create LuxCore Material node tree
                    tree_name = "Nodes_" + active_material.name
                    # Check if LuxCore Material node tree already exists
                    if active_material.luxcore.node_tree:
                        print("------- Luxcore Material Exists Already !!! --------")
                        node_tree = active_material.luxcore.node_tree
                        lux_nodes = node_tree.nodes
                    else:
                        node_tree = bpy.data.node_groups.new(name=tree_name, type="luxcore_material_nodes")
                        active_material.luxcore.node_tree = node_tree
                        node_tree.use_fake_user = True
                        lux_nodes = node_tree.nodes
                    lux_obj = {'lux_nodes': lux_nodes, 'node_tree': node_tree}
                    counter = 0
                    Cycles_glass_nodes = [node for node in c_nodes_tree.nodes if node.bl_idname.startswith("ShaderNodeBsdfGlass")]
                    #print(val_to_rgb_nodes)
                    for Cycles_Glass in Cycles_glass_nodes:
                        node_c = Cycles_Glass
                        new_glass = Cycles_Glass.location
                        new_glass_Base_color = Cycles_Glass.inputs[0].default_value
                        new_glass_Roughness = Cycles_Glass.inputs[1].default_value
                        new_glass_IOR = Cycles_Glass.inputs[2].default_value
                        Lux_Glass = False
                        if hasattr(Luxcore_nd, 'nodes'):
                            for node1 in Luxcore_nd.nodes:
                                if "LuxCoreNodeMatGlass" in node1.bl_idname:
                                    Glass = node1
                                    Lux_Glass = True
                                    break
                            if not Lux_Glass:
                                bpy.context.object.active_material.luxcore.use_cycles_nodes = False 
                                Glass = lux_obj['lux_nodes'].new("LuxCoreNodeMatGlass")
                                Glass.location = new_glass
                            Glass.inputs[0].default_value = (new_glass_Base_color[0], new_glass_Base_color[1], new_glass_Base_color[2]) 
                            Glass.inputs[1].default_value = (new_glass_Base_color[0], new_glass_Base_color[1], new_glass_Base_color[2])
                            Glass.inputs[2].default_value = new_glass_IOR
                            if new_glass_Roughness != 0:
                                Glass.rough = True
                                Glass.inputs[6].default_value = new_glass_Roughness
                            Luxcore_output = False
                            for node_do in Luxcore_nd.nodes:
                                if "LuxCoreNodeMatOutput" in node_do.bl_idname:
                                    LDO = node_do
                                    Luxcore_output = True
                                    break
                            if not Luxcore_output:
                                LDO = lux_obj['lux_nodes'].new("LuxCoreNodeMatOutput")
                                LDO.location = new_glass.x + 500, new_glass.y -150 
                            #Luxcore_nd.linksnew 
                            Luxcore_nd.links.new(Glass.outputs[0], LDO.inputs[0])    
        import os
        # Loop through all materials
        for material in bpy.data.materials:
            # Check if material has a node tree
            if hasattr(material, 'node_tree'):
                # Set active material
                active_material = material
                # Get Cycles node tree
                c_nodes_tree = active_material.node_tree
                # Get LuxCore node tree
                Luxcore_nd = active_material.luxcore.node_tree
                # Check if Cycles node tree has nodes
                if hasattr(c_nodes_tree, 'nodes'):
                    # Get Cycles nodes
                    c_nodes = c_nodes_tree.nodes
                    # Create LuxCore Material node tree
                    tree_name = "Nodes_" + active_material.name
                    # Check if LuxCore Material node tree already exists
                    if active_material.luxcore.node_tree:
                        print("------- Luxcore Material Exists Already !!! --------")
                        node_tree = active_material.luxcore.node_tree
                        lux_nodes = node_tree.nodes
                    else:
                        node_tree = bpy.data.node_groups.new(name=tree_name, type="luxcore_material_nodes")
                        active_material.luxcore.node_tree = node_tree
                        node_tree.use_fake_user = True
                        lux_nodes = node_tree.nodes
                    lux_obj = {'lux_nodes': lux_nodes, 'node_tree': node_tree}
                    counter = 0
                    Cycles_blackbody_nodes = [node for node in c_nodes_tree.nodes if node.bl_idname.startswith("ShaderNodeBlackbody")]        
                    Cycles_emission_nodes = [node for node in c_nodes_tree.nodes if node.bl_idname.startswith("ShaderNodeEmission")]
                    #print(val_to_rgb_nodes)
                    for Cycles_emission in Cycles_emission_nodes:
                        node_c = Cycles_emission
                        new_emision = Cycles_emission.location
                        new_emission_Base_color = Cycles_emission.inputs[0].default_value
                        new_emission_Strength = Cycles_emission.inputs[1].default_value
                        Lux_mate = False
                        if hasattr(Luxcore_nd, 'nodes'):
                            for node1 in Luxcore_nd.nodes:
                                if "LuxCoreNodeMatMatte" in node1.bl_idname:
                                    Matte = node1
                                    Lux_mate = True
                                    break
                            if not Lux_mate:
                                bpy.context.object.active_material.luxcore.use_cycles_nodes = False 
                                Matte = lux_obj['lux_nodes'].new("LuxCoreNodeMatMatte")
                                Matte.location = new_emision
                                Lux_mate = True
                            if Lux_mate:
                                Emission_exist = False
                                for node2 in Luxcore_nd.nodes:
                                    if "LuxCoreNodeMatEmission" in node2.bl_idname:
                                        new_light = node2
                                        Emission_exist = True
                                        break
                                if not Emission_exist:
                                    new_light = lux_obj['lux_nodes'].new("LuxCoreNodeMatEmission")
                                    new_light.location =  new_emision.y -300, new_emision.x -200
                                    Emission_exist = True
                                if Emission_exist:            
                                    new_light.gain = new_emission_Strength
                                    new_light.inputs[0].default_value = (new_emission_Base_color[0], new_emission_Base_color[1], new_emission_Base_color[2])
                                Luxcore_output = False
                                for node_do in Luxcore_nd.nodes:
                                    if "LuxCoreNodeMatOutput" in node_do.bl_idname:
                                        LDO = node_do
                                        Luxcore_output = True
                                        break
                                if not Luxcore_output:
                                    LDO = lux_obj['lux_nodes'].new("LuxCoreNodeMatOutput")
                                    LDO.location = new_emision.x + 300, new_emision.y -150 
                                Luxcore_nd.links.new(new_light.outputs[0], Matte.inputs[4])
                                Luxcore_nd.links.new(Matte.outputs[0], LDO.inputs[0])
                    for Cycles_blackbody in Cycles_blackbody_nodes:
                        node_bb = Cycles_blackbody
                        new_bb = Cycles_blackbody.inputs[0].default_value
                        bb = Cycles_blackbody.location
                        Luxcore_BB = False
                        for nodelb in Luxcore_nd.nodes:
                            if "LuxCoreNodeTexBlackbody" in nodelb.bl_idname:
                                new_lb = nodelb
                                Luxcore_BB = True
                                break
                        if not Luxcore_BB:
                            new_lb = lux_obj['lux_nodes'].new("LuxCoreNodeTexBlackbody")
                            new_lb.location = bb
                            Luxcore_BB = True
                                #break
                        if Luxcore_BB:
                            for node_emi in Luxcore_nd.nodes:
                                if "LuxCoreNodeMatEmission" in node_emi.bl_idname:
                                    new_emi = node_emi    
                                    new_lb.temperature = new_bb   
                        Luxcore_nd.links.new(new_lb.outputs[0], new_emi.inputs[0])
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Fabrics_inputs = bpy.context.window_manager.Cloth_textures.split(",")
        Nazwy_Luxcore_mat =("Disney Material", "Matte Material", "Carpaint Material", "Glass Material", "Cloth Material", "Mix Material", "Velvet Material", "Glossy Translucent Material", "Glossy Material", "Metal Material", "Mirror Material")
        for mat_disney in bpy.data.materials:
            if "luxcore" in mat_disney:
                node_group_disney = mat_disney.luxcore.node_tree
                if node_group_disney:
                    Dinsey_use_exist = False
                    Any_Material_exists = False
                    for node_material in node_group_disney.nodes:
                        for Material in Nazwy_Luxcore_mat:
                            if Material in node_material.name:
                                #if not "LuxCoreNodeMatDisney" in node_material.bl_idname:
                                print(node_material.name)
                                Any_Material_exists = True
                                break
                    if not Any_Material_exists:
                        for node in node_group_disney.nodes:
                            #material_exists = False
                            material__Disney_exists = False
                            for node0 in node_group_disney.nodes:
                                #for Material in Nazwy_Luxcore_mat:                
                                    #if Material in node0.name:
                                if "LuxCoreNodeMatDisney" in node0.bl_idname:
                                    new_node = node0
                                    material__Disney_exists = True
                                    break
                                #else:                         
                                    #print(Material)
                                    #node_group_disney.nodes.remove(node0)
                                    #material__Disney_exists = False
                                #break
                                #print(node.name)
                                if not material__Disney_exists:
                                    new_node = node_group_disney.nodes.new(type="LuxCoreNodeMatDisney")
                                    new_node.use_transform = True
                                    new_node.location = 400,-600
                                    material__Disney_exists= True
                                    break
                            output_exists = False
                            for node2 in node_group_disney.nodes:
                                if "LuxCoreNodeMatOutput" in node2.bl_idname:
                                    new_output = node2
                                    output_exists = True
                                    break
                            if not output_exists:
                                    new_output = node_group_disney.nodes.new(type="LuxCoreNodeMatOutput")
                                    new_output.use_transform = True
                                    new_output.name = "Luxcore_Output"
                                    new_output.location = 800,-800
                            node_group_disney.links.new(new_node.outputs[0], new_output.inputs[0])
                            Dinsey_use_exist=True
                            break
                    if Dinsey_use_exist:
                        for node in node_group_disney.nodes:
                            #print("tutaj_jestem")    
                            if "LuxCoreNodeMatDisney" in node.bl_idname:
                                group_inputs_Disney = [node.inputs[i] for i in range(len(node.inputs))]
                                for node_A in node_group_disney.nodes:
                                    for tekstura in Albedo:
                                        if tekstura.lower() in node_A.label.lower():
                                            node_group_disney.links.new(node_A.outputs[0], group_inputs_Disney[0])
                                for node_B in node_group_disney.nodes:
                                    for reflect in Reflection:
                                        if reflect.lower() in node_B.label.lower():
                                            node_group_disney.links.new(node_B.outputs[0], group_inputs_Disney[3])
                                for node in node_group_disney.nodes:       
                                        for Roug in RGH:
                                            if Roug.lower() in node.label.lower():
                                                Rough_new = node
                                                print(Rough_new)
                                                node_group_disney.links.new(Rough_new.outputs[0], group_inputs_Disney[5])
                                                for node in node_group_disney.nodes:
                                                    if "gloss" in node.label.lower():
                                                        Invert = False
                                                        for node in node_group_disney.nodes:
                                                            if "Invert_Luxcore" in node.name:
                                                                Invert_node = node
                                                                Invert = True
                                                                break
                                                        if not Invert:
                                                            Invert_node = node_group_disney.nodes.new(type="LuxCoreNodeTexInvert")
                                                            Invert_node.name = "Invert_Luxcore"                                            
                                                            Invert_node.use_transform = True
                                                            Invert_node.location = 200,-700
                                                        #print("Outputs invert to:",new_gloss.outputs)
                                                        node_group_disney.links.new(Invert_node.outputs[0], group_inputs_Disney[5])
                                                        node_group_disney.links.new(Rough_new.outputs[0], Invert_node.inputs[0])
                                                    Invert = True
                                                if Roug.lower() in node.label.lower():
                                                    if "gloss" not in node.label.lower():
                                                        for node_inv in node_group_disney.nodes:
                                                            if "Invert_Luxcore" in node_inv.name:
                                                                node_group_disney.nodes.remove(node_inv)
                                                               # break
                                #Podlaczenie Opacity:
                                for node_do in node_group_disney.nodes:       
                                    for Maska in Opacity:
                                        if Maska.lower() in node_do.label.lower():
                                            #print("Tekstura Opacity to:",node.label)
                                            node_group_disney.links.new(node_do.outputs[0], group_inputs_Disney[14])
                                Use_disney_normal = False
                                for node_nd in node_group_disney.nodes:
                                    for Normalki in Normal_names:
                                        if Normalki.lower() in node_nd.label.lower():
                                            if "Normal/Map" not in node_nd.label:
                                                node_nd.is_normal_map = True
                                                node_group_disney.links.new(node_nd.outputs[2], group_inputs_Disney[15])
                                                #node.is_normal_map = True
                                                Use_disney_normal = True
                                                for node_DB in node_group_disney.nodes:
                                                    if "LuxCoreNodeTexBump" in node_DB.bl_idname:
                                                        #print(node.name)
                                                       node_group_disney.nodes.remove(node_DB)
                                                break
                                    if not Use_disney_normal:
                                        for node_db in node_group_disney.nodes:
                                            for Bumpik in Bumps_maps:
                                                if Bumpik.lower() in node_db.label.lower():
                                                    #node_group_disney.links.new(nodeb.outputs[0], group_inputs_Trans[15])
                                                    Bum_Exists = False
                                                    for node_bump in node_group_disney.nodes:
                                                        if "LuxCoreNodeTexBump" in node_bump.bl_idname:
                                                            new_node_bump = node_bump
                                                            Bum_Exists = True
                                                            break
                                                    if not Bum_Exists:
                                                        new_node_bump = node_group_disney.nodes.new(type="LuxCoreNodeTexBump")
                                                        new_node_bump.use_transform = True
                                                        new_node_bump.name = "Luxcore_Bump"
                                                        new_node_bump.location = 150,-1000
                                                    node_group_disney.links.new(node_db.outputs[0], new_node_bump.inputs[0])
                                                    node_group_disney.links.new(new_node_bump.outputs[0], group_inputs_Disney[15])                
        #Podlaczenie Transmission:
        for material_trans in bpy.data.materials:
            if "luxcore" in material_trans:
                node_group_trans = material_trans.luxcore.node_tree
                if node_group_trans:
                    for node_trans in node_group_trans.nodes:
                        for Trans_tex in Trans:
                             if (Trans_tex.lower() in node_trans.label.lower()) and ('cycles' not in node_trans.label.lower()) and ('octane' not in node_trans.label.lower()):
                                #print("Wykrywam:", node_trans.name, "Tekstura:", node_trans.label, "Material:", node_group_trans.name)
                                #print("Wykrywam:", node_trans.name, "Tekstura:", node_trans.label)
                                material_exists_Trans = False
                                for node1 in node_group_trans.nodes:
                                    print(node1.name)
                                    for Materialy_tex in Nazwy_Luxcore_mat:
                                        #print(Nazwy_Luxcore_mat)
                                        if Materialy_tex in node1.name:
                                            if "LuxCoreNodeMatGlossyTranslucent" in node1.bl_idname:
                                                new_node_trans = node1
                                                material_exists_Trans = True
                                                break
                                            else:
                                                node_group_trans.nodes.remove(node1)
                                                material_exists_Trans = False
                                            if not material_exists_Trans:
                                                new_node_trans = node_group_trans.nodes.new(type="LuxCoreNodeMatGlossyTranslucent")
                                                new_node_trans.use_transform = True
                                                new_node_trans.location = 400, -600
                                                material_exists_Trans = True
                                                break
                                output_exist = False
                                for node2 in node_group_trans.nodes:
                                    if "Luxcore_Output" in node2.name:
                                        new_output_trans = node2
                                        output_exist = True
                                        break
                                if not output_exist:
                                    new_output_trans = node_group_trans.nodes.new(type="LuxCoreNodeMatOutput")
                                    new_output_trans.use_transform = True
                                    new_output_trans.name = "Luxcore_Output"
                                    new_output_trans.location = 800, -800
                                #Bump_exist = False
                                #for node3 in node_group_trans.nodes:
                                    #if "Luxcore_Bump" in node3.name:
                                       # new_node_bump = node3
                                        #Bump_exist = True
                                        #break
                                #if not Bump_exist:
                                    #new_node_bump = node_group_trans.nodes.new(type="LuxCoreNodeTexBump")
                                    #new_node_bump.use_transform = True
                                    #new_node_bump.name = "Luxcore_Bump"
                                    #new_node_bump.location = 150, -1000
                                node_group_trans.links.new(new_node_trans.outputs[0], new_output_trans.inputs[0])
                                #node_group_trans.links.new(new_node.inputs[15], new_node_bump.outputs[0])
                                #break
                                if material_exists_Trans:
                                    for node_trans_new in node_group_trans.nodes:
                                        if "LuxCoreNodeMatGlossyTranslucent" in node_trans_new.name:
                                            Trans_mat_inputs = [node_trans_new.inputs[i] for i in range(len(node_trans_new.inputs))]
                                            node_trans_new.use_ior = True
                                            for nod_x in node_group_trans.nodes:
                                                if "Luxcore_HSV_trans" in nod_x.name:
                                                    node_group_trans.nodes.remove(nod_x)
                                                if (Trans_tex.lower() in node_trans.label.lower()) and ('cycles' not in node_trans.label.lower()) and ('octane' not in node_trans.label.lower()):
                                                    node_group_trans.links.new(node_trans.outputs[0], Trans_mat_inputs[1])
                                                    for node in node_group_trans.nodes:
                                                        for tekstura in Albedo:
                                                            #print("To jest Twoje Albedo:", Albedo)
                                                            if tekstura.lower() in node.label.lower():
                                                                print("tekstura to:",node.label)
                                                                node_group_trans.links.new(node.outputs[0], Trans_mat_inputs[0])
                                                                if "petal" in node.label.lower():
                                                                    node.brightness = 0.2
                                                        for reflection_tex in Reflection:
                                                            if reflection_tex.lower() in node.label.lower():
                                                                node_group_trans.links.new(node.outputs[0], Trans_mat_inputs[2])
                                                                #break
                                                        for Tekstura_RGH in RGH:
                                                            if Tekstura_RGH.lower() in node.label.lower():
                                                                #new_node.rough = True
                                                                node_rough = node
                                                                node_group_trans.links.new(node_rough.outputs[0], Trans_mat_inputs[6])
                                                                if "gloss" in node.label.lower():
                                                                    Invert = False
                                                                    for node in node_group_trans.nodes:
                                                                        if "Invert_Luxcore" in node.name:
                                                                            invert_node = node
                                                                            Invert= True
                                                                            break
                                                                    if not Invert:
                                                                        invert_node = node_group_trans.nodes.new(type="LuxCoreNodeTexInvert")
                                                                        invert_node.use_transform = True
                                                                        invert_node.name = "Invert_Luxcore"
                                                                        invert_node.location = 200, -600
                                                                    node_group_trans.links.new(invert_node.outputs[0], Trans_mat_inputs[6])
                                                                    node_group_trans.links.new(node_rough.outputs[0], invert_node.inputs[0])
                                                                Invert = True
                                                                #break
                                                            if Tekstura_RGH.lower() in node.label.lower():
                                                                if "gloss" not in node.label.lower():
                                                                    for node_inv in node_group_trans.nodes:
                                                                        #new_node.rough = True
                                                                        if "Invert_Luxcore" in node_inv.name:
                                                                            node_group_trans.nodes.remove(node_inv)
                                                                            break
                                                        for tekstura_o in Opacity:
                                                            if tekstura_o.lower() in node.label.lower():
                                                                node_o = node
                                                                node_group_trans.links.new(node_o.outputs[0], Trans_mat_inputs[14])
                                                        use_trans_normal = False
                                                        for node_tn in node_group_trans.nodes:
                                                            for Normalki in Normal_names:
                                                                if Normalki.lower() in node_tn.label.lower():
                                                                    if "Normal/Map" not in node_tn.label:
                                                                        node_tn.is_normal_map = True
                                                                        node_group_trans.links.new(node_tn.outputs[2], Trans_mat_inputs[15])
                                                                        #node.is_normal_map = True
                                                                        use_trans_normal = True
                                                                        for node_TB in node_group_trans.nodes:
                                                                            if "Luxcore_Bump" in node_TB.name:
                                                                                #print(node.name)
                                                                               node_group_trans.nodes.remove(node_TB)
                                                                        break
                                                            if not use_trans_normal:
                                                                for node_tb in node_group_trans.nodes:
                                                                    for Bumpik in Bumps_maps:
                                                                        if Bumpik.lower() in node_tb.label.lower():
                                                                            #node_group_trans.links.new(nodeb.outputs[0], group_inputs_Trans[15])
                                                                            Bum_Exists = False
                                                                            for node_trans_bump in node_group_trans.nodes:
                                                                                if "LuxCoreNodeTexBump" in node_trans_bump.bl_idname:
                                                                                    new_trans_node_bump = node_trans_bump
                                                                                    Bum_Exists = True
                                                                                    break
                                                                            if not Bum_Exists:
                                                                                new_trans_node_bump = node_group_trans.nodes.new(type="LuxCoreNodeTexBump")
                                                                                new_trans_node_bump.use_transform = True
                                                                                new_trans_node_bump.name = "Luxcore_Bump"
                                                                                new_trans_node_bump.location = 150,-1000
                                                                            node_group_trans.links.new(node_tb.outputs[0], new_trans_node_bump.inputs[0])
                                                                            node_group_trans.links.new(new_trans_node_bump.outputs[0], Trans_mat_inputs[15])      
        #Podlaczenie Glass:
        for Drzewo_Glass in bpy.data.materials:
            if "luxcore" in Drzewo_Glass: 
                node_group_glass = Drzewo_Glass.luxcore.node_tree
                if node_group_glass:        
                    for node_glass in node_group_glass.nodes:
                        for glass_text in szklo:
                            if (glass_text.lower() in node_glass.label.lower()) and ('cycles' not in node_glass.label.lower()) and ('octane' not in node_glass.label.lower()):
                                material_exists_glass = False
                                for node1g in node_group_glass.nodes:
                                    #print(node1.name)
                                    for Materialy_tex in Nazwy_Luxcore_mat:
                                        #print(Nazwy_Luxcore_mat)
                                        if Materialy_tex in node1g.name:
                                            if "LuxCoreNodeMatGlass" in node1g.bl_idname:
                                                new_node_glass = node1g
                                                material_exists_glass = True
                                                break
                                            else:
                                                node_group_glass.nodes.remove(node1g)
                                                material_exists_glass = False
                                            if not material_exists_glass:
                                                new_node_glass = node_group_glass.nodes.new(type="LuxCoreNodeMatGlass")
                                                new_node_glass.label = "Lux_glass"
                                                new_node_glass.use_transform = True
                                                new_node_glass.location = 400, -600 
                                                material_exists_glass = True   
                                                break
                                output_glass_exist = False
                                for node2g in node_group_glass.nodes:
                                    if "LuxCoreNodeMatOutput" in node2g.name:
                                        new_output_glass = node2g
                                        output_glass_exist = True
                                        break
                                if not output_glass_exist:
                                    new_output_glass = node_group_glass.nodes.new(type="LuxCoreNodeMatOutput")
                                    new_output_glass.use_transform = True
                                    new_output_glass.location = 800, -800
                                    output_glass_exist = True
                                node_group_glass.links.new(new_node_glass.outputs[0], new_output_glass.inputs[0])
                                    #node_group_glass.links.new(new_node.inputs[9], new_node_bump.outputs[0])
                                if material_exists_glass:
                                    for node_gg in node_group_glass.nodes:
                                        if "LuxCoreNodeMatGlass" in node_gg.bl_idname:
                                            group_inputs_glass = [node_gg.inputs[i] for i in range(len(node_gg.inputs))]
                                            for node_AG in node_group_glass.nodes:
                                                for Tekstura_glass_albedo in Albedo:
                                                    if Tekstura_glass_albedo.lower() in node_AG.label.lower():
                                                        node_group_glass.links.new(node_AG.outputs[0], group_inputs_glass[0])
                                            for node_RG in node_group_glass.nodes:            
                                                for reflection_tex in Reflection:
                                                    if reflection_tex.lower() in node_RG.label.lower():
                                                        node_group_glass.links.new(node_RG.outputs[0], group_inputs_glass[1])
                                            for node_RR in node_group_glass.nodes:        
                                                for Tekstura_RGH in RGH:
                                                    if Tekstura_RGH.lower() in node_RR.label.lower():
                                                        node_gg.rough = True
                                                        node_rough = node_RR
                                                        node_group_glass.links.new(node_rough.outputs[0], group_inputs_glass[6])
                                                        if "gloss" in node.label.lower():
                                                            Invert = False
                                                            for node in node_group_glass.nodes:
                                                                if "Invert_Luxcore" in node.name:
                                                                    invert_node = node
                                                                    Invert= True
                                                                    break
                                                            if not Invert:
                                                                invert_node = node_group_glass.nodes.new(type="LuxCoreNodeTexInvert")
                                                                invert_node.use_transform = True
                                                                invert_node.name = "Invert_Luxcore"
                                                                invert_node.location = 200, -600
                                                            node_group_glass.links.new(invert_node.outputs[0], group_inputs_glass[6])
                                                            node_group_glass.links.new(node_rough.outputs[0], invert_node.inputs[0])
                                                        Invert = True
                                                        #break
                                                    if Tekstura_RGH.lower() in node_RR.label.lower():
                                                        if "gloss" not in node_RR.label.lower():
                                                            for node_inv in node_group_glass.nodes:
                                                                new_node.rough = True
                                                                if "Invert_Luxcore" in node_inv.name:
                                                                    node_group_glass.nodes.remove(node_inv)
                                                                    break
                                            #Podlaczanie Bump/Normal:
                                            use_glass_normal = False
                                            for node_gn in node_group_glass.nodes:
                                                for Normalki in Normal_names:
                                                    if Normalki.lower() in node_gn.label.lower():
                                                        if "Normal/Map" not in node_gn.label:
                                                            node_gn.is_normal_map = True
                                                            node_group_glass.links.new(node_gn.outputs[2], group_inputs_glass[9])
                                                            #node.is_normal_map = True
                                                            use_glass_normal = True
                                                            for node_GB in node_group_glass.nodes:
                                                                if "LuxCoreNodeTexBump" in node_GB.bl_idname:
                                                                    #print(node.name)
                                                                   node_group_glass.nodes.remove(node_GB)
                                                            break
                                                if not use_glass_normal:
                                                    for node_gb in node_group_glass.nodes:
                                                        for Bumpik in Bumps_maps:
                                                            if Bumpik.lower() in node_gb.label.lower():
                                                                #node_group_glass.links.new(node_gb.outputs[0], group_inputs_Trans[15])
                                                                Bum_Exists = False
                                                                for node_bump in node_group_glass.nodes:
                                                                    if "LuxCoreNodeTexBump" in node_bump.bl_idname:
                                                                        new_node_bump = node_bump
                                                                        Bum_Exists = True
                                                                        break
                                                                if not Bum_Exists:
                                                                    new_node_bump = node_group_glass.nodes.new(type="LuxCoreNodeTexBump")
                                                                    new_node_bump.use_transform = True
                                                                    new_node_bump.name = "Luxcore_Bump"
                                                                    new_node_bump.location = 150,-1000
                                                                node_group_glass.links.new(node_gb.outputs[0], new_node_bump.inputs[0])
                                                                node_group_glass.links.new(new_node_bump.outputs[0], group_inputs_glass[9])
                                            #Podlaczenie Opacity:
                                            for node_go in node_group_glass.nodes:       
                                                for Maska in Opacity:
                                                    if Maska.lower() in node_go.label.lower():
                                                        #print("Tekstura Opacity to:",node.label)
                                                        node_group_glass.links.new(node_go.outputs[0], group_inputs_glass[8])
        #Podlaczenie Metal
        for Drzewo_metal in bpy.data.materials:
            if "luxcore" in Drzewo_metal:
                node_group_metal = Drzewo_metal.luxcore.node_tree
                if node_group_metal:
                    for node_metal in node_group_metal.nodes:
                        for metal_text in Metal:
                            if (metal_text.lower() in node_metal.label.lower()) and ('cycles' not in node_metal.label.lower()) and ('octane' not in node_metal.label.lower()):
                                #print("Wykrywam:", node_metal.name, "Tekstura:", node_metal.label)
                                material_metal_exists = False
                                for node_m1 in node_group_metal.nodes:
                                    #print(node_m1.name)
                                    for Materialy_tex in Nazwy_Luxcore_mat:
                                        #print(Nazwy_Luxcore_mat)
                                        if Materialy_tex in node_m1.name:
                                            if "LuxCoreNodeMatMetal" in node_m1.bl_idname:
                                                new_metal_node = node_m1
                                                material_metal_exists = True
                                                break
                                            else:
                                                node_group_metal.nodes.remove(node_m1)
                                                material_metal_exists = False
                                            if not material_metal_exists:
                                                new_metal_node = node_group_metal.nodes.new(type="LuxCoreNodeMatMetal")
                                                new_metal_node.use_transform = True
                                                new_metal_node.location = 400, -600
                                                material_metal_exists = True
                                                break
                                output_metal_exist = False
                                for node2 in node_group_metal.nodes:
                                    if "Luxcore_Output" in node2.name:
                                        metal_output = node2
                                        output_metal_exist = True
                                        break
                                if not output_metal_exist:
                                    metal_output = node_group_metal.nodes.new(type="LuxCoreNodeMatOutput")
                                    metal_output.use_transform = True
                                    metal_output.name = "Luxcore_Output"
                                    metal_output.location = 800, -800
                                    output_metal_exist = True
                                node_group_metal.links.new(new_metal_node.outputs[0], metal_output.inputs[0])
                                    #node_group_metal.links.new(new_node.inputs[5], new_node_bump.outputs[0])
                                #break
                                if material_metal_exists:
                                    for node_mn in node_group_metal.nodes:
                                        if  "LuxCoreNodeMatMetal" in node_mn.bl_idname:
                                            new_metal_shader = node_mn
                                            for node_A in node_group_metal.nodes:
                                                for tekstura in Albedo:
                                                    if tekstura.lower() in node_A.label.lower():
                                                        node_group_metal.links.new(node_A.outputs[0], node_mn.inputs[0])
                                            for node_R in node_group_metal.nodes:
                                                for reflect in Reflection:
                                                    if reflect.lower() in node_R.label.lower():
                                                        node_group_metal.links.new(node_R.outputs[0], node_mn.inputs[0])
                                                        node_R.gamma = 2.2
                                            for node in node_group_metal.nodes:       
                                                    for Roug in RGH:
                                                        if Roug.lower() in node.label.lower():
                                                            Rough_new = node
                                                            print(Rough_new)
                                                            node_group_metal.links.new(Rough_new.outputs[0], node_mn.inputs[2])
                                                            for node in node_group_metal.nodes:
                                                                if "gloss" in node.label.lower():
                                                                    Invert = False
                                                                    for node in node_group_metal.nodes:
                                                                        if "Invert_Luxcore" in node.name:
                                                                            Invert_node = node
                                                                            Invert = True
                                                                            break
                                                                    if not Invert:
                                                                        Invert_node = node_group_metal.nodes.new(type="LuxCoreNodeTexInvert")
                                                                        Invert_node.name = "Invert_Luxcore"                                            
                                                                        Invert_node.use_transform = True
                                                                        Invert_node.location = 200,-700
                                                                    #print("Outputs invert to:",new_gloss.outputs)
                                                                    node_group_metal.links.new(Invert_node.outputs[0], node_mn.inputs[2])
                                                                    node_group_metal.links.new(Rough_new.outputs[0], Invert_node.inputs[0])
                                                                    Invert = True
                                                            if Roug.lower() in node.label.lower():
                                                                if "gloss" not in node.label.lower():
                                                                    for node_inv in node_group_metal.nodes:
                                                                        if "Invert_Luxcore" in node_inv.name:
                                                                            node_group_metal.nodes.remove(node_inv)
                                            #Podlaczanie Bump/Normal:
                                            use_metal_normal = False
                                            for noden in node_group_metal.nodes:
                                                for Normalki in Normal_names:
                                                    if Normalki.lower() in noden.label.lower():
                                                        if "Normal/Map" not in noden.label:
                                                            noden.is_normal_map = True
                                                            node_group_metal.links.new(noden.outputs[2], node_mn.inputs[5])
                                                            #node.is_normal_map = True
                                                            use_metal_normal = True
                                                            for node_LB in node_group_metal.nodes:
                                                                if "LuxCoreNodeTexBump" in node_LB.bl_idname:
                                                                    #print(node.name)
                                                                   node_group_metal.nodes.remove(node_LB)
                                                            break
                                                if not use_metal_normal:
                                                    for nodeb in node_group_metal.nodes:
                                                        for Bumpik in Bumps_maps:
                                                            if Bumpik.lower() in nodeb.label.lower():
                                                                #node_group_metal.links.new(nodeb.outputs[0], group_inputs_Trans[15])
                                                                Bum_Exists = False
                                                                for node_bump in node_group_metal.nodes:
                                                                    if "LuxCoreNodeTexBump" in node_bump.bl_idname:
                                                                        new_node_bump = node_bump
                                                                        Bum_Exists = True
                                                                        break
                                                                if not Bum_Exists:
                                                                    new_node_bump = node_group_metal.nodes.new(type="LuxCoreNodeTexBump")
                                                                    new_node_bump.use_transform = True
                                                                    new_node_bump.location = 150,-1000
                                                                node_group_metal.links.new(nodeb.outputs[0], new_node_bump.inputs[0])
                                                                node_group_metal.links.new(new_node_bump.outputs[0], node_mn.inputs[5])                                
                                            #Podlaczenie Opacity:
                                            for node_mo in node_group_metal.nodes:       
                                                for Maska in Opacity:
                                                    if Maska.lower() in node_mo.label.lower():
                                                        #print("Tekstura Opacity to:",node.label)
                                                        node_group_metal.links.new(node_mo.outputs[0], node_mn.inputs[4])
        #Podlaczanie Cloth:
        for Drzewo_Cloth in bpy.data.materials:
            if "luxcore" in Drzewo_Cloth:
                node_group_cloth = Drzewo_Cloth.luxcore.node_tree
                if node_group_cloth:
                    for node_cloth in node_group_cloth.nodes:
                        for cloth_texture in Fabrics_inputs:
                            if (cloth_texture.lower() in node_cloth.label.lower()) and ('cycles' not in node_cloth.label.lower()) and ('octane' not in node_cloth.label.lower()):
                                #print("Wykrywam:", node_metal.name, "Tekstura:", node_metal.label)
                                material_cloth_exists = False
                                for node0 in node_group_cloth.nodes:
                                    for Material in Nazwy_Luxcore_mat:                
                                        if Material in node0.name:
                                            if "LuxCoreNodeMatCloth" in node0.bl_idname:
                                                new_node = node0
                                                material_cloth_exists = True
                                                break
                                            else:
                                                node_group_cloth.nodes.remove(node0)
                                                material_cloth_exists = False
                                            #break
                                            #print(node.name)
                                            if not material_cloth_exists:
                                                new_node = node_group_cloth.nodes.new(type="LuxCoreNodeMatCloth")
                                                new_node.use_transform = True
                                                new_node.preset = 'cotton_twill'
                                                new_node.location = 400,-600
                                                break
                                output_cloth_exists = False
                                for node2 in node_group_cloth.nodes:
                                    if "LuxCoreNodeMatOutput" in node2.bl_idname:
                                        new_output = node2
                                        output_cloth_exists = True
                                        break
                                if not output_cloth_exists:
                                    new_output = node_group_cloth.nodes.new(type="LuxCoreNodeMatOutput")
                                    new_output.use_transform = True
                                    new_output.name = "Luxcore_Output"
                                    new_output.location = 800,-800
                                    output_cloth_exists = True
                                node_group_cloth.links.new(new_node.outputs[0], new_output.inputs[0])
                                material_cloth_exists = True
                                if material_cloth_exists:
                                    for node in node_group_cloth.nodes:    
                                        if "LuxCoreNodeMatCloth" in node.bl_idname:
                                            group_inputs_cloth = [node.inputs[i] for i in range(len(node.inputs))]
                                            node_cloth = node
                                            for node_A in node_group_cloth.nodes:
                                                for tekstura in Albedo:
                                                    if tekstura.lower() in node_A.label.lower():
                                                        node_group_cloth.links.new(node_A.outputs[0], group_inputs_cloth[0])
                                                        node_group_cloth.links.new(node_A.outputs[0], group_inputs_cloth[2])
                                            for node_R in node_group_cloth.nodes:
                                                for reflect in Reflection:
                                                    if reflect.lower() in node_R.label.lower():
                                                        node_group_cloth.links.new(node_R.outputs[0], group_inputs_cloth[1])
                                                        node_group_cloth.links.new(node_R.outputs[0], group_inputs_cloth[3])
                                                        node_R.gamma = 1
                                            #Podlaczanie Bump/Normal:
                                            use_cloth_normal = False
                                            for noden in node_group_cloth.nodes:
                                                for Normalki in Normal_names:
                                                    if Normalki.lower() in noden.label.lower():
                                                        if "Normal/Map" not in noden.label:
                                                            noden.is_normal_map = True
                                                            node_group_cloth.links.new(noden.outputs[2], group_inputs_cloth[5])
                                                            #node.is_normal_map = True
                                                            use_cloth_normal = True
                                                            for node_LB in node_group_cloth.nodes:
                                                                if "Luxcore_Bump" in node_LB.name:
                                                                    #print(node.name)
                                                                   node_group_cloth.nodes.remove(node_LB)
                                                            break
                                                if not use_cloth_normal:
                                                    for nodeb in node_group_cloth.nodes:
                                                        for Bumpik in Bumps_maps:
                                                            if Bumpik.lower() in nodeb.label.lower():
                                                                #node_group_cloth.links.new(nodeb.outputs[0], group_inputs_cloth[15])
                                                                Bum_Exists = False
                                                                for node_bump in node_group_cloth.nodes:
                                                                    if "LuxCoreNodeTexBump" in node_bump.bl_idname:
                                                                        new_node_bump = node_bump
                                                                        Bum_Exists = True
                                                                        break
                                                                if not Bum_Exists:
                                                                    new_node_bump = node_group_cloth.nodes.new(type="LuxCoreNodeTexBump")
                                                                    new_node_bump.use_transform = True
                                                                    new_node_bump.name = "Luxcore_Bump"
                                                                    new_node_bump.location = 150,-1000
                                                                node_group_cloth.links.new(nodeb.outputs[0], new_node_bump.inputs[0])
                                                                node_group_cloth.links.new(new_node_bump.outputs[0], group_inputs_cloth[5])                                                              
                                            #Podlaczenie Opacity:
                                            for node in node_group_cloth.nodes:       
                                                for Maska in Opacity:
                                                    if Maska.lower() in node.label.lower():
                                                        #print("Tekstura Opacity to:",node.label)
                                                        node_group_cloth.links.new(node.outputs[0], group_inputs_cloth[4])
                                                        #break
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Luxcore_Metals_Creation_7D699(bpy.types.Operator):
    bl_idname = "sna.luxcore_metals_creation_7d699"
    bl_label = "Luxcore_Metals_Creation"
    bl_description = "Creates Metals Materials according to Textures inputs"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Nazwy_Luxcore_mat =("Disney Material", "Matte Material", "Carpaint Material", "Glass Material", "Cloth Material", "Mix Material", "Velvet Material", "Glossy Translucent Material", "Glossy Material", "Metal Material", "Mirror Material")
        active_material = bpy.context.object.active_material
        if not "Dots Stroke" in active_material.name:
            if "luxcore" in active_material:
                node_tree_metal = active_material.luxcore.node_tree
                #print(node_tree.nodes)
                material_metal_exists = False
                for node0 in node_tree_metal.nodes:
                    for Material in Nazwy_Luxcore_mat:                
                        if Material in node0.name:
                            if "LuxCoreNodeMatMetal" in node0.bl_idname:
                                new_node = node0
                                material_metal_exists = True
                            else:
                                node_tree_metal.nodes.remove(node0)
                                material_metal_exists = False
                            #print(node.name)
                            if not material_metal_exists:
                                new_node = node_tree_metal.nodes.new(type="LuxCoreNodeMatMetal")
                                new_node.use_transform = True
                                new_node.location = 400,-600
                                material_metal_exists = True
                                break
                output_exists = False
                for node2 in node_tree_metal.nodes:
                    if "LuxCoreNodeMatOutput" in node2.bl_idname:
                        new_output = node2
                        output_exists = True
                        break
                if not output_exists:
                    new_output = node_tree_metal.nodes.new(type="LuxCoreNodeMatOutput")
                    new_output.use_transform = True
                    new_output.name = "Luxcore_Output"
                    new_output.location = 800,-800
                    output_exists = True
                node_tree_metal.links.new(new_node.outputs[0], new_output.inputs[0])
                if material_metal_exists:
                    for node in node_tree_metal.nodes:    
                        if "LuxCoreNodeMatMetal" in node.bl_idname:
                            group_inputs_metal = [node.inputs[i] for i in range(len(node.inputs))]
                            node_metal = node
                            for node_A in node_tree_metal.nodes:
                                for tekstura in Albedo:
                                    if tekstura.lower() in node_A.label.lower():
                                        node_tree_metal.links.new(node_A.outputs[0], group_inputs_metal[0])
                            for node_R in node_tree_metal.nodes:
                                for reflect in Reflection:
                                    if reflect.lower() in node_R.label.lower():
                                        node_tree_metal.links.new(node_R.outputs[0], group_inputs_metal[0])
                                        node_R.gamma = 2.2
                            for node in node_tree_metal.nodes:       
                                    for Roug in RGH:
                                        if Roug.lower() in node.label.lower():
                                            Rough_new = node
                                            print(Rough_new)
                                            node_tree_metal.links.new(Rough_new.outputs[0], group_inputs_metal[2])
                                            for node in node_tree_metal.nodes:
                                                if "gloss" in node.label.lower():
                                                    Invert = False
                                                    for node in node_tree_metal.nodes:
                                                        if "Invert_Luxcore" in node.name:
                                                            Invert_node = node
                                                            Invert = True
                                                            break
                                                    if not Invert:
                                                        Invert_node = node_tree_metal.nodes.new(type="LuxCoreNodeTexInvert")
                                                        Invert_node.name = "Invert_Luxcore"                                            
                                                        Invert_node.use_transform = True
                                                        Invert_node.location = 200,-700
                                                    #print("Outputs invert to:",new_gloss.outputs)
                                                    node_tree_metal.links.new(Invert_node.outputs[0], group_inputs_metal[2])
                                                    node_tree_metal.links.new(Rough_new.outputs[0], Invert_node.inputs[0])
                                                    Invert = True
                                            if Roug.lower() in node.label.lower():
                                                if "gloss" not in node.label.lower():
                                                    for node_inv in node_group.nodes:
                                                        if "Invert_Luxcore" in node_inv.name:
                                                            node_tree_metal.nodes.remove(node_inv)
                            #Podlaczanie Bump/Normal:
                            use_metal_normal = False
                            for noden in node_tree_metal.nodes:
                                for Normalki in Normal_names:
                                    if Normalki.lower() in noden.label.lower():
                                        if "Normal/Map" not in noden.label:
                                            noden.is_normal_map = True
                                            node_tree_metal.links.new(noden.outputs[2], group_inputs_metal[5])
                                            #node.is_normal_map = True
                                            use_metal_normal = True
                                            for node_LB in node_tree_metal.nodes:
                                                if "LuxCoreNodeTexBump" in node_LB.bl_idname:
                                                    #print(node.name)
                                                   node_tree_metal.nodes.remove(node_LB)
                                            break
                                if not use_metal_normal:
                                    for nodeb in node_tree_metal.nodes:
                                        for Bumpik in Bumps_maps:
                                            if Bumpik.lower() in nodeb.label.lower():
                                                #node_tree_metal.links.new(nodeb.outputs[0], group_inputs_Trans[15])
                                                Bum_Exists = False
                                                for node_bump in node_tree_metal.nodes:
                                                    if "LuxCoreNodeTexBump" in node_bump.bl_idname:
                                                        new_node_bump = node_bump
                                                        Bum_Exists = True
                                                        break
                                                if not Bum_Exists:
                                                    new_node_bump = node_tree_metal.nodes.new(type="LuxCoreNodeTexBump")
                                                    new_node_bump.use_transform = True
                                                    new_node_bump.location = 150,-1000
                                                node_tree_metal.links.new(nodeb.outputs[0], new_node_bump.inputs[0])
                                                node_tree_metal.links.new(new_node_bump.outputs[0], group_inputs_metal[5])                                
                            #Podlaczenie Opacity:
                            for node_mo in node_tree_metal.nodes:       
                                for Maska in Opacity:
                                    if Maska.lower() in node_mo.label.lower():
                                        #print("Tekstura Opacity to:",node.label)
                                        node_tree_metal.links.new(node_mo.outputs[0], group_inputs_metal[4])
                                        #break
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Octane_Trans_84Db7(bpy.types.Operator):
    bl_idname = "sna.octane_trans_84db7"
    bl_label = "Octane_Trans"
    bl_description = "Creates Octane Transmission"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Fabrics_inputs = bpy.context.window_manager.Cloth_textures.split(",")
        protected_materials = [m for m in bpy.data.materials if getattr(m, "protect_octane", False)]
        protected_material_names = [m.name for m in protected_materials]
        # Get the directory of the current blend file
        current_blend_file_dir = os.path.dirname(bpy.data.filepath)
        # Get the path to the tree node file
        #relative_path = os.path.join(current_blend_file_dir, "shaders/Shaders.blend/NodeTree")
        #bpy.ops.wm.append(filename="AM268_001_Octane_Transmission", directory=relative_path)
        #Dodawaniez addonu:
        addon_dir = os.path.dirname(__file__)
        shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        bpy.ops.wm.append(filename="AM268_001_Octane_Transmission", directory=shaders_path)
        # Get the appended tree node group
        tree_node_group = bpy.data.node_groups["AM268_001_Octane_Transmission"]
        # Get the name of the blend file
        blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        new_group_name = blend_file_name[:9]
        # Get the NodeTree to be added to materials
        node_tree = bpy.data.node_groups["AM268_001_Octane_Transmission"]
        # Set the new name of the node tree
        node_tree.name = new_group_name + "_Octane_Transmission"
        active_material = bpy.context.object.active_material
        if not any (name in active_material.name for name in protected_material_names):
            if not "Dots Stroke" in active_material.name:
                nodetree = active_material.node_tree
                if nodetree:
                    for node0 in nodetree.nodes:
                        Material_Octane = False
                        for node1 in nodetree.nodes:
                            if "Octane" in node1.name:
                                if "First_Side" in node1.label:
                                    group_node = node1
                                    Material_Octane = True
                                    break
                                else:
                                    nodetree.nodes.remove(node1)
                                    Material_Octane = False
                                    #break
                        if not Material_Octane:
                            group_node = nodetree.nodes.new("ShaderNodeGroup")
                            group_node.node_tree = node_tree.copy()
                            group_node.name = node_tree.name
                            group_node.label = "First_Side"
                            group_node.inputs[9].default_value = 1
                            group_node.location.x += 1950
                            Octane_out_exist = False
                            for node2 in nodetree.nodes:
                                if "Octane_Output" in node2.label:
                                    output_node = node2
                                    Octane_out_exist = True
                                    break
                            if not Octane_out_exist:
                                output_node = active_material.node_tree.nodes.new("ShaderNodeOutputMaterial")
                                output_node.label = "Octane_Output"
                                output_node.location.x += 2500
                            nodetree.links.new(group_node.outputs[0], output_node.inputs[0])
                            group_node.inputs[9].default_value = 1.0
                            Material_Octane = True
                        #break
                    print("Dotad dzialam")
                    for nodex in nodetree.nodes:
                        if "First_Side" in nodex.label:
                            group_oct_trans = nodex
                            group_oct_trans.inputs[9].default_value = 1
                            for node in nodetree.nodes:
                                if "Octane_Output" in node.label:
                                    out_oct = node
                                    for node in nodetree.nodes:
                                        if node.bl_idname == "OctaneRGBImage":
                                            if "back" in node.image.name.lower() or "front" in node.image.name.lower():
                                                print("moje teksturey to ;", node.image.name)
                                                Back_oct = False
                                                for node_back in nodetree.nodes:
                                                    if "Back_Side" in node_back.label:
                                                       group_node_back = node_back
                                                       Back_oct = True
                                                       break
                                                if not Back_oct:
                                                    group_node_back = nodetree.nodes.new(type='ShaderNodeGroup')
                                                    group_node_back.name = node_tree.name + "_back"
                                                    group_node_back.label = "Back_Side"
                                                    group_node_back.node_tree = node_tree.copy()
                                                    group_node_back.location = 1950, -464
                                                    Back_oct = True
                                                Mix_mat = False
                                                for node1 in nodetree.nodes:
                                                    if "mix_mat_oct" in node1.name:
                                                        node_mix = node1
                                                        Mix_mat = True
                                                        break
                                                if not Mix_mat:
                                                    node_mix = nodetree.nodes.new("OctaneMixMaterial")
                                                    node_mix.name = "mix_mat_oct"
                                                    node_mix.location = 2200, -75
                                                OCT_double = False
                                                for node2 in nodetree.nodes:
                                                    if "Oct_Two_Side" in node2.name:
                                                        oct_2_side = node2
                                                        OCT_double = True
                                                        break
                                                if not OCT_double:
                                                    oct_2_side = nodetree.nodes.new("OctanePolygonSide")
                                                    oct_2_side.name = "Oct_Two_Side"
                                                    oct_2_side.location = 1880, 162
                                                    oct_2_side.inputs[0].default_value = True
                                                nodetree.links.new(node_mix.outputs[0],out_oct.inputs[0])
                                                nodetree.links.new(node_mix.inputs[1],group_oct_trans.outputs[0])
                                                nodetree.links.new(node_mix.inputs[2],group_node_back.outputs[0])
                                                nodetree.links.new(node_mix.inputs[0],oct_2_side.outputs[0])
                                                for node_t in nodetree.nodes:
                                                    if node_t.bl_idname == "OctaneRGBImage":
                                                        for tekstura in Albedo:
                                                            if tekstura.lower() in node_t.image.name.lower() and not "back" in node_t.image.name.lower():
                                                                nodetree.links.new(node_t.outputs[0],group_oct_trans.inputs[0])
                                                                nodetree.links.new(node_t.outputs[0],group_oct_trans.inputs[1])
                                                                print("moja tekstura_diffuse to :", node_t.image.name)
                                                                group_oct_trans.inputs[3].default_value = 1.3
                                                                group_oct_trans.inputs[4].default_value = 0.5
                                                                Albedo_back_exists = False
                                                                for node_t2 in nodetree.nodes:
                                                                    if node_t2.bl_idname == "OctaneRGBImage":
                                                                        for tekstura2 in Albedo:
                                                                            if tekstura2.lower() in node_t2.image.name.lower() and "back" in node_t2.image.name.lower():
                                                                                Albedo_back = node_t2
                                                                                Albedo_back_exists = True
                                                                                break
                                                                if not Albedo_back_exists:
                                                                    Albedo_back = node_t
                                                                nodetree.links.new(Albedo_back.outputs[0],group_node_back.inputs[0])
                                                                nodetree.links.new(Albedo_back.outputs[0],group_node_back.inputs[1])
                                                                group_node_back.inputs[3].default_value = 1.3
                                                                group_node_back.inputs[4].default_value = 0.5
                                                                break                #break
                                                for node_t2 in nodetree.nodes:
                                                    if node_t2.bl_idname == "OctaneRGBImage":
                                                        for tekstur_tr in Trans:
                                                            if tekstur_tr.lower() in node_t2.image.name.lower() and not "back" in node_t2.image.name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[1])
                                                                Transmission_back = False
                                                                for node_t3 in nodetree.nodes:
                                                                    if node_t3.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_tr in Trans:
                                                                            if tekstur_tr.lower() in node_t3.image.name.lower() and "back" in node_t3.image.name.lower():
                                                                                node_trans_back = node_t3
                                                                                Transmission_back = True
                                                                                break
                                                                if not Transmission_back:
                                                                    node_trans_back = node_t2
                                                                nodetree.links.new(node_trans_back.outputs[0], group_node_back.inputs[1])
                                                                group_oct_trans.inputs[3].default_value = 1.0
                                                                group_oct_trans.inputs[4].default_value = 0.0
                                                                group_node_back.inputs[3].default_value = 1.0
                                                                group_node_back.inputs[4].default_value = 0.0
                                                        for tkstur_r in Reflection:
                                                            if tkstur_r.lower() in node_t2.image.name.lower() and not "back" in node_t2.image.name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[5])
                                                                node_t2.inputs[2].default_value = 1
                                                                Reflection_back = False
                                                                for node_rb in nodetree.nodes:
                                                                    if node_rb.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_r2 in Trans:
                                                                            if tekstur_r2.lower() in node_rb.image.name.lower() and "back" in node_rb.image.name.lower():
                                                                                node_reflect_back = node_rb
                                                                                Reflection_back = True
                                                                                break
                                                                if not Reflection_back:
                                                                    node_reflect_back = node_t2
                                                                nodetree.links.new(node_reflect_back.outputs[0], group_node_back.inputs[5])
                                                        for tekstur_roug in RGH:
                                                            if tekstur_roug.lower() in node_t2.image.name.lower() and not "back" in node_t2.image.name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[6])
                                                                node_t2.inputs[2].default_value = 1
                                                                if "gloss" in node_t2.image.name.lower():
                                                                    node_t2.inputs[3].default_value = True
                                                                Roughness_back = False
                                                                for node_rb in nodetree.nodes:
                                                                    if node_rb.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_r2 in Trans:
                                                                            if tekstur_r2.lower() in node_rb.image.name.lower() and "back" in node_rb.image.name.lower():
                                                                                node_roughness_back = node_rb
                                                                                Roughness_back = True
                                                                                break
                                                                if not Roughness_back:
                                                                    node_roughness_back = node_t2
                                                                nodetree.links.new(node_roughness_back.outputs[0], group_node_back.inputs[6])
                                                        for tkstur_n in Normal_names:
                                                            if tkstur_n.lower() in node_t2.image.name.lower() and not "back" in node_t2.image.name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[7])
                                                                node_t2.inputs[2].default_value = 1
                                                                Normal_back = False
                                                                for node_nb in nodetree.nodes:
                                                                    if node_nb.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_n2 in Trans:
                                                                            if tekstur_n2.lower() in node_nb.image.name.lower() and "back" in node_nb.image.name.lower():
                                                                                node_normal_back = node_nb
                                                                                Normal_back = True
                                                                                break
                                                                if not Normal_back:
                                                                    node_normal_back = node_t2
                                                                nodetree.links.new(node_normal_back.outputs[0], group_node_back.inputs[7])
                                                        for tkstur_b in Bumps_maps:
                                                            if tkstur_b.lower() in node_t2.image.name.lower() and not "back" in node_t2.image.name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[8])
                                                                node_t2.inputs[2].default_value = 1
                                                                Bump_back = False
                                                                for node_bb in nodetree.nodes:
                                                                    if node_bb.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_n2 in Trans:
                                                                            if tekstur_n2.lower() in node_bb.image.name.lower() and "back" in node_bb.image.name.lower():
                                                                                node_bump_back = node_bb
                                                                                Bump_back = True
                                                                                break
                                                                if not Bump_back:
                                                                    node_bump_back = node_t2
                                                                nodetree.links.new(node_bump_back.outputs[0], group_node_back.inputs[8])
                                                        for tkstur_o in Opacity:
                                                            if tkstur_o.lower() in node_t2.image.name.lower() and not "back" in node_t2.image.name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[12])
                                                                node_t2.inputs[2].default_value = 1
                                                                Opacity_back = False
                                                                for node_ob in nodetree.nodes:
                                                                    if node_ob.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_n2 in Trans:
                                                                            if tekstur_n2.lower() in node_ob.image.name.lower() and "back" in node_ob.image.name.lower():
                                                                                node_opacity_back = node_ob
                                                                                Opacity_back = True
                                                                                break
                                                                if not Opacity_back:
                                                                    node_opacity_back = node_t2
                                                                nodetree.links.new(node_opacity_back.outputs[0], group_node_back.inputs[12])
                                                        for tkstur_D in Displacement:
                                                            if tkstur_D.lower() in node_t2.image.name.lower() and not "back" in node_t2.image.name.lower():
                                                                nodetree.links.new(node_t2.outputs[0], group_oct_trans.inputs[13])
                                                                node_t2.inputs[2].default_value = 1
                                                                group_oct_trans.inputs[14].default_value = 0.01
                                                                Disp_back = False
                                                                for node_db in nodetree.nodes:
                                                                    if node_db.bl_idname == "OctaneRGBImage":
                                                                        for tekstur_n2 in Trans:
                                                                            if tekstur_n2.lower() in node_db.image.name.lower() and "back" in node_db.image.name.lower():
                                                                                node_disp_back = node_db
                                                                                Disp_back = True
                                                                                break
                                                                if not Disp_back:
                                                                    node_disp_back = node_t2
                                                                nodetree.links.new(node_disp_back.outputs[0], group_node_back.inputs[12])
                                                                group_node_back.inputs[14].default_value = 0.01
                                                            else:
                                                                group_oct_trans.inputs[14].default_value = 0.001
                                                break
                                            else:
                                                for tekstura in Albedo:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        nodetree.links.new(node.outputs[0], group_oct_trans.inputs[0])
                                                        nodetree.links.new(node.outputs[0], group_oct_trans.inputs[1])
                                                        group_oct_trans.inputs[3].default_value = 150
                                                        group_oct_trans.inputs[4].default_value = 0.5
                                                        break    #break
                                                for tekstura in Trans:
                                                    if tekstura.lower() in node.image.name.lower():
                                                         nodetree.links.new(node.outputs[0], group_oct_trans.inputs[1])
                                                         group_oct_trans.inputs[3].default_value = 100
                                                         group_oct_trans.inputs[4].default_value = 0.0
                                                for tekstura in Reflection:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        node.inputs[2].default_value = 1
                                                        nodetree.links.new(node.outputs[0], group_oct_trans.inputs[5])
                                                for tekstura in RGH:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        node.inputs[2].default_value = 1
                                                        node.inputs[3].default_value = False
                                                        nodetree.links.new(node.outputs[0], group_oct_trans.inputs[6])
                                                        if "gloss" in node.image.name.lower():
                                                            node.inputs[3].default_value = False                                    
                                                for tekstura in Normal_names:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        node.inputs[2].default_value = 1
                                                        nodetree.links.new(node.outputs[0], group_oct_trans.inputs[7])
                                                for tekstura in Bumps_maps:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        node.inputs[2].default_value = 1
                                                        nodetree.links.new(node.outputs[0], group_oct_trans.inputs[8])
                                                for tekstura_o in Opacity:
                                                    if tekstura_o.lower() in node.image.name.lower():
                                                        nodetree.links.new(node.outputs[0], group_oct_trans.inputs[12])
                                                for tekstura_d in Displacement:
                                                    if tekstura_d.lower() in node.image.name.lower():
                                                        node.inputs[2].default_value = 1
                                                        nodetree.links.new(node.outputs[0], group_oct_trans.inputs[12])
                                                        group_oct_trans.inputs[14].default_value = 0.01
                                                    else:
                                                        group_oct_trans.inputs[14].default_value = 0.001
                                                for node_m in nodetree.nodes:
                                                    if "Back_Side" in node_m.label or "Oct_Two_Side" in node_m.name or "mix_mat_oct" in node_m.name:
                                                        nodetree.nodes.remove(node_m)
                                                for node_n in nodetree.nodes:
                                                    if "First_Side" in node_n.label:
                                                        Shader = node_n
                                                        for node_n1 in nodetree.nodes:
                                                            if "Octane_Output" in node_n1.label:
                                                                Output_1 = node_n1
                                                                nodetree.links.new(Shader.outputs[0], Output_1.inputs[0])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Octane_Glass_4Cd6D(bpy.types.Operator):
    bl_idname = "sna.octane_glass_4cd6d"
    bl_label = "Octane_Glass"
    bl_description = "Creates Octane Glass Shader"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Fabrics_inputs = bpy.context.window_manager.Cloth_textures.split(",")
        protected_materials = [m for m in bpy.data.materials if getattr(m, "protect_octane", False)]
        protected_material_names = [m.name for m in protected_materials]
        # Get the directory of the current blend file
        current_blend_file_dir = os.path.dirname(bpy.data.filepath)
        #Dodawanie z Addonu
        addon_dir = os.path.dirname(__file__)
        shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        bpy.ops.wm.append(filename="AM266_001_Octane_Glass", directory=shaders_path)
        # Dodawanie z realitive path
        #relative_path = os.path.join(current_blend_file_dir, "shaders/Shaders.blend/NodeTree")
        #bpy.ops.wm.append(filename="AM266_001_Octane_Glass", directory=relative_path)
        # Get the appended tree node group
        tree_node_group = bpy.data.node_groups["AM266_001_Octane_Glass"]
        # Get the name of the blend file
        blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        new_group_name = blend_file_name[:9]
        # Get the NodeTree to be added to materials
        node_tree = bpy.data.node_groups["AM266_001_Octane_Glass"]
        # Set the new name of the node tree
        node_tree.name = new_group_name + "_Octane_Glass"
        active_material = bpy.context.object.active_material
        if not any (name in active_material.name for name in protected_material_names):
            if not "Dots Stroke" in active_material.name:
                nodetree = active_material.node_tree
                if nodetree:
                    for node0 in nodetree.nodes:
                        Octane_Glass_Exists = False
                        for node1 in nodetree.nodes:
                            if "Octane" in node1.name:
                                if "Octane_Glass" in node1.label:
                                    group_node = node1
                                    Octane_Glass_Exists = True
                                    break
                                else:
                                    nodetree.nodes.remove(node1)
                                    Octane_Glass_Exists = False
                                break
                        if not Octane_Glass_Exists:
                            group_node = nodetree.nodes.new("ShaderNodeGroup")
                            group_node.node_tree = node_tree.copy()
                            group_node.name = node_tree.name
                            group_node.label = "Octane_Glass"
                            group_node.location.x += 1650
                            Octane_out_exist = False
                            for node2 in nodetree.nodes:
                                if "Octane_Output" in node2.label:
                                    output_node = node2
                                    Octane_out_exist = True
                                    break
                            if not Octane_out_exist:
                                output_node = material.node_tree.nodes.new("ShaderNodeOutputMaterial")
                                output_node.label = "Octane_Output"
                                output_node.location.x += 2000
                            nodetree.links.new(group_node.outputs[0], output_node.inputs[0])
                            #group_node.inputs[9].default_value = True
                            for node3 in nodetree.nodes:
                                if "mix_mat_oct" in node3.name or "Oct_Two_Side" in node3.name or "Back_Side" in node3.label or "First_Side" in node3.label:
                                    nodetree.nodes.remove(node3)
                            Material_Octane = True
                        break
                    for node in nodetree.nodes:
                        if "Octane_Glass" in node.label:
                            group_oct_glass = node
                            for node in nodetree.nodes:
                                if node.bl_idname == "OctaneRGBImage":
                                    for tekstura in Albedo:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 2.2
                                            nodetree.links.new(node.outputs[0], group_oct_glass.inputs[0])
                                    for tekstura in Reflection:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_glass.inputs[2])
                                    for tekstura in RGH:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value =1.0
                                            nodetree.links.new(node.outputs[0], group_oct_glass.inputs[3])
                                            if "gloss" in node.image.name.lower():
                                                node.inputs[3].default_value = True
                                    for tekstura in Normal_names:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_glass.inputs[4])
                                    for tekstura in Bumps_maps:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_glass.inputs[5])
                                    for tekstura_o in Opacity:
                                        if tekstura_o.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_oct_glass.inputs[6])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Octane_Textures_80Ea7(bpy.types.Operator):
    bl_idname = "sna.octane_textures_80ea7"
    bl_label = "Octane_Textures"
    bl_description = "Migrates All Cycles textures to Octane"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Original_file_path = bpy.data.filepath
        #current_directory = os.path.dirname(current_file_name)
        bpy.ops.wm.save_as_mainfile(filepath=Original_file_path)
        # Set the View Transform to Filmic
        bpy.context.scene.view_settings.view_transform = 'Raw'
        # Set the render engine to Octane
        bpy.data.scenes["Scene"].render.engine = "octane"
        #addon_dir = os.path.dirname(__file__)
        #shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        #if not bpy.data.node_groups.get("[OCTANE_HELPER_NODE_GROUP]"):
            #bpy.ops.wm.append(filename="[OCTANE_HELPER_NODE_GROUP]", directory=shaders_path)
        # Get a list of all collections in the Blender file
        collections = bpy.data.collections
        # Iterate over the collections
        for collection in collections:
            # Replace "Cycles" with "Octane" in the collection name
            collection.name = collection.name.replace("Cycles", "Octane")
        # Get all materials in the scene
        materials = bpy.data.materials
        # Iterate over all materials
        for mat in materials:
            # Get the material's node tree
            nodes = mat.node_tree
            if nodes is not None:
                # Iterate over all nodes in the node tree
                for node in nodes.nodes:
                    # Check if the node is a Principled BSDF node
                    if node.type == "BSDF_PRINCIPLED":
                        # Check if the base color input is not connected
                        if not node.inputs["Base Color"].is_linked:
                            # Create a new Octane RGB Color node
                            octane_rgb_color_node = nodes.nodes.new("OctaneRGBColor")
                            # Set the color of the Octane RGB Color node to the same color as the base color of the Principled BSDF node
                            octane_rgb_color_node.a_value = node.inputs["Base Color"].default_value[:3]
                            # Set the label of the Octane RGB Color node to "Base Color"
                            octane_rgb_color_node.label = "Base Color"
                            # Set the location of the Octane RGB Color node to be 1650 units to the right of the original location of the Principled BSDF node
                            octane_rgb_color_node.location = (node.location[0] + 1650, node.location[1])
        # Iterate over all materials
        for mat in materials:
            # Get the material's node tree
            nodes = mat.node_tree
            if nodes is not None:
                # Iterate over all nodes in the node tree
                for node in nodes.nodes:
                    # Check if the node is a Cycles Image Texture node
                    if node.type == "TEX_IMAGE":
                        # Create a new Octane Image Texture node
                        octane_image_texture_node = nodes.nodes.new("OctaneRGBImage")
                        # Copy the image, colorspace, and projection settings from the Cycles node
                        octane_image_texture_node.image = node.image
                        # Set the location of the Octane texture node to be 1650 units to the right of the original location of the Cycles texture node
                        octane_image_texture_node.location = (node.location[0] +1650, node.location[1])
                        # Set the default_value of the input at index 2 of the Octane texture node to 1.0 if the image name contains "normal" or "glossiness"
                        if "Normal" in node.image.name or "Glossiness" in node.image.name or "Reflection" in node.image.name or "Roughness" in node.image.name or "Opacity" in node.image.name or "Height" in node.image.name:
                            octane_image_texture_node.inputs[2].default_value = 1.0
                        else:
                            octane_image_texture_node.inputs[2].default_value = 2.2
        #Przeniesienie COlorramp
        octane_helper = bpy.data.node_groups.get("[OCTANE_HELPER_NODE_GROUP]")
        if octane_helper:
            node_gradient = "OctaneGradientMap"
            octane_elements = True
        else:
            node_gradient = "ShaderNodeOctGradientTex"
            octane_elements = None
        # Iterate over all materials
        for mat in bpy.data.materials:
            # Get the material's node tree
            Colorramp = mat.node_tree
            if Colorramp:
                # Get all ShaderNodeValToRGB nodes in the material's node tree
                val_to_rgb_nodes = [node for node in Colorramp.nodes if node.bl_idname.startswith("ShaderNodeValToRGB")]
                # Iterate over all ShaderNodeValToRGB nodes
                for val_to_rgb in val_to_rgb_nodes:
                    node_c = val_to_rgb.color_ramp
                    color_ramp_Cycles_Location = val_to_rgb.location
                    num_elements = len(node_c.elements)
                    # Create a new Octane Gradient Map node if one doesn't exist
                    octane_image_texture_node = None
                    for node_oG in Colorramp.nodes:
                        if node_gradient in node_oG.bl_idname:
                            octane_image_texture_node = node_oG
                            break
                    if not octane_image_texture_node:
                        octane_image_texture_node = Colorramp.nodes.new(node_gradient)
                        octane_image_texture_node.name = "Gradient Tex" + val_to_rgb.name.split(".")[-1]
                        if node_gradient == "OctaneGradientMap":
                            octane_name = octane_image_texture_node.color_ramp_name
                    # If we are using Octane Helper group, get the color ramp elements from the helper group
                    if octane_elements:
                        ramp_items = octane_helper.nodes[0].color_ramp.elements
                    # Otherwise, get the color ramp elements from the node we just created
                    else:
                        ramp_items = octane_image_texture_node.color_ramp.elements
                    # Loop through all the color ramp elements and add new elements to the Octane Gradient Map
                    for i in range(num_elements):
                        elements = node_c.elements[i]
                        if i >= len(ramp_items):
                            ramp_items.new(elements.position)
                        ramp_items[i].position = elements.position
                        ramp_items[i].color = elements.color
        # Get the current file name and directory
        current_file_name = bpy.data.filepath
        current_directory = os.path.dirname(current_file_name)
        # Replace "Cycles" with "Octane" in the file name
        new_file_name = current_file_name.replace("Cycles", "Octane")
        # Save the file with the new name
        bpy.ops.wm.save_as_mainfile(filepath=new_file_name)
        # Get the directory of the current blend file
        #current_blend_file_dir = os.path.dirname(bpy.data.filepath)
        # Get the path to the tree node file
        #relative_path = os.path.join(current_blend_file_dir, "shaders/Shaders.blend/NodeTree")
        # Append the tree node group from the file
        #bpy.ops.wm.append(filename="AM268_001_Octane", directory=relative_path)
        #bpy.ops.wm.append(filename="AM266_001_Octane_Glass", directory=relative_path)
        #bpy.ops.wm.append(filename="AM268_001_Octane_Transmission", directory=relative_path)
        ## Get the appended tree node group
        #tree_node_group = bpy.data.node_groups["AM268_001_Octane"]
        # Get the name of the blend file
        #blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        #new_group_name = blend_file_name[:9]
        # Get the NodeTree to be added to materials
        #node_tree = bpy.data.node_groups["AM268_001_Octane"]
        # Set the new name of the node tree
        #node_tree.name = new_group_name + "_Octane"
        # Iterate over all materials in the scene
        #for material in bpy.data.materials:
           # if not "Dots Stroke" in material.name:
              #  nodetree= material.node_tree
              #  if nodetree:
                  # Add a "ShaderNodeGroup" node to the material's node tree
                #  group_node = material.node_tree.nodes.new("ShaderNodeGroup")
                  # Set the node's settings to use the new NodeTree
                 # group_node.node_tree = node_tree.copy()
                  # Set the name of the node to "Octane"
                 # group_node.name = node_tree.name 
                  # Position the node 1650 units to the right
                  #group_node.location.x += 1650
                  # Add a Material Output node to the material's node tree
                  #output_node = material.node_tree.nodes.new("ShaderNodeOutputMaterial")
                  # Position the Material Output node 2000 units to the right
                  #output_node.location.x += 2000
                  # Connect the group node to the Material Output node
                  #material.node_tree.links.new(group_node.outputs[0], output_node.inputs[0])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Metal_Cycles_10800(bpy.types.Operator):
    bl_idname = "sna.metal_cycles_10800"
    bl_label = "Metal_Cycles"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Fabrics_inputs = bpy.context.window_manager.Cloth_textures.split(",")
        # Get the directory of the current blend file
        current_blend_file_dir = os.path.dirname(bpy.data.filepath)
        #Dodawanie grupy z Addonu:
        addon_dir = os.path.dirname(__file__)
        shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        bpy.ops.wm.append(filename="AM266_001_Cycles", directory=shaders_path)
        #Dodawanie grupy z Realitviepath:
        #relative_path = os.path.join(current_blend_file_dir, "shaders/Shaders.blend/NodeTree")
        #bpy.ops.wm.append(filename="AM266_001_Cycles", directory=relative_path)
        # Get the appended tree node group
        tree_node_group = bpy.data.node_groups["AM266_001_Cycles"]
        # Get the name of the blend file
        blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        new_group_name = blend_file_name[:9]
        # Get the NodeTree to be added to materials
        node_tree = bpy.data.node_groups["AM266_001_Cycles"]
        # Set the new name of the node tree
        node_tree.name = new_group_name + "_Cycles_Base"
        active_material = bpy.context.object.active_material
        if not "Dots Stroke" in active_material.name:
            nodetree = active_material.node_tree
            if nodetree:
                for node0 in nodetree.nodes:
                    Cycles_Basic_Exists = False
                    for node1 in nodetree.nodes:
                        if "Cycles" in node1.name:
                            if "Cycles_basic" in node1.label:
                                group_node = node1
                                Cycles_Basic_Exists = True
                                break
                            else:
                                nodetree.nodes.remove(node1)
                                Cycles_Basic_Exists = False
                            break
                    if not Cycles_Basic_Exists:
                        group_node = nodetree.nodes.new("ShaderNodeGroup")
                        group_node.node_tree = node_tree.copy()
                        group_node.name = node_tree.name
                        group_node.label = "Cycles_basic"
                        #for node3 in nodetree.nodes:
                            #if "mix_mat_oct" in node3.name or "Oct_Two_Side" in node3.name or "Back_Side" in node3.label or "First_Side" in node3.label or "Octane_Glass" in node3.label:
                                #nodetree.nodes.remove(node3)
                    break
                for node in nodetree.nodes:
                    if "Cycles_basic" in node.label:
                        group_cyc_basic = node
                        for node in nodetree.nodes:   
                            if node.type == "TEX_IMAGE":
                                group_cyc_basic.inputs[5].default_value = 1
                                for tekstura in Albedo:
                                    if tekstura.lower() in node.image.name.lower():
                                        group_cyc_basic.inputs[1].default_value = 0.6
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[0])
                                for tekstura in Reflection:
                                    if tekstura.lower() in node.image.name.lower():
                                        node.image.colorspace_settings.name = 'sRGB'
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[0])
                                        group_cyc_basic.inputs[1].default_value = 1.0
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[2])
                                for tekstura in RGH:
                                    if tekstura.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[3])
                                        group_cyc_basic.inputs[4].default_value = 0
                                        if "gloss" in node.image.name.lower():
                                             group_cyc_basic.inputs[4].default_value = 1
                                for tekstura in Bumps_maps:
                                    if tekstura.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[8])
                                        group_cyc_basic.inputs[11].default_value = 1 
                                for tekstura in Normal_names:
                                    if tekstura.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[8])
                                        group_cyc_basic.inputs[11].default_value = 0
                                for tekstura_o in Opacity:
                                    if tekstura_o.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[15])
                                for tekstura_d in Displacement:
                                    if tekstura_d.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[13])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Cycles_Basic_2C7A2(bpy.types.Operator):
    bl_idname = "sna.cycles_basic_2c7a2"
    bl_label = "Cycles_Basic"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Fabrics_inputs = bpy.context.window_manager.Cloth_textures.split(",")
        # Get the directory of the current blend file
        current_blend_file_dir = os.path.dirname(bpy.data.filepath)
        #Dodawanie grupy z Addonu:
        addon_dir = os.path.dirname(__file__)
        shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        bpy.ops.wm.append(filename="AM266_001_Cycles", directory=shaders_path)
        #Dodawanie grupy z Realitviepath:
        #relative_path = os.path.join(current_blend_file_dir, "shaders/Shaders.blend/NodeTree")
        #bpy.ops.wm.append(filename="AM266_001_Cycles", directory=relative_path)
        # Get the appended tree node group
        tree_node_group = bpy.data.node_groups["AM266_001_Cycles"]
        # Get the name of the blend file
        blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        new_group_name = blend_file_name[:9]
        # Get the NodeTree to be added to materials
        node_tree = bpy.data.node_groups["AM266_001_Cycles"]
        # Set the new name of the node tree
        node_tree.name = new_group_name + "_Cycles_Base"
        active_material = bpy.context.object.active_material
        if not "Dots Stroke" in active_material.name:
            nodetree = active_material.node_tree
            if nodetree:
                for node0 in nodetree.nodes:
                    Cycles_Basic_Exists = False
                    for node1 in nodetree.nodes:
                        if "Cycles" in node1.name:
                            if "Cycles_basic" in node1.label:
                                group_node = node1
                                Cycles_Basic_Exists = True
                                break
                            else:
                                nodetree.nodes.remove(node1)
                                Cycles_Basic_Exists = False
                            break
                    if not Cycles_Basic_Exists:
                        group_node = nodetree.nodes.new("ShaderNodeGroup")
                        group_node.node_tree = node_tree.copy()
                        group_node.name = node_tree.name
                        group_node.label = "Cycles_basic"
                        #for node3 in nodetree.nodes:
                            #if "mix_mat_oct" in node3.name or "Oct_Two_Side" in node3.name or "Back_Side" in node3.label or "First_Side" in node3.label or "Octane_Glass" in node3.label:
                                #nodetree.nodes.remove(node3)
                    break
                for node in nodetree.nodes:
                    if "Cycles_basic" in node.label:
                        group_cyc_basic = node
                        for node in nodetree.nodes:   
                            if node.type == "TEX_IMAGE":
                                group_cyc_basic.inputs[5].default_value = 0
                                for tekstura in Albedo:
                                    if tekstura.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[0])
                                for tekstura in Reflection:
                                    if tekstura.lower() in node.image.name.lower():
                                        node.image.colorspace_settings.name = 'Non-Color'
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[2])
                                for tekstura in RGH:
                                    if tekstura.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[3])
                                        group_cyc_basic.inputs[4].default_value = 0
                                        if "gloss" in node.image.name.lower():
                                             group_cyc_basic.inputs[4].default_value = 1
                                for tekstura in Bumps_maps:
                                    if tekstura.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[8])
                                        group_cyc_basic.inputs[11].default_value = 1 
                                for tekstura in Normal_names:
                                    if tekstura.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[8])
                                        group_cyc_basic.inputs[11].default_value = 0
                                for tekstura_o in Opacity:
                                    if tekstura_o.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[15])
                                for tekstura_d in Displacement:
                                    if tekstura_d.lower() in node.image.name.lower():
                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[13])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Luxcore_Cloth_862C1(bpy.types.Operator):
    bl_idname = "sna.luxcore_cloth_862c1"
    bl_label = "Luxcore_Cloth"
    bl_description = "Creates Cloth Materials according to Textures inputs"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Nazwy_Luxcore_mat =("Disney Material", "Matte Material", "Carpaint Material", "Glass Material", "Cloth Material", "Mix Material", "Velvet Material", "Glossy Translucent Material", "Glossy Material", "Metal Material", "Mirror Material")
        active_material = bpy.context.object.active_material
        if not "Dots Stroke" in active_material.name:
            if "luxcore" in active_material:
                node_tree_cloth = active_material.luxcore.node_tree
                #print(node_tree_cloth.nodes)
                material_Cloth_exists = False
                if node_tree_cloth:
                    for node0 in node_tree_cloth.nodes:
                        for Material in Nazwy_Luxcore_mat:                
                            if Material in node0.name:
                                if "LuxCoreNodeMatCloth" in node0.bl_idname:
                                    new_node = node0
                                    material_Cloth_exists = True
                                    break
                                else:
                                    node_tree_cloth.nodes.remove(node0)
                                    material_exists = False
                                #break
                                #print(node.name)
                                if not material_Cloth_exists:
                                    new_node = node_tree_cloth.nodes.new(type="LuxCoreNodeMatCloth")
                                    new_node.use_transform = True
                                    new_node.preset = 'cotton_twill'
                                    new_node.location = 400,-600
                                    break
                    output_exists = False
                    for node2 in node_tree_cloth.nodes:
                        if "LuxCoreNodeMatOutput" in node2.bl_idname:
                            new_output = node2
                            output_exists = True
                            break
                    if not output_exists:
                        new_output = node_tree_cloth.nodes.new(type="LuxCoreNodeMatOutput")
                        new_output.use_transform = True
                        new_output.name = "Luxcore_Output"
                        new_output.location = 800,-800
                        output_exists = True
                    node_tree_cloth.links.new(new_node.outputs[0], new_output.inputs[0])
                    material_Cloth_exists = True
                    if material_Cloth_exists:
                        for node in node_tree_cloth.nodes:    
                            if "LuxCoreNodeMatCloth" in node.bl_idname:
                                group_inputs_cloth = [node.inputs[i] for i in range(len(node.inputs))]
                                node_cloth = node
                                for node_A in node_tree_cloth.nodes:
                                    for tekstura in Albedo:
                                        if tekstura.lower() in node_A.label.lower():
                                            node_tree_cloth.links.new(node_A.outputs[0], group_inputs_cloth[0])
                                            node_tree_cloth.links.new(node_A.outputs[0], group_inputs_cloth[2])
                                for node_R in node_tree_cloth.nodes:
                                    for reflect in Reflection:
                                        if reflect.lower() in node_R.label.lower():
                                            node_tree_cloth.links.new(node_R.outputs[0], group_inputs_cloth[1])
                                            node_tree_cloth.links.new(node_R.outputs[0], group_inputs_cloth[3])
                                            node_R.gamma = 1
                                #Podlaczanie Bump/Normal:
                                use_cloth_normal = False
                                for noden in node_tree_cloth.nodes:
                                    for Normalki in Normal_names:
                                        if Normalki.lower() in noden.label.lower():
                                            if "Normal/Map" not in noden.label:
                                                noden.is_normal_map = True
                                                node_tree_cloth.links.new(noden.outputs[2], group_inputs_cloth[5])
                                                #node.is_normal_map = True
                                                use_cloth_normal = True
                                                for node_LB in node_tree_cloth.nodes:
                                                    if "Luxcore_Bump" in node_LB.name:
                                                        #print(node.name)
                                                       node_tree_cloth.nodes.remove(node_LB)
                                                break
                                    if not use_cloth_normal:
                                        for nodeb in node_tree_cloth.nodes:
                                            for Bumpik in Bumps_maps:
                                                if Bumpik.lower() in nodeb.label.lower():
                                                    #node_tree_cloth.links.new(nodeb.outputs[0], group_inputs_cloth[15])
                                                    Bum_Exists = False
                                                    for node_bump in node_tree_cloth.nodes:
                                                        if "LuxCoreNodeTexBump" in node_bump.bl_idname:
                                                            new_node_bump = node_bump
                                                            Bum_Exists = True
                                                            break
                                                    if not Bum_Exists:
                                                        new_node_bump = node_tree_cloth.nodes.new(type="LuxCoreNodeTexBump")
                                                        new_node_bump.use_transform = True
                                                        new_node_bump.name = "Luxcore_Bump"
                                                        new_node_bump.location = 150,-1000
                                                    node_tree_cloth.links.new(nodeb.outputs[0], new_node_bump.inputs[0])
                                                    node_tree_cloth.links.new(new_node_bump.outputs[0], group_inputs_cloth[5])                                                              
                                #Podlaczenie Opacity:
                                for node in node_tree_cloth.nodes:       
                                    for Maska in Opacity:
                                        if Maska.lower() in node.label.lower():
                                            #print("Tekstura Opacity to:",node.label)
                                            node_tree_cloth.links.new(node.outputs[0], group_inputs_cloth[4])
                                            #break
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Luxcore_Materials_0C4Ac(bpy.types.Operator):
    bl_idname = "sna.luxcore_materials_0c4ac"
    bl_label = "Luxcore_Materials"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Nazwy_Luxcore_mat =("Disney Material", "Matte Material", "Carpaint Material", "Glass Material", "Cloth Material", "Mix Material", "Velvet Material", "Glossy Translucent Material", "Glossy Material", "Metal Material", "Mirror Material")
        active_material = bpy.context.object.active_material
        if not "Dots Stroke" in active_material.name:
            if "luxcore" in active_material:
                node_tree_disney = active_material.luxcore.node_tree
                #print(node_tree.nodes)
                if node_tree_disney:
                    for node0 in node_tree_disney.nodes:
                        for Material in Nazwy_Luxcore_mat:
                            material_exists = False                
                            if Material in node0.name:
                                if "LuxCoreNodeMatDisney" in node0.bl_idname:
                                    new_node = node0
                                    material_exists = True
                                    break
                                else:
                                    node_tree_disney.nodes.remove(node0)
                                    material_exists = False
                                    #break
                                #break
                                #print(node.name)
                                if not material_exists:
                                    new_node = node_tree_disney.nodes.new(type="LuxCoreNodeMatDisney")
                                    new_node.use_transform = True
                                    new_node.location = 400,-600
                                    material_exists = True
                                    break
                    output_exists = False
                    for node_Disneyek in node_tree_disney.nodes:
                        if "LuxCoreNodeMatDisney" in node_Disneyek.bl_idname:
                            nasz_dinseyek = node_Disneyek
                    for node2 in node_tree_disney.nodes:
                        if "LuxCoreNodeMatOutput" in node2.bl_idname:
                            new_output = node2
                            output_exists = True
                            break
                    if not output_exists:
                            new_output = node_tree_disney.nodes.new(type="LuxCoreNodeMatOutput")
                            new_output.use_transform = True
                            new_output.name = "Luxcore_Output"
                            new_output.location = 800,-800
                            material_exists = True
                    node_tree_disney.links.new(nasz_dinseyek.outputs[0], new_output.inputs[0])
                    if material_exists:
                        for node in node_tree_disney.nodes:    
                            if "LuxCoreNodeMatDisney" in node.bl_idname:
                                group_inputs_Disney = [node.inputs[i] for i in range(len(node.inputs))]
                                for node_A in node_tree_disney.nodes:
                                    for tekstura in Albedo:
                                        if tekstura.lower() in node_A.label.lower():
                                            node_tree_disney.links.new(node_A.outputs[0], group_inputs_Disney[0])
                                for node_Metal in node_tree_disney.nodes:
                                    for metaling in Metal:
                                        if metaling.lower() in node_Metal.label.lower():
                                            node_tree_disney.links.new(node_Metal.outputs[0], group_inputs_Disney[2])
                                for node_B in node_tree_disney.nodes:
                                    for reflect in Reflection:
                                        if reflect.lower() in node_B.label.lower():
                                            node_tree_disney.links.new(node_B.outputs[0], group_inputs_Disney[3])
                                for node in node_tree_disney.nodes:       
                                        for Roug in RGH:
                                            if Roug.lower() in node.label.lower():
                                                Rough_new = node
                                                print(Rough_new)
                                                node_tree_disney.links.new(Rough_new.outputs[0], group_inputs_Disney[5])
                                                for node in node_tree_disney.nodes:
                                                    if "gloss" in node.label.lower():
                                                        Invert = False
                                                        for node in node_tree_disney.nodes:
                                                            if "Invert_Luxcore" in node.name:
                                                                Invert_node = node
                                                                Invert = True
                                                                break
                                                        if not Invert:
                                                            Invert_node = node_tree_disney.nodes.new(type="LuxCoreNodeTexInvert")
                                                            Invert_node.name = "Invert_Luxcore"                                            
                                                            Invert_node.use_transform = True
                                                            Invert_node.location = 200,-700
                                                        #print("Outputs invert to:",new_gloss.outputs)
                                                        node_tree_disney.links.new(Invert_node.outputs[0], group_inputs_Disney[5])
                                                        node_tree_disney.links.new(Rough_new.outputs[0], Invert_node.inputs[0])
                                                    Invert = True
                                                if Roug.lower() in node.label.lower():
                                                    if "gloss" not in node.label.lower():
                                                        for node_inv in node_group.nodes:
                                                            if "Invert_Luxcore" in node_inv.name:
                                                                node_tree_disney.nodes.remove(node_inv)
                                                               # break
                                #Podlaczenie Opacity:
                                for node_do in node_tree_disney.nodes:       
                                    for Maska in Opacity:
                                        if Maska.lower() in node_do.label.lower():
                                            #print("Tekstura Opacity to:",node.label)
                                            node_tree_disney.links.new(node_do.outputs[0], group_inputs_Disney[14])
                                Use_disney_normal = False
                                for node_nd in node_tree_disney.nodes:
                                    for Normalki in Normal_names:
                                        if Normalki.lower() in node_nd.label.lower():
                                            if "Normal/Map" not in node_nd.label:
                                                node_nd.is_normal_map = True
                                                node_tree_disney.links.new(node_nd.outputs[2], group_inputs_Disney[15])
                                                #node.is_normal_map = True
                                                Use_disney_normal = True
                                                for node_DB in node_tree_disney.nodes:
                                                    if "LuxCoreNodeTexBump" in node_DB.bl_idname:
                                                        #print(node.name)
                                                       node_tree_disney.nodes.remove(node_DB)
                                                break
                                    if not Use_disney_normal:
                                        for node_db in node_tree_disney.nodes:
                                            for Bumpik in Bumps_maps:
                                                if Bumpik.lower() in node_db.label.lower():
                                                    #node_tree_disney.links.new(nodeb.outputs[0], group_inputs_Trans[15])
                                                    Bum_Exists = False
                                                    for node_bump in node_tree_disney.nodes:
                                                        if "LuxCoreNodeTexBump" in node_bump.bl_idname:
                                                            new_node_bump = node_bump
                                                            Bum_Exists = True
                                                            break
                                                    if not Bum_Exists:
                                                        new_node_bump = node_tree_disney.nodes.new(type="LuxCoreNodeTexBump")
                                                        new_node_bump.use_transform = True
                                                        new_node_bump.name = "Luxcore_Bump"
                                                        new_node_bump.location = 150,-1000
                                                    node_tree_disney.links.new(node_db.outputs[0], new_node_bump.inputs[0])
                                                    node_tree_disney.links.new(new_node_bump.outputs[0], group_inputs_Disney[15])                 
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Luxcore_Mapping_Ad5Cc(bpy.types.Operator):
    bl_idname = "sna.luxcore_mapping_ad5cc"
    bl_label = "Luxcore_mapping"
    bl_description = "Adds 2d mapping to all textures in the materail "
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        active_material = bpy.context.object.active_material
        if not "Dots Stroke" in active_material.name:
            if "luxcore" in active_material:
                Node_mapping = active_material.luxcore.node_tree
                #print(Node_mapping.nodes)
                if Node_mapping:
                    imagetexture = False
                    for node0 in Node_mapping.nodes:
                        if "Imagemap" in node0.name:
                            mapping_location = node0.location
                            imagetexture = True
                            break
                    if imagetexture:
                        Mapping = False
                        for node_map in Node_mapping.nodes:
                            if "LuxCoreNodeTexMapping2D" in node_map.bl_idname:
                                mapping_node = node_map
                                Mapping = True
                                break
                        if not Mapping:
                            mapping_node = Node_mapping.nodes.new(type="LuxCoreNodeTexMapping2D")
                            mapping_node.use_transform = True
                            mapping_node.location = mapping_location.x - 500, mapping_location.y - 500
                        for node_textures in Node_mapping.nodes:
                            if "Imagemap" in node_textures.name:
                                Node_mapping.links.new(node_textures.inputs[0],mapping_node.outputs[0] )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Octane_Base_7C132(bpy.types.Operator):
    bl_idname = "sna.octane_base_7c132"
    bl_label = "Octane_Base"
    bl_description = "Octane_Uber"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Fabrics_inputs = bpy.context.window_manager.Cloth_textures.split(",")
        protected_materials = [m for m in bpy.data.materials if getattr(m, "protect_octane", False)]
        protected_material_names = [m.name for m in protected_materials]
        # Get the directory of the current blend file
        current_blend_file_dir = os.path.dirname(bpy.data.filepath)
        # Get the path to the tree node file
        #relative_path = os.path.join(current_blend_file_dir, "shaders/Shaders.blend/NodeTree")
        # Append the tree node group from the file
        #bpy.ops.wm.append(filename="AM268_001_Octane", directory=relative_path)
        #Dodawanie z Addonu
        addon_dir = os.path.dirname(__file__)
        shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        bpy.ops.wm.append(filename="AM268_001_Octane", directory=shaders_path)
        # Get the appended tree node group
        tree_node_group = bpy.data.node_groups["AM268_001_Octane"]
        # Get the name of the blend file
        blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        new_group_name = blend_file_name[:9]
        # Get the NodeTree to be added to materials
        node_tree = bpy.data.node_groups["AM268_001_Octane"]
        # Set the new name of the node tree
        node_tree.name = new_group_name + "_Octane"
        active_material = bpy.context.object.active_material
        if not any (name in active_material.name for name in protected_material_names):
            if not "Dots Stroke" in active_material.name:
                nodetree = active_material.node_tree
                if nodetree:
                    for node0 in nodetree.nodes:
                        Octane_Basic_Exists = False
                        for node1 in nodetree.nodes:
                            if "Octane" in node1.name:
                                if "Octane_Basic" in node1.label:
                                    group_node = node1
                                    Octane_Basic_Exists = True
                                    break
                                else:
                                    nodetree.nodes.remove(node1)
                                    Octane_Basic_Exists = False
                                break
                        if not Octane_Basic_Exists:
                            group_node = nodetree.nodes.new("ShaderNodeGroup")
                            group_node.node_tree = node_tree.copy()
                            group_node.name = node_tree.name
                            group_node.label = "Octane_Basic"
                            group_node.location.x += 1650
                            Octane_out_exist = False
                            for node2 in nodetree.nodes:
                                if "Octane_Output" in node2.label:
                                    output_node = node2
                                    Octane_out_exist = True
                                    break
                            if not Octane_out_exist:
                                output_node = active_material.node_tree.nodes.new("ShaderNodeOutputMaterial")
                                output_node.label = "Octane_Output"
                                output_node.location.x += 2000
                            nodetree.links.new(group_node.outputs[0], output_node.inputs[0])
                            group_node.inputs[9].default_value = True
                            for node3 in nodetree.nodes:
                                if "mix_mat_oct" in node3.name or "Oct_Two_Side" in node3.name or "Back_Side" in node3.label or "First_Side" in node3.label or "Octane_Glass" in node3.label:
                                    nodetree.nodes.remove(node3)
                            Octane_out_exist = True
                        break
                    for node in nodetree.nodes:
                        if "Octane_Basic" in node.label:
                            group_oct_basic = node
                            for node in nodetree.nodes:
                                if node.label == "Base Color":
                                    nodetree.links.new(node.outputs[0], group_oct_basic.inputs[0])
                                if node.bl_idname == "OctaneRGBImage":
                                    group_oct_basic.inputs[8].default_value = 0
                                    for tekstura in Albedo:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 2.2
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[0])
                                    for tekstura in Reflection:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[1])
                                    for tekstura in RGH:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value =1.0
                                            node.inputs[3].default_value = True
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[2])
                                            if "gloss" in node.image.name.lower():
                                                node.inputs[3].default_value = True
                                    for tekstura in Normal_names:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[3])
                                    for tekstura in Bumps_maps:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[6])
                                    for tekstura_o in Opacity:
                                        if tekstura_o.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[5])
                                    for tekstura_d in Displacement:
                                        if tekstura_d.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[5])
                                            node.inputs[2].default_value = 1
                                            group_oct_basic.inputs[11].default_value = 0.01
                                        else:
                                            group_oct_basic.inputs[11].default_value = 0.001
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Cycles_Popup_Fedda(bpy.types.Operator):
    bl_idname = "sna.cycles_popup_fedda"
    bl_label = "Cycles_Popup"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        for mat in bpy.data.materials:
            drzewo_nodow = mat.node_tree
            if drzewo_nodow:
                prefix = None
                for texture_node in drzewo_nodow.nodes:
                    if texture_node.type == 'TEX_IMAGE' and hasattr(texture_node.image, 'name'):
                        #Pobierz nazwę tekstury
                        tekstura = texture_node.image.name
                        #Sprawdzenie czy tekstura jest do czegoś podłączona
                        if not any(socket.is_linked for socket in texture_node.outputs):
                            drzewo_nodow.nodes.remove(texture_node)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Rotacji_Operator_222C2(bpy.types.Operator):
    bl_idname = "sna.reset_rotacji_operator_222c2"
    bl_label = "Reset_Rotacji_operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        from mathutils import Vector
        # Znajdź aktywny obiekt
        obj = bpy.context.active_object
        # Sprawdź, czy grupa "obrot" istnieje
        if "obrot" not in obj.vertex_groups:
            print("Grupa wierzchołków 'obrot' nie istnieje.")
            #quit()
        # Pobierz listę wierzchołków z grupy "obrot"
        mesh = obj.data
        group_index = obj.vertex_groups["obrot"].index
        verts = [v for v in mesh.vertices if group_index in [g.group for g in v.groups]]
        # Oblicz kąt pomiędzy osią Z a rzutem wektora normalnego na płaszczyznę xy
        normal = Vector()
        for i in range(0, len(verts), 3):
            normal += (verts[i+1].co - verts[i].co).cross(verts[i+2].co - verts[i].co)
        normal.normalize()
        # Oblicz kąt pomiędzy osią Z a rzutem wektora normalnego na płaszczyznę xy dla pierwszej pary wierzchołków
        angle_x1 = math.atan2(verts[1].co.y - verts[0].co.y, verts[1].co.z - verts[0].co.z)
        angle_x1_deg = math.degrees(angle_x1)
        # Wydrukuj kąt w stopniach dla pierwszej pary wierzchołków
        print("Kąt obrotu dla pierwszej pary wierzchołków w osi X: ", angle_x1_deg)
        # Obróć model o kąt dla pierwszej pary wierzchołków
        if abs(angle_x1_deg) > 0 and abs(angle_x1_deg) % 90 != 0:
            bpy.ops.transform.rotate(value=1.5707963268-angle_x1, orient_axis='X', orient_type='GLOBAL')
        # Oblicz kąt pomiędzy osią Z a rzutem wektora normalnego na płaszczyznę xy dla drugiej pary wierzchołków
        else:
            angle_x2 = math.atan2(verts[2].co.y - verts[0].co.y, verts[2].co.z - verts[0].co.z)
            angle_x2_deg = math.degrees(angle_x2)
            # Wydrukuj kąt w stopniach dla drugiej pary wierzchołków
            print("Kąt obrotu dla drugiej pary wierzchołków w osi X: ", angle_x2_deg)
            # Obróć model o kąt dla drugiej pary wierzchołków
            bpy.ops.transform.rotate(value=1.5707963268-angle_x2, orient_axis='X', orient_type='GLOBAL')
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
        angle_Y1 = math.atan2(verts[1].co.x - verts[0].co.x, verts[1].co.z - verts[0].co.z)
        angle_Y1_deg = math.degrees(angle_Y1)
        # Wydrukuj kąt w stopniach dla pierwszej pary wierzchołków
        print("Kąt obrotu dla pierwszej pary wierzchołków w osi X: ", angle_Y1_deg)
        # Obróć model o kąt dla pierwszej pary wierzchołków
        if abs(angle_Y1_deg) > 0 and abs(angle_Y1_deg) % 90 != 0:
            bpy.ops.transform.rotate(value=angle_Y1-1.5707963268, orient_axis='Y', orient_type='GLOBAL')
        # Oblicz kąt pomiędzy osią Z a rzutem wektora normalnego na płaszczyznę xy dla drugiej pary wierzchołków
        else:
            angle_Y2 = math.atan2(verts[2].co.x - verts[0].co.x, verts[2].co.z - verts[0].co.z)
            angle_Y2_deg = math.degrees(angle_Y2)
            # Wydrukuj kąt w stopniach dla drugiej pary wierzchołków
            print("Kąt obrotu dla drugiej pary wierzchołków w osi X: ", angle_Y2_deg)
            # Obróć model o kąt dla drugiej pary wierzchołków
            bpy.ops.transform.rotate(value=angle_Y2-1.5707963268, orient_axis='Y', orient_type='GLOBAL')
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Octane_All_007D9(bpy.types.Operator):
    bl_idname = "sna.octane_all_007d9"
    bl_label = "Octane_All"
    bl_description = "Creates Octane All Materials"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Original_file_path = bpy.data.filepath
        #current_directory = os.path.dirname(current_file_name)
        bpy.ops.wm.save_as_mainfile(filepath=Original_file_path)
        # Set the View Transform to Filmic
        bpy.context.scene.view_settings.view_transform = 'Raw'
        # Set the render engine to Octane
        bpy.data.scenes["Scene"].render.engine = "octane"
        #addon_dir = os.path.dirname(__file__)
        #shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        #if not bpy.data.node_groups.get("[OCTANE_HELPER_NODE_GROUP]"):
            #bpy.ops.wm.append(filename="[OCTANE_HELPER_NODE_GROUP]", directory=shaders_path)
        # Get a list of all collections in the Blender file
        collections = bpy.data.collections
        # Iterate over the collections
        for collection in collections:
            # Replace "Cycles" with "Octane" in the collection name
            collection.name = collection.name.replace("Cycles", "Octane")
        # Get all materials in the scene
        materials = bpy.data.materials
        # Iterate over all materials
        for mat in materials:
            # Get the material's node tree
            nodes = mat.node_tree
            if nodes is not None:
                # Iterate over all nodes in the node tree
                for node in nodes.nodes:
                    # Check if the node is a Principled BSDF node
                    if node.type == "BSDF_PRINCIPLED":
                        # Check if the base color input is not connected
                        if not node.inputs["Base Color"].is_linked:
                            # Create a new Octane RGB Color node
                            octane_rgb_color_node = nodes.nodes.new("OctaneRGBColor")
                            # Set the color of the Octane RGB Color node to the same color as the base color of the Principled BSDF node
                            octane_rgb_color_node.a_value = node.inputs["Base Color"].default_value[:3]
                            # Set the label of the Octane RGB Color node to "Base Color"
                            octane_rgb_color_node.label = "Base Color"
                            # Set the location of the Octane RGB Color node to be 1650 units to the right of the original location of the Principled BSDF node
                            octane_rgb_color_node.location = (node.location[0] + 1650, node.location[1])
        # Iterate over all materials
        for mat in materials:
            # Get the material's node tree
            nodes = mat.node_tree
            if nodes is not None:
                # Iterate over all nodes in the node tree
                for node in nodes.nodes:
                    # Check if the node is a Cycles Image Texture node
                    if node.type == "TEX_IMAGE":
                        # Create a new Octane Image Texture node
                        octane_image_texture_node = nodes.nodes.new("OctaneRGBImage")
                        # Copy the image, colorspace, and projection settings from the Cycles node
                        octane_image_texture_node.image = node.image
                        # Set the location of the Octane texture node to be 1650 units to the right of the original location of the Cycles texture node
                        octane_image_texture_node.location = (node.location[0] +1650, node.location[1])
                        # Set the default_value of the input at index 2 of the Octane texture node to 1.0 if the image name contains "normal" or "glossiness"
                        if "Normal" in node.image.name or "Glossiness" in node.image.name or "Reflection" in node.image.name or "Roughness" in node.image.name or "Opacity" in node.image.name or "Height" in node.image.name:
                            octane_image_texture_node.inputs[2].default_value = 1.0
                        else:
                            octane_image_texture_node.inputs[2].default_value = 2.2
        #Przeniesienie COlorramp
        octane_helper = bpy.data.node_groups.get("[OCTANE_HELPER_NODE_GROUP]")
        if octane_helper:
            node_gradient = "OctaneGradientMap"
            octane_elements = True
        else:
            node_gradient = "ShaderNodeOctGradientTex"
            octane_elements = None
        # Iterate over all materials
        for mat in bpy.data.materials:
            # Get the material's node tree
            Colorramp = mat.node_tree
            if Colorramp:
                # Get all ShaderNodeValToRGB nodes in the material's node tree
                val_to_rgb_nodes = [node for node in Colorramp.nodes if node.bl_idname.startswith("ShaderNodeValToRGB")]
                # Iterate over all ShaderNodeValToRGB nodes
                for val_to_rgb in val_to_rgb_nodes:
                    node_c = val_to_rgb.color_ramp
                    color_ramp_Cycles_Location = val_to_rgb.location
                    num_elements = len(node_c.elements)
                    # Create a new Octane Gradient Map node if one doesn't exist
                    octane_image_texture_node = None
                    for node_oG in Colorramp.nodes:
                        if node_gradient in node_oG.bl_idname:
                            octane_image_texture_node = node_oG
                            break
                    if not octane_image_texture_node:
                        octane_image_texture_node = Colorramp.nodes.new(node_gradient)
                        octane_image_texture_node.name = "Gradient Tex" + val_to_rgb.name.split(".")[-1]
                        if node_gradient == "OctaneGradientMap":
                            octane_name = octane_image_texture_node.color_ramp_name
                    # If we are using Octane Helper group, get the color ramp elements from the helper group
                    if octane_elements:
                        ramp_items = octane_helper.nodes[0].color_ramp.elements
                    # Otherwise, get the color ramp elements from the node we just created
                    else:
                        ramp_items = octane_image_texture_node.color_ramp.elements
                    # Loop through all the color ramp elements and add new elements to the Octane Gradient Map
                    for i in range(num_elements):
                        elements = node_c.elements[i]
                        if i >= len(ramp_items):
                            ramp_items.new(elements.position)
                        ramp_items[i].position = elements.position
                        ramp_items[i].color = elements.color
        # Get the current file name and directory
        current_file_name = bpy.data.filepath
        current_directory = os.path.dirname(current_file_name)
        # Replace "Cycles" with "Octane" in the file name
        new_file_name = current_file_name.replace("Cycles", "Octane")
        # Save the file with the new name
        bpy.ops.wm.save_as_mainfile(filepath=new_file_name)
        # Get the directory of the current blend file
        #current_blend_file_dir = os.path.dirname(bpy.data.filepath)
        # Get the path to the tree node file
        #relative_path = os.path.join(current_blend_file_dir, "shaders/Shaders.blend/NodeTree")
        # Append the tree node group from the file
        #bpy.ops.wm.append(filename="AM268_001_Octane", directory=relative_path)
        #bpy.ops.wm.append(filename="AM266_001_Octane_Glass", directory=relative_path)
        #bpy.ops.wm.append(filename="AM268_001_Octane_Transmission", directory=relative_path)
        ## Get the appended tree node group
        #tree_node_group = bpy.data.node_groups["AM268_001_Octane"]
        # Get the name of the blend file
        #blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        #new_group_name = blend_file_name[:9]
        # Get the NodeTree to be added to materials
        #node_tree = bpy.data.node_groups["AM268_001_Octane"]
        # Set the new name of the node tree
        #node_tree.name = new_group_name + "_Octane"
        # Iterate over all materials in the scene
        #for material in bpy.data.materials:
           # if not "Dots Stroke" in material.name:
              #  nodetree= material.node_tree
              #  if nodetree:
                  # Add a "ShaderNodeGroup" node to the material's node tree
                #  group_node = material.node_tree.nodes.new("ShaderNodeGroup")
                  # Set the node's settings to use the new NodeTree
                 # group_node.node_tree = node_tree.copy()
                  # Set the name of the node to "Octane"
                 # group_node.name = node_tree.name 
                  # Position the node 1650 units to the right
                  #group_node.location.x += 1650
                  # Add a Material Output node to the material's node tree
                  #output_node = material.node_tree.nodes.new("ShaderNodeOutputMaterial")
                  # Position the Material Output node 2000 units to the right
                  #output_node.location.x += 2000
                  # Connect the group node to the Material Output node
                  #material.node_tree.links.new(group_node.outputs[0], output_node.inputs[0])
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Fabrics_inputs = bpy.context.window_manager.Cloth_textures.split(",")
        Nazwy_front =("_f_", "_F_", "front", "Front")
        Nazwy_Back =("_b_", "_B_", "Back", "back")
        #Dodawanie z Addonu
        addon_dir = os.path.dirname(__file__)
        shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        bpy.ops.wm.append(filename="AM268_001_Octane", directory=shaders_path)
        bpy.ops.wm.append(filename="AM266_001_Octane_Glass", directory=shaders_path)
        bpy.ops.wm.append(filename="AM268_001_Octane_Transmission", directory=shaders_path)
        tree_node_group = bpy.data.node_groups["AM268_001_Octane"]
        blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        new_group_name = blend_file_name[:9]
        # Ustawianie grupy Base
        node_tree = bpy.data.node_groups["AM268_001_Octane"]
        node_tree.name = new_group_name + "_Octane"
        #Ustawianie grupy glass:
        node_tree_glass = bpy.data.node_groups["AM266_001_Octane_Glass"]
        node_tree_glass.name = new_group_name + "_Octane_Glass"
        #Ustawienie grupy Transmission:
        node_tree_trans = bpy.data.node_groups["AM268_001_Octane_Transmission"]
        node_tree_trans.name = new_group_name + "_Octane_Transmission"
        for material in bpy.data.materials:
            #print(material.name)
            if not "Dots Stroke" in material.name:
                #print("Moj materail to: ", material.name)
                nodetree= material.node_tree
                if nodetree:
                    for node in nodetree.nodes:
                        Octane_Basic_Exists = False
                        for node1 in nodetree.nodes:
                            if "Octane" in node1.name:
                                if "Octane_Basic" in node1.label:
                                    Octane_Basic_Exists = True
                                    break
                        if not Octane_Basic_Exists:
                            group_node = nodetree.nodes.new("ShaderNodeGroup")
                            group_node.node_tree = node_tree.copy()
                            group_node.name = node_tree.name
                            group_node.label = "Octane_Basic"
                            group_node.location.x += 1650
                            Octane_out_exist = False
                            for node2 in nodetree.nodes:
                                if "Octane_Output" in node2.label:
                                    output_node = node2
                                    Octane_out_exist = True
                                    break
                            if not Octane_out_exist:
                                output_node = material.node_tree.nodes.new("ShaderNodeOutputMaterial")
                                output_node.label = "Octane_Output"
                                output_node.location.x += 2000
                            nodetree.links.new(group_node.outputs[0], output_node.inputs[0])
                            group_node.inputs[9].default_value = True
                            for node3 in nodetree.nodes:
                                if "mix_mat_oct" in node3.name or "Oct_Two_Side" in node3.name or "Back_Side" in node3.label or "First_Side" in node3.label or "Octane_Glass" in node3.label:
                                    nodetree.nodes.remove(node3)
                            Octane_out_exist = True
                        break
                    for node in nodetree.nodes:
                        if "Octane_Basic" in node.label:
                            group_oct_basic = node
                            for node in nodetree.nodes:
                                if node.label == "Base Color":
                                    nodetree.links.new(node.outputs[0], group_oct_basic.inputs[0])
                                if node.bl_idname == "OctaneRGBImage":
                                    for tekstura in Albedo:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 2.2
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[0])
                                    for tekstura in Reflection:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[1])
                                    for tekstura in RGH:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value =1.0
                                            node.inputs[3].default_value = False
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[2])
                                            if "gloss" in node.image.name.lower():
                                                node.inputs[3].default_value = True                                        
                                    for tekstura in Normal_names:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[3])
                                    for tekstura in Bumps_maps:
                                        if tekstura.lower() in node.image.name.lower():
                                            node.inputs[2].default_value = 1
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[6])
                                    for tekstura_o in Opacity:
                                        if tekstura_o.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[5])
                                    for tekstura_d in Displacement:
                                        if tekstura_d.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_oct_basic.inputs[5])
                                            node.inputs[2].default_value = 1
                                            group_oct_basic.inputs[11].default_value = 0.01
                                        else:
                                            group_oct_basic.inputs[11].default_value = 0.001
                        for node_r in nodetree.nodes:
                            if "Octane_Basic" in node_r.label:
                                group_oct_basic = node_r
                                for node in nodetree.nodes:
                                    if node.bl_idname == "OctaneRGBImage":
                                        for Tekstur_metal in Metal:
                                            if Tekstur_metal.lower() in node.image.name.lower():
                                                group_oct_basic.inputs[8].default_value = 1
                                                for tekstura in Reflection:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        node.inputs[2].default_value = 2.2
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[0])
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[1])
                                                for tekstura in RGH:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        node.inputs[2].default_value =1.0
                                                        node.inputs[3].default_value = False
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[2])
                                                        if "gloss" in node.image.name.lower():
                                                            node.inputs[3].default_value = True  
                                                for tekstura in Normal_names:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        node.inputs[2].default_value = 1
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[3])
                                                for tekstura in Bumps_maps:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        node.inputs[2].default_value = 1
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[6])
                                                for tekstura_o in Opacity:
                                                    if tekstura_o.lower() in node.image.name.lower():
                                                        nodetree.links.new(node.outputs[0], group_oct_basic.inputs[5])
        #Podlaczenie_glass                                                    
        for material_glass in bpy.data.materials:
            if not "Dots Stroke" in material_glass.name:
                nodetree_glass = material_glass.node_tree
                if nodetree_glass:
                    for node_glass in nodetree_glass.nodes:
                        if node_glass.bl_idname == "OctaneRGBImage":
                            for tekstura_glass in szklo:
                                if tekstura_glass.lower() in node_glass.image.name.lower():
                                    Octane_Glass_Exists = False
                                    for node1 in nodetree_glass.nodes:
                                        if "Octane" in node1.name:
                                            if "Octane_Glass" in node1.label:
                                                group_node_glass = node1
                                                Octane_Glass_Exists = True
                                                break
                                            else:
                                                nodetree_glass.nodes.remove(node1)
                                                Octane_Glass_Exists = False
                                            break
                                    if not Octane_Glass_Exists:
                                        group_node_glass = nodetree_glass.nodes.new("ShaderNodeGroup")
                                        group_node_glass.node_tree = node_tree_glass.copy()
                                        group_node_glass.name = node_tree_glass.name
                                        group_node_glass.label = "Octane_Glass"
                                        group_node_glass.location.x += 1650
                                        Octane_out_exist = False
                                        for node2 in nodetree_glass.nodes:
                                            if "Octane_Output" in node2.label:
                                                output_node = node2
                                                Octane_out_exist = True
                                                break
                                        if not Octane_out_exist:
                                            output_node = nodetree_glass.nodes.new("ShaderNodeOutputMaterial")
                                            output_node.label = "Octane_Output"
                                            output_node.location.x += 2000
                                        nodetree_glass.links.new(group_node_glass.outputs[0], output_node.inputs[0])
                                        #group_node_glass.inputs[9].default_value = True
                                        for node3 in nodetree_glass.nodes:
                                            if "mix_mat_oct" in node3.name or "Oct_Two_Side" in node3.name or "Back_Side" in node3.label or "First_Side" in node3.label:
                                                nodetree_glass.nodes.remove(node3)
                                        Material_Octane = True
                                    break
                            for tekstura_glass in szklo:
                                if tekstura_glass.lower() in node_glass.image.name.lower():
                                    for node_gm in nodetree_glass.nodes:
                                        if "Octane_Glass" in node_gm.label:
                                            print("Tego noda szukam:  ",node_gm.name)
                                            group_node = node_gm
                                            for node in nodetree_glass.nodes:
                                                if node.bl_idname == "OctaneRGBImage":
                                                    for tekstura in Albedo:
                                                        if tekstura.lower() in node.image.name.lower():
                                                            node.inputs[2].default_value = 2.2
                                                            nodetree_glass.links.new(node.outputs[0], node_gm.inputs[0])
                                                    for tekstura in Reflection:
                                                        if tekstura.lower() in node.image.name.lower():
                                                            node.inputs[2].default_value = 1
                                                            nodetree_glass.links.new(node.outputs[0], node_gm.inputs[2])
                                                    for tekstura in RGH:
                                                        if tekstura.lower() in node.image.name.lower():
                                                            node.inputs[2].default_value =1.0
                                                            nodetree_glass.links.new(node.outputs[0], node_gm.inputs[3])
                                                            if "gloss" in node.image.name.lower():
                                                                node.inputs[3].default_value = True
                                                    for tekstura in Normal_names:
                                                        if tekstura.lower() in node.image.name.lower():
                                                            node.inputs[2].default_value = 1
                                                            nodetree_glass.links.new(node.outputs[0], node_gm.inputs[4])
                                                    for tekstura in Bumps_maps:
                                                        if tekstura.lower() in node.image.name.lower():
                                                            node.inputs[2].default_value = 1
                                                            nodetree_glass.links.new(node.outputs[0], node_gm.inputs[5])
                                                    for tekstura_o in Opacity:
                                                        if tekstura_o.lower() in node.image.name.lower():
                                                            nodetree_glass.links.new(node.outputs[0], node_gm.inputs[6])
        #Dodanie Trans
        for material in bpy.data.materials:
            #print(material.name)
            if not "Dots Stroke" in material.name:
                #print("Moj materail to: ", material.name)
                nodetree = material.node_tree
                if nodetree:
                    for node_trans in nodetree.nodes:
                        if node_trans.bl_idname == "OctaneRGBImage":
                            for tekstura_tt in Trans:
                                #print("to jest moje Trans ", Trans)
                                #print("a to znajduje", tekstura_tt)               
                                if tekstura_tt.lower() in node_trans.image.name.lower():
                                    Material_Octane = False
                                    for node1 in nodetree.nodes:
                                        print(node1.name)
                                        if "Octane" in node1.name:
                                            if "First_Side" in node1.label:
                                                group_oct_trans = node1
                                                Material_Octane = True
                                                break
                                            else:
                                                nodetree.nodes.remove(node1)
                                                First_Side = False
                                    if not Material_Octane:
                                        group_oct_trans = material.node_tree.nodes.new("ShaderNodeGroup")
                                        group_oct_trans.node_tree = node_tree_trans.copy()
                                        group_oct_trans.name = node_tree_trans.name
                                        group_oct_trans.label = "First_Side"
                                        group_oct_trans.location.x += 1950
                                    Material_Octane = True
                                    Octane_out_exist = False
                                    for node2 in nodetree.nodes:
                                        if "Octane_Output" in node2.label:
                                            out_oct = node2
                                            Octane_out_exist = True
                                            break
                                    if not Octane_out_exist:
                                        out_oct = material.node_tree.nodes.new("ShaderNodeOutputMaterial")
                                        out_oct.label = "Octane_Output"
                                        out_oct.location.x += 2500
                                        Octane_out_exist = True
                                    nodetree.links.new(group_oct_trans.outputs[0], out_oct.inputs[0])
                                    #group_oct_trans.inputs[9].default_value = 1.0
                                    has_front_texture = False
                                    has_back_texture = False
                                    for node_1s in nodetree.nodes:
                                        if node_1s.bl_idname == "OctaneRGBImage":
                                            for front in Nazwy_front:
                                                if front.lower() in node_1s.image.name.lower():
                                                    has_front_texture = True
                                            for back in Nazwy_Back:
                                                if back.lower() in node_1s.image.name.lower():
                                                    has_back_texture = True
                                    if has_front_texture and has_back_texture:
                                        Two_Sided_Geometry = False
                                        for node_2s in nodetree.nodes:
                                            if "Two_sided_geo_oct" in node_2s.label:
                                                two_sided_geo = node_2s
                                                Two_Sided_Geometry = True
                                                break
                                        if not Two_Sided_Geometry:
                                            two_sided_geo = nodetree.nodes.new("OctanePolygonSide")
                                            two_sided_geo.label = "Two_sided_geo_oct"
                                            two_sided_geo.location = 1350, 745
                                            two_sided_geo.inputs[0].default_value = True
                                        for node_2s in nodetree.nodes:
                                            if node_2s.bl_idname == "OctaneRGBImage":
                                                for tekstura in Albedo:
                                                    if tekstura.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[0])
                                                        front_Albdeo = False
                                                        back_albedo = False
                                                        for node_af in nodetree.nodes:
                                                            if node_af.bl_idname == "OctaneRGBImage":
                                                                for tekstura_AF in Albedo:
                                                                    if tekstura_AF.lower() in node_af.image.name.lower() and any(name.lower() in node_af.image.name.lower() for name in Nazwy_front):
                                                                        Albedo_f = node_af
                                                                        front_Albdeo = True
                                                        for node_ab in nodetree.nodes:
                                                            if node_ab.bl_idname == "OctaneRGBImage":
                                                                for tekstura_AB in Albedo:
                                                                    if tekstura_AB.lower() in node_ab.image.name.lower() and any(name.lower() in node_ab.image.name.lower() for name in Nazwy_Back):
                                                                        Albedo_b = node_ab
                                                                        back_albedo = True
                                                        if front_Albdeo and back_albedo:
                                                            Two_sided_albedo = False
                                                            for node_two_albedo in nodetree.nodes:
                                                                if "MixAlbedoOct" in node_two_albedo.label:
                                                                    mix_albedo = node_two_albedo
                                                                    Two_sided_albedo = True
                                                                    break
                                                            if not Two_sided_albedo:
                                                                mix_albedo = nodetree.nodes.new("OctaneMixTexture")
                                                                mix_albedo.label = "MixAlbedoOct"
                                                                mix_albedo.location = 1730, 224
                                                                Two_sided_albedo = True
                                                            nodetree.links.new(Albedo_f.outputs[0], mix_albedo.inputs[1])
                                                            nodetree.links.new(Albedo_b.outputs[0], mix_albedo.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[0], mix_albedo.inputs[0])
                                                            nodetree.links.new(mix_albedo.outputs[0], group_oct_trans.inputs[0])
                                                for tekstura_t in Trans:
                                                    if tekstura_t.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[1])
                                                        front_trans = False
                                                        back_trans = False
                                                        for node_tf in nodetree.nodes:
                                                            if node_tf.bl_idname == "OctaneRGBImage":
                                                                for tekstura_TF in Trans:
                                                                    if tekstura_TF.lower() in node_tf.image.name.lower() and any(name.lower() in node_tf.image.name.lower() for name in Nazwy_front):
                                                                        trans_f = node_tf
                                                                        front_trans = True
                                                        for node_tb in nodetree.nodes:
                                                            if node_tb.type =="OctaneRGBImage":
                                                                for tekstura_TB in Trans:
                                                                    if tekstura_TB.lower() in node_tb.image.name.lower() and any(name.lower() in node_tb.image.name.lower() for name in Nazwy_Back):
                                                                        Trans_b = node_tb
                                                                        back_trans = True
                                                        if front_trans and back_trans:
                                                            Two_sided_trans = False
                                                            for node_two_trans in nodetree.nodes:
                                                                if "MixTransOct" in node_two_trans.label:
                                                                    mix_trans = node_two_trans
                                                                    Two_sided_trans = True
                                                                    break
                                                            if not Two_sided_trans:
                                                                mix_trans = nodetree.nodes.new("OctaneMixTexture")
                                                                mix_trans.label = "MixTransOct"
                                                                mix_trans.location = 1730, 14
                                                                Two_sided_reflection = True
                                                            nodetree.links.new(trans_f.outputs[0], mix_trans.inputs[1])
                                                            nodetree.links.new(Trans_b.outputs[0], mix_trans.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[0], mix_trans.inputs[0])
                                                            nodetree.links.new(mix_trans.outputs[0], group_oct_trans.inputs[1])
                                                for tekstura_r in Reflection:
                                                    if tekstura_r.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[5])
                                                        front_reflection = False
                                                        back_reflection = False
                                                        for node_rf in nodetree.nodes:
                                                            if node_rf.bl_idname == "OctaneRGBImage":
                                                                for tekstura_RF in Reflection:
                                                                    if tekstura_RF.lower() in node_rf.image.name.lower() and any(name.lower() in node_rf.image.name.lower() for name in Nazwy_front):
                                                                        Reflection_f = node_rf
                                                                        front_reflection = True
                                                        for node_rb in nodetree.nodes:
                                                            if node_rb.bl_idname == "OctaneRGBImage":
                                                                for tekstura_RB in Reflection:
                                                                    if tekstura_RB.lower() in node_rb.image.name.lower() and any(name.lower() in node_rb.image.name.lower() for name in Nazwy_Back):
                                                                        Reflection_b = node_rb
                                                                        back_reflection = True
                                                        if front_reflection and back_reflection:
                                                            Two_sided_reflection = False
                                                            for node_two_reflection in nodetree.nodes:
                                                                if "MixReflectOct" in node_two_reflection.label:
                                                                    mix_reflection = node_two_reflection
                                                                    Two_sided_reflection = True
                                                                    break
                                                            if not Two_sided_reflection:
                                                                mix_reflection = nodetree.nodes.new("OctaneMixTexture")
                                                                mix_reflection.label = "MixReflectOct"
                                                                mix_reflection.location = 1730, -85
                                                                Two_sided_reflection = True
                                                            nodetree.links.new(Reflection_f.outputs[0], mix_reflection.inputs[1])
                                                            nodetree.links.new(Reflection_b.outputs[0], mix_reflection.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[0], mix_reflection.inputs[0])
                                                            nodetree.links.new(mix_reflection.outputs[0], group_oct_trans.inputs[5])
                                                for tekstura_g in RGH:
                                                    if tekstura_g.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[6])
                                                        node_2s.inputs[3].default_value = False
                                                        if "gloss" in node_2s.image.name.lower():
                                                            node_2s.inputs[3].default_value = True        
                                                        front_roughness = False
                                                        back_roughness = False
                                                        for node_gf in nodetree.nodes:
                                                            if node_gf.bl_idname == "OctaneRGBImage":
                                                                for tekstura_GF in RGH:
                                                                    if tekstura_GF.lower() in node_gf.image.name.lower() and any(name.lower() in node_gf.image.name.lower() for name in Nazwy_front):
                                                                        rough_f = node_gf
                                                                        front_roughness = True
                                                        for node_gb in nodetree.nodes:
                                                            if node_gb.bl_idname == "OctaneRGBImage":
                                                                for tekstura_GB in RGH:
                                                                    if tekstura_GB.lower() in node_gb.image.name.lower() and any(name.lower() in node_gb.image.name.lower() for name in Nazwy_Back):
                                                                        Rough_b= node_gb
                                                                        back_roughness = True
                                                        if front_roughness and back_roughness:
                                                            Two_sided_roughness = False
                                                            for node_two_sided_roughness in nodetree.nodes:
                                                                if "MixRoughOct" in node_two_sided_roughness.label:
                                                                    mix_roughnessn = node_two_sided_roughness
                                                                    Two_sided_roughness = True
                                                                    break
                                                            if not Two_sided_roughness:
                                                                mix_roughnessn = nodetree.nodes.new("OctaneMixTexture")
                                                                mix_roughnessn.label = "MixRoughOct"
                                                                mix_roughnessn.location = 1730, -168
                                                                Two_sided_roughness = True
                                                            nodetree.links.new(rough_f.outputs[0], mix_roughnessn.inputs[1])
                                                            nodetree.links.new(Rough_b.outputs[0], mix_roughnessn.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[0], mix_roughnessn.inputs[0])
                                                            nodetree.links.new(mix_roughnessn.outputs[0], group_oct_trans.inputs[6])
                                                for tekstura_b in Bumps_maps:
                                                    if tekstura_b.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[8])
                                                        front_bump = False
                                                        back_bump = False
                                                        for node_bf in nodetree.nodes:
                                                            if node_bf.bl_idname == "OctaneRGBImage":
                                                                for tekstura_BF in Bumps_maps:
                                                                    if tekstura_BF.lower() in node_bf.image.name.lower() and any(name.lower() in node_bf.image.name.lower() for name in Nazwy_front):
                                                                        bump_f = node_bf
                                                                        front_bump = True
                                                        for node_bb in nodetree.nodes:
                                                            if node_bb.bl_idname == "OctaneRGBImage":
                                                                for tekstura_BB in Bumps_maps:
                                                                    if tekstura_BB.lower() in node_bb.image.name.lower() and any(name.lower() in node_bb.image.name.lower() for name in Nazwy_Back):
                                                                        bump_b= node_bb
                                                                        back_bump = True
                                                        if front_bump and back_bump:
                                                            Two_sided_bump = False
                                                            for node_two_sided_bump in nodetree.nodes:
                                                                if "MixBumpOct" in node_two_sided_bump.label:
                                                                    mix_bump = node_two_sided_bump
                                                                    Two_sided_bump = True
                                                                    break
                                                            if not Two_sided_bump:
                                                                mix_bump = nodetree.nodes.new("OctaneMixTexture")
                                                                mix_bump.label = "MixBumpOct"
                                                                mix_bump.location = 1730, -198
                                                                Two_sided_bump = True
                                                            nodetree.links.new(bump_f.outputs[0], mix_bump.inputs[1])
                                                            nodetree.links.new(bump_b.outputs[0], mix_bump.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[0], mix_bump.inputs[0])
                                                            nodetree.links.new(mix_bump.outputs[0], group_oct_trans.inputs[8])
                                                for tekstura_n in Normal_names:
                                                    if tekstura_n.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[7])
                                                        front_normal = False
                                                        back_normal = False
                                                        for node_nf in nodetree.nodes:
                                                            if node_nf.bl_idname == "OctaneRGBImage":
                                                                for tekstura_NF in Normal_names:
                                                                    if tekstura_NF.lower() in node_nf.image.name.lower() and any(name.lower() in node_nf.image.name.lower() for name in Nazwy_front):
                                                                        normal_f = node_nf
                                                                        front_normal = True
                                                        for node_nb in nodetree.nodes:
                                                            if node_nb.bl_idname == "OctaneRGBImage":
                                                                for tekstura_NB in Normal_names:
                                                                    if tekstura_NB.lower() in node_nb.image.name.lower() and any(name.lower() in node_nb.image.name.lower() for name in Nazwy_Back):
                                                                        normal_b= node_nb
                                                                        back_normal = True
                                                        if front_normal and back_normal:
                                                            Two_sided_normal = False
                                                            for node_two_sided_nrm in nodetree.nodes:
                                                                if "MixNormalOct" in node_two_sided_nrm.label:
                                                                    mix_nrm = node_two_sided_nrm
                                                                    Two_sided_normal = True
                                                                    break
                                                            if not Two_sided_normal:
                                                                mix_nrm = nodetree.nodes.new("OctaneMixTexture")
                                                                mix_nrm.label = "MixNormalOct"
                                                                mix_nrm.location = 1730, -212
                                                                Two_sided_normal = True
                                                            nodetree.links.new(normal_f.outputs[0], mix_nrm.inputs[1])
                                                            nodetree.links.new(normal_b.outputs[0], mix_nrm.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[0], mix_nrm.inputs[0])
                                                            nodetree.links.new(mix_nrm.outputs[0], group_oct_trans.inputs[7])
                                                for tekstura_o in Opacity:
                                                    if tekstura_o.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[12])
                                                        front_opacity = False
                                                        back_opacity = False
                                                        for node_of in nodetree.nodes:
                                                            if node_of.bl_idname == "OctaneRGBImage":
                                                                for tekstura_OF in Opacity:
                                                                    if tekstura_OF.lower() in node_of.image.name.lower() and any(name.lower() in node_of.image.name.lower() for name in Nazwy_front):
                                                                        opacity_f = node_of
                                                                        front_opacity = True
                                                        for node_ob in nodetree.nodes:
                                                            if node_ob.bl_idname == "OctaneRGBImage":
                                                                for tekstura_OB in Opacity:
                                                                    if tekstura_OB.lower() in node_ob.image.name.lower() and any(name.lower() in node_ob.image.name.lower() for name in Nazwy_Back):
                                                                        opacity_b = node_nb
                                                                        back_opacity = True
                                                        if front_opacity and back_opacity:
                                                            Two_sided_opacity = False
                                                            for node_sided_opacity in nodetree.nodes:
                                                                if "MixOpacityOct" in node_sided_opacity.label:
                                                                    mix_opacity = node_sided_opacity
                                                                    Two_sided_opacity = True
                                                                    break
                                                            if not Two_sided_normal:
                                                                mix_opacity = nodetree.nodes.new("OctaneMixTexture")
                                                                mix_opacity.label = "MixOpacityOct"
                                                                mix_opacity.location = 1730, -311
                                                                Two_sided_opacity = True
                                                            nodetree.links.new(opacity_f.outputs[0], mix_opacity.inputs[1])
                                                            nodetree.links.new(opacity_b.outputs[0], mix_opacity.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[0], mix_opacity.inputs[0])
                                                            nodetree.links.new(mix_opacity.outputs[0], group_oct_trans.inputs[12])
                                                for tekstura_d in Displacement:
                                                    if tekstura_d.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[13])
                                                        front_disp = False
                                                        back_disp = False
                                                        for node_df in nodetree.nodes:
                                                            if node_df.bl_idname == "OctaneRGBImage":
                                                                for tekstura_DF in Displacement:
                                                                    if tekstura_DF.lower() in node_df.image.name.lower() and any(name.lower() in node_df.image.name.lower() for name in Nazwy_front):
                                                                        disp_f = node_df
                                                                        front_disp = True
                                                        for node_db in nodetree.nodes:
                                                            if node_db.bl_idname == "OctaneRGBImage":
                                                                for tekstura_DB in Displacement:
                                                                    if tekstura_DB.lower() in node_db.image.name.lower() and any(name.lower() in node_db.image.name.lower() for name in Nazwy_Back):
                                                                        disp_b = node_db
                                                                        back_disp = True
                                                        if front_disp and back_disp:
                                                            Two_sided_disp = False
                                                            for node_sided_disp in nodetree.nodes:
                                                                if "MixDispOct" in node_sided_disp.label:
                                                                    mix_disp = node_sided_disp
                                                                    Two_sided_disp = True
                                                                    break
                                                            if not Two_sided_disp:
                                                                mix_disp = nodetree.nodes.new("OctaneMixTexture")
                                                                mix_disp.label = "MixDispOct"
                                                                mix_disp.location = 1730, -355
                                                                Two_sided_disp = True
                                                            nodetree.links.new(disp_f.outputs[0], mix_disp.inputs[1])
                                                            nodetree.links.new(disp_b.outputs[0], mix_disp.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[0], mix_disp.inputs[0])
                                                            nodetree.links.new(mix_disp.outputs[0], group_oct_trans.inputs[12])
                                    else:
                                        for node_2s in nodetree.nodes:
                                            if node_2s.bl_idname == "OctaneRGBImage":
                                                for tekstura in Albedo:
                                                    if tekstura.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[0])
                                                for tekstura_t in Trans:
                                                    if tekstura_t.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[1]) 
                                                for tekstura_r in Reflection:
                                                    if tekstura_r.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[5])  
                                                for tekstura_g in RGH:
                                                    if tekstura_g.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[6])
                                                        node_2s.inputs[3].default_value = False
                                                        if "gloss" in node_2s.image.name.lower():
                                                            node_2s.inputs[3].default_value = True  
                                                for tekstura_b in Bumps_maps:
                                                    if tekstura_b.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[8]) 
                                                for tekstura_n in Normal_names:
                                                    if tekstura_n.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[7])
                                                for tekstura_o in Opacity:
                                                    if tekstura_o.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[12])
                                                for tekstura_d in Displacement:
                                                    if tekstura_d.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_oct_trans.inputs[13])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Cleaning_Luxcor_Nodes_6A712(bpy.types.Operator):
    bl_idname = "sna.cleaning_luxcor_nodes_6a712"
    bl_label = "Cleaning_Luxcor_Nodes"
    bl_description = "It Cleans not used Luxcore Nodes"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for mat in bpy.data.materials:
            if "luxcore" in mat:
                node_tree = mat.luxcore.node_tree
                if node_tree:
                    #print(node_tree)
                    for texture_node in node_tree.nodes:
                        if "Imagemap" in texture_node.name:
                            #Sprawdzenie czy tekstura jest do czegoś podłączona
                            if not any(socket.is_linked for socket in texture_node.outputs):
                                node_tree.nodes.remove(texture_node)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Lux_To_Cyc_8902C(bpy.types.Operator):
    bl_idname = "sna.lux_to_cyc_8902c"
    bl_label = "Lux_to_Cyc"
    bl_description = "Goes back to Cycles "
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for area in bpy.context.screen.areas:
            if area.type == 'NODE_EDITOR':
                for space in area.spaces:
                    if space.type == 'NODE_EDITOR' and space.tree_type == 'luxcore_material_nodes':
                        old_tree = space.tree_type
                        space.tree_type = 'ShaderNodeTree'
                        area.tag_redraw()
                        break
        bpy.context.scene.render.engine = 'CYCLES'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Cycles_Import_7Fcb0(bpy.types.Operator):
    bl_idname = "sna.cycles_import_7fcb0"
    bl_label = "Cycles_Import"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        for im in list(bpy.data.images):
            if im.type != "RENDER_RESULT":
                im.name = im.filepath.split(os.sep)[-1]
        for material in bpy.data.materials:
            if not "Dots Stroke" in material.name:
                nodetree = material.node_tree
                if nodetree:
                    for node in nodetree.nodes:
                        if node.type == "TEX_IMAGE":
                            texture_name = node.image.name
                            if "map" in texture_name.lower():
                                continue
                            last_underscore_index = texture_name.rfind("_")
                            material_name = texture_name[:last_underscore_index]
                            material.name = material_name
                            break
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Fabrics_inputs = bpy.context.window_manager.Cloth_textures.split(",")
        # Set the View Transform to Filmic
        bpy.context.scene.view_settings.view_transform = 'Filmic'
        # Pętla przez wszystkie materiały w scenie
        for mat in bpy.data.materials:
            # Sprawdzenie czy materiał ma nazwę kończącą się na "_F" lub "_B"
            if mat.name.endswith("_F") or mat.name.endswith("_B"):
                # Przypisanie nowej nazwy bez ostatnich dwóch znaków
                new_name = mat.name[:-2]
                # Zmiana nazwy materiału
                mat.name = new_name
        # Get all materials in the scene
        materials = bpy.data.materials
        # Set the Viewport Display metallic value to 0.0 for all materials
        for material in materials:
            material.metallic = 0.0
            material.roughness = 0.4
        # Find the first empty object in the scene
        for obj in bpy.context.scene.objects:
            if obj.type == 'MESH':
                # Set the file name and collection name to the first 9 characters of the empty object's name
                # with the "_Cycles" suffix
                filename = obj.name[:9] + "_Cycles"
                collection_name = obj.name[:9] + "_Cycles"
                break
        # Rename all the collections in the scene
        for collection in bpy.data.collections:
            collection.name = collection_name
        #change Origin:
        for obj in bpy.context.scene.objects:
            if obj.type == 'MESH':
                try:
                    obj.select_set(True)
                    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
                except Exception as e:
                    print(f"Błąd dla obiektu {obj.name}: {e}")
                finally:
                    obj.select_set(False)
        #Change name:
        for obj in bpy.context.scene.objects:
            if obj.type == 'MESH':
                mesh = obj.data
                mesh.name = obj.name
            else:
                print("Nie właściwy obiekt")
        #Rename UV 
        for obj in bpy.context.scene.objects:
            if obj.type == 'MESH':
                if obj.data.uv_layers:
                    obj.data.uv_layers[0].name = "UV Map"
                else:
                    obj.data.uv_layers.new(name="UV Map")
            # Get all material slots in the scene
        material_slots = bpy.data.materials
        # Iterate over each material slot
        for material in material_slots:
            if hasattr(material, 'node_tree') and hasattr(material.node_tree, 'nodes'):
                nodes = material.node_tree.nodes
                 # Check if the principled BSDF node exists
                if "Principled BSDF" in nodes:
                    # Delete the principled BSDF node
                    nodes.remove(nodes["Principled BSDF"])
                # Check if the material output node exists
                if "Material Output" in nodes:
                    # Delete the material output node
                    nodes.remove(nodes["Material Output"])
                # Check if the Normal Map node exists
                if "Normal Map" in nodes:
                    # Delete the Normal Map node
                    nodes.remove(nodes["Normal Map"])
            else:
                print("Material node tree not found")
        print("Test nowy")
        moje_tekstury = os.path.join(bpy.path.abspath("//"), "textures")
        print(moje_tekstury)
        exclude_material = False
        short_prefix_materials = []
        for mat in bpy.data.materials:
            drzewo_nodow = mat.node_tree
            if drzewo_nodow:
                prefix = mat.name
                original_prefix = prefix
                exclude_material = False
                for texture_node in drzewo_nodow.nodes:
                    if texture_node.type == 'TEX_IMAGE' and hasattr(texture_node.image, 'name'):
                        #Pobierz nazwę tekstury
                        tekstura = texture_node.image.name
                        # Znajdź wspólną część nazwy prefixu i tekstury
                        for i in range(min(len(prefix), len(tekstura))):
                            if i >= len(prefix) or i >= len(tekstura):
                                break
                            if prefix[i] != tekstura[i]:
                                prefix = prefix[:i]
                                break
                pos_y = 600
                for file in os.listdir(moje_tekstury):
                    if len(original_prefix) > 10:
                        if file.startswith(original_prefix) and file not in [texture_node.image.name for texture_node in drzewo_nodow.nodes if texture_node.type == 'TEX_IMAGE']:
                            print("Dodaję brakującą teksturę: ", file)
                            new_node = drzewo_nodow.nodes.new(type="ShaderNodeTexImage")
                            new_node.image = bpy.data.images.load(os.path.join(moje_tekstury, file))
                            new_node.location.x -= 610
                            new_node.location.y = pos_y
                            pos_y -= 350
                            match = False
                            for word in Albedo:
                                if word in file:
                                    new_node.image.colorspace_settings.name = 'sRGB'
                                    match = True
                                    break
                            for word_trans in Trans:
                                if word_trans.lower() in file.lower():
                                    new_node.image.colorspace_settings.name = 'sRGB'
                                    match = True
                                    break
                            if not match:
                                new_node.image.colorspace_settings.name = 'Non-Color' 
                    if len(original_prefix) <= 10:
                        if mat.name not in short_prefix_materials:
                            short_prefix_materials.append(mat.name)
                            #bpy.ops.wm.cyc_im('INVOKE_DEFAULT')
                            mat.Short_prefix = True
                        break
        bpy.ops.wm.cyc_im('INVOKE_DEFAULT')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator001_9Eadc(bpy.types.Operator):
    bl_idname = "sna.operator001_9eadc"
    bl_label = "Operator.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        Albedo = bpy.context.window_manager.Albedo_names.split(",")
        Reflection = bpy.context.window_manager.Reflection_names.split(",")
        RGH = bpy.context.window_manager.Roughness_names.split(",")
        Metal = bpy.context.window_manager.Metal_names.split(",")
        Normal_names= bpy.context.window_manager.Normal_names.split(",")
        Bumps_maps = bpy.context.window_manager.Bump_names.split(",")
        szklo = bpy.context.window_manager.Glass_names.split(",")
        Trans = bpy.context.window_manager.Transmission_names.split(",")
        Opacity = bpy.context.window_manager.Opacity_names.split(",")
        Displacement = bpy.context.window_manager.Displacement_names.split(",")
        Fabrics_inputs = bpy.context.window_manager.Cloth_textures.split(",")
        Nazwy_front =("_f_", "_F_", "front", "Front")
        Nazwy_Back =("_b_", "_B_", "Back", "back")
        #Dodawanie grupy z Addonu:
        addon_dir = os.path.dirname(__file__)
        shaders_path = os.path.join(addon_dir, "assets/Shaders.blend/NodeTree")
        bpy.ops.wm.append(filename="AM266_001_Cycles", directory=shaders_path)
        bpy.ops.wm.append(filename="AM266_001_Cycles_Transmission", directory=shaders_path)
        bpy.ops.wm.append(filename="AM266_003_Cycles_Transmission_Two_sided", directory=shaders_path)
        bpy.ops.wm.append(filename="AM251_010_Cycles_Solid_glass", directory=shaders_path)
        # Get the appended tree node group
        tree_node_group = bpy.data.node_groups["AM266_001_Cycles"]
        # Get the name of the blend file
        blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)
        # Use the first 9 characters of the blend file name as the new group name
        new_group_name = blend_file_name[:9]
        # Get the NodeTree to be added to materials
        node_tree = bpy.data.node_groups["AM266_001_Cycles"]
        # Set the new name of the node tree
        node_tree.name = new_group_name + "_Cycles_Base"
        node_tree_trans = bpy.data.node_groups["AM266_001_Cycles_Transmission"]
        node_tree_trans.name = new_group_name + "_Cycles_Transmission"
        node_tree_two_sided = bpy.data.node_groups["AM266_003_Cycles_Transmission_Two_sided"]
        node_tree_two_sided.name = new_group_name + "_Cycles_Transmission_Two_sided"
        node_tree_g = bpy.data.node_groups["AM251_010_Cycles_Solid_glass"]
        node_tree_g.name = new_group_name + "_Cycles_Solid_glass"
         # Iterate over all materials in the scene
        for material in bpy.data.materials:
            #print(material.name)
            if not "Dots Stroke" in material.name:
                #print("Moj materail to: ", material.name)
                nodetree= material.node_tree
                if nodetree:
                    for node in nodetree.nodes:
                        Cycles_Basic_Exists = False
                        for node1 in nodetree.nodes:
                            if "Cycles" in node1.name:
                                if "Cycles_basic" in node1.label:
                                    group_node = node1
                                    Cycles_Basic_Exists = True
                                    break
                                else:
                                    nodetree.nodes.remove(node1)
                                    Cycles_Basic_Exists = False
                        if not Cycles_Basic_Exists:
                            group_node = nodetree.nodes.new("ShaderNodeGroup")
                            group_node.node_tree = node_tree.copy()
                            group_node.name = node_tree.name
                            group_node.label = "Cycles_basic"
                        break
                    for node in nodetree.nodes:
                        if "Cycles_basic" in node.label:
                            group_cyc_basic = node
                            for node in nodetree.nodes:
                                if node.type == "TEX_IMAGE":
                                    for tekstura in Albedo:
                                        if tekstura.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[0])
                                    for tekstura in Reflection:
                                        if tekstura.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[2])
                                            nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[3])
                                            group_cyc_basic.inputs[4].default_value = 1
                                    for tekstura in RGH:
                                        if tekstura.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[3])
                                            group_cyc_basic.inputs[4].default_value = 0
                                            if "gloss" in node.image.name.lower():
                                                group_cyc_basic.inputs[4].default_value = 1  
                                    for tekstura in Bumps_maps:
                                        if tekstura.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[8])
                                            group_cyc_basic.inputs[11].default_value = 1                                     
                                    for tekstura in Normal_names:
                                        if tekstura.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[8])
                                            group_cyc_basic.inputs[11].default_value = 0
                                    for tekstura_o in Opacity:
                                        if tekstura_o.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[15])
                                    for tekstura_d in Displacement:
                                        if tekstura_d.lower() in node.image.name.lower():
                                            nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[13])
                        for node_r in nodetree.nodes:
                            if "Cycles_basic" in node_r.label:
                                group_cyc_basic = node_r
                                for node in nodetree.nodes:
                                    if node.type == "TEX_IMAGE":
                                        for Tekstur_metal in Metal:
                                            if Tekstur_metal.lower() in node.image.name.lower():
                                                group_cyc_basic.inputs[5].default_value = 1
                                                for tekstura in Albedo:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[0])
                                                        group_cyc_basic.inputs[1].default_value = 0.8
                                                        node.image.colorspace_settings.name = 'sRGB'
                                                for tekstura in Reflection:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        node.image.colorspace_settings.name = 'sRGB'
                                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[0])
                                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[2])
                                                        group_cyc_basic.inputs[1].default_value = 1
                                                for tekstura in RGH:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[3])
                                                        group_cyc_basic.inputs[4].default_value = 0 
                                                        if "gloss" in node.image.name.lower():
                                                            group_cyc_basic.inputs[4].default_value = 1 
                                                for tekstura in Bumps_maps:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        group_cyc_basic.inputs[12].default_value = 1
                                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[8])
                                                for tekstura in Normal_names:
                                                    if tekstura.lower() in node.image.name.lower():
                                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[8])
                                                        group_cyc_basic.inputs[12].default_value = 0
                                                for tekstura_o in Opacity:
                                                    if tekstura_o.lower() in node.image.name.lower():
                                                        nodetree.links.new(node.outputs[0], group_cyc_basic.inputs[10])
         # Iterate over all materials in the scene
        for material in bpy.data.materials:
            #print(material.name)
            if not "Dots Stroke" in material.name:
                #print("Moj materail to: ", material.name)
                nodetree= material.node_tree
                if nodetree:                                                
                    for node_g in nodetree.nodes:
                        if node_g.type =="TEX_IMAGE":
                            for tekstura_g in szklo:
                                if tekstura_g.lower() in node_g.image.name.lower():
                                    Cycles_glass_Exists = False
                                    for node1 in nodetree.nodes:
                                        if "Cycles" in node1.name:
                                            if "Cycles_Solid_glass" in node1.label:
                                                group_node = node1
                                                Cycles_glass_Exists = True
                                                break
                                            else:
                                                nodetree.nodes.remove(node1)
                                                Cycles_glass_Exists = False
                                    if not Cycles_glass_Exists:
                                        group_node = nodetree.nodes.new("ShaderNodeGroup")
                                        group_node.node_tree = node_tree_g.copy()
                                        group_node.name = node_tree.name
                                        group_node.label = "Cycles_Solid_glass"
                                    break
                            for node in nodetree.nodes:
                                if "Cycles_Solid_glass" in node.label:
                                    group_cyc_glass = node
                                    for node in nodetree.nodes:
                                        if node.type == "TEX_IMAGE":
                                            for tekstura_glass in szklo:
                                                if tekstura_glass.lower() in node.image.name.lower():
                                                    for tekstura in Albedo:
                                                        if tekstura.lower() in node.image.name.lower():
                                                            nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[0])
                                                            group_cyc_glass.inputs[1].default_value = 0.01
                                                    for tekstura in Reflection:
                                                        if tekstura.lower() in node.image.name.lower():
                                                            nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[3])
                                                    for tekstura in RGH:
                                                        if tekstura.lower() in node.image.name.lower():
                                                            nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[4])
                                                            group_cyc_glass.inputs[6].default_value = 0
                                                            if "gloss" in node.image.name.lower():
                                                                group_cyc_glass.inputs[6].default_value = 1
                                                    for tekstura in Bumps_maps:
                                                        if tekstura.lower() in node.image.name.lower():
                                                            nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[5])
                                                            group_cyc_glass.inputs[10].default_value = 1 
                                                            group_cyc_glass.inputs[19].default_value = 0.1
                                                    for tekstura in Normal_names:
                                                        if tekstura.lower() in node.image.name.lower():
                                                            nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[5])
                                                            group_cyc_glass.inputs[10].default_value = 0
                                                    for tekstura_o in Opacity:
                                                        if tekstura_o.lower() in node.image.name.lower():
                                                            nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[8])
                                                    #for tekstura_d in Displacement:
                                                        #if tekstura_d.lower() in node.image.name.lower():
                                                            #nodetree.links.new(node.outputs[0], group_cyc_glass.inputs[13])
         # Iterate over all materials in the scene
        for material in bpy.data.materials:
            #print(material.name)
            if not "Dots Stroke" in material.name:
                #print("Moj materail to: ", material.name)
                nodetree= material.node_tree
                if nodetree:                                                
                    for node_tr in nodetree.nodes:
                        if node_tr.type == "TEX_IMAGE":
                            for tekstura_t in Trans:
                                if tekstura_t.lower() in node_tr.image.name.lower():
                                    Cycles_Transission_Exists = False
                                    for node1 in nodetree.nodes:
                                        if "Cycles" in node1.name:
                                            if "Cycles_Transission_One_Side" in node1.label:
                                                group_node = node1
                                                Cycles_Transission_Exists = True
                                                break
                                            else:
                                                nodetree.nodes.remove(node1)
                                                Cycles_Transission_Exists = False
                                    if not Cycles_Transission_Exists:
                                        group_node = nodetree.nodes.new("ShaderNodeGroup")
                                        group_node.node_tree = node_tree_trans.copy()
                                        group_node.name = node_tree.name
                                        group_node.label = "Cycles_Transission_One_Side"
                                        group_node.location = 210, 160
                                    Cycles_Transission_Exists = True
                                    has_front_texture = False
                                    has_back_texture = False
                                    for node_1s in nodetree.nodes:
                                        if node_1s.type == "TEX_IMAGE":
                                            for front in Nazwy_front:
                                                if front.lower() in node_1s.image.name.lower():
                                                    has_front_texture = True
                                            for back in Nazwy_Back:
                                                if back.lower() in node_1s.image.name.lower():
                                                    has_back_texture = True
                                    if has_front_texture and has_back_texture:
                                        Two_Sided_Geometry = False
                                        for node_2s in nodetree.nodes:
                                            if "Two_sided_geo_Cycles" in node_2s.label:
                                                two_sided_geo = node_2s
                                                Two_Sided_Geometry = True
                                                break
                                        if not Two_Sided_Geometry:
                                            two_sided_geo = nodetree.nodes.new("ShaderNodeNewGeometry")
                                            two_sided_geo.label = "Two_sided_geo_Cycles"
                                            two_sided_geo.location = -219, 875
                                        for node_2s in nodetree.nodes:
                                            if node_2s.type == "TEX_IMAGE":
                                                for tekstura in Albedo:
                                                    if tekstura.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[0])
                                                        front_Albdeo = False
                                                        back_albedo = False
                                                        for node_af in nodetree.nodes:
                                                            if node_af.type == "TEX_IMAGE":
                                                                for tekstura_AF in Albedo:
                                                                    if tekstura_AF.lower() in node_af.image.name.lower() and any(name.lower() in node_af.image.name.lower() for name in Nazwy_front):
                                                                        Albedo_f = node_af
                                                                        front_Albdeo = True
                                                        for node_ab in nodetree.nodes:
                                                            if node_ab.type == "TEX_IMAGE":
                                                                for tekstura_AB in Albedo:
                                                                    if tekstura_AB.lower() in node_ab.image.name.lower() and any(name.lower() in node_ab.image.name.lower() for name in Nazwy_Back):
                                                                        Albedo_b = node_ab
                                                                        back_albedo = True
                                                        if front_Albdeo and back_albedo:
                                                            Two_sided_albedo = False
                                                            for node_two_albedo in nodetree.nodes:
                                                                if "MixAlbedoCycles" in node_two_albedo.label:
                                                                    mix_albedo = node_two_albedo
                                                                    Two_sided_albedo = True
                                                                    break
                                                            if not Two_sided_albedo:
                                                                mix_albedo = nodetree.nodes.new("ShaderNodeMixRGB")
                                                                mix_albedo.label = "MixAlbedoCycles"
                                                                mix_albedo.location = 6, 290
                                                                Two_sided_albedo = True
                                                            nodetree.links.new(Albedo_f.outputs[0], mix_albedo.inputs[1])
                                                            nodetree.links.new(Albedo_b.outputs[0], mix_albedo.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[6], mix_albedo.inputs[0])
                                                            nodetree.links.new(mix_albedo.outputs[0], group_node.inputs[0])
                                                for tekstura_t in Trans:
                                                    if tekstura_t.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[1])
                                                        front_trans = False
                                                        back_trans = False
                                                        for node_tf in nodetree.nodes:
                                                            if node_tf.type == "TEX_IMAGE":
                                                                for tekstura_TF in Trans:
                                                                    if tekstura_TF.lower() in node_tf.image.name.lower() and any(name.lower() in node_tf.image.name.lower() for name in Nazwy_front):
                                                                        trans_f = node_tf
                                                                        front_trans = True
                                                        for node_tb in nodetree.nodes:
                                                            if node_tb.type =="TEX_IMAGE":
                                                                for tekstura_TB in Trans:
                                                                    if tekstura_TB.lower() in node_tb.image.name.lower() and any(name.lower() in node_tb.image.name.lower() for name in Nazwy_Back):
                                                                        Trans_b = node_tb
                                                                        back_trans = True
                                                        if front_trans and back_trans:
                                                            Two_sided_trans = False
                                                            for node_two_trans in nodetree.nodes:
                                                                if "MixTransCycles" in node_two_trans.label:
                                                                    mix_trans = node_two_trans
                                                                    Two_sided_trans = True
                                                                    break
                                                            if not Two_sided_trans:
                                                                mix_trans = nodetree.nodes.new("ShaderNodeMixRGB")
                                                                mix_trans.label = "MixTransCycles"
                                                                mix_trans.location = 6, 216
                                                                Two_sided_reflection = True
                                                            nodetree.links.new(trans_f.outputs[0], mix_trans.inputs[1])
                                                            nodetree.links.new(Trans_b.outputs[0], mix_trans.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[6], mix_trans.inputs[0])
                                                            nodetree.links.new(mix_trans.outputs[0], group_node.inputs[1])
                                                for tekstura_r in Reflection:
                                                    if tekstura_r.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[2])
                                                        front_reflection = False
                                                        back_reflection = False
                                                        for node_rf in nodetree.nodes:
                                                            if node_rf.type == "TEX_IMAGE":
                                                                for tekstura_RF in Reflection:
                                                                    if tekstura_RF.lower() in node_rf.image.name.lower() and any(name.lower() in node_rf.image.name.lower() for name in Nazwy_front):
                                                                        Reflection_f = node_rf
                                                                        front_reflection = True
                                                        for node_rb in nodetree.nodes:
                                                            if node_rb.type == "TEX_IMAGE":
                                                                for tekstura_RB in Reflection:
                                                                    if tekstura_RB.lower() in node_rb.image.name.lower() and any(name.lower() in node_rb.image.name.lower() for name in Nazwy_Back):
                                                                        Reflection_b = node_rb
                                                                        back_reflection = True
                                                        if front_reflection and back_reflection:
                                                            Two_sided_reflection = False
                                                            for node_two_reflection in nodetree.nodes:
                                                                if "MixReflectCycles" in node_two_reflection.label:
                                                                    mix_reflection = node_two_reflection
                                                                    Two_sided_reflection = True
                                                                    break
                                                            if not Two_sided_reflection:
                                                                mix_reflection = nodetree.nodes.new("ShaderNodeMixRGB")
                                                                mix_reflection.label = "MixReflectCycles"
                                                                mix_reflection.location = 6, 120
                                                                Two_sided_reflection = True
                                                            nodetree.links.new(Reflection_f.outputs[0], mix_reflection.inputs[1])
                                                            nodetree.links.new(Reflection_b.outputs[0], mix_reflection.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[6], mix_reflection.inputs[0])
                                                            nodetree.links.new(mix_reflection.outputs[0], group_node.inputs[2])
                                                for tekstura_g in RGH:
                                                    if tekstura_g.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[3])
                                                        group_node.inputs[12].default_value = 0.0  
                                                        if "gloss" in node_2s.image.name.lower():
                                                            group_node.inputs[12].default_value = 1.0       
                                                        front_roughness = False
                                                        back_roughness = False
                                                        for node_gf in nodetree.nodes:
                                                            if node_gf.type == "TEX_IMAGE":
                                                                for tekstura_GF in RGH:
                                                                    if tekstura_GF.lower() in node_gf.image.name.lower() and any(name.lower() in node_gf.image.name.lower() for name in Nazwy_front):
                                                                        rough_f = node_gf
                                                                        front_roughness = True
                                                        for node_gb in nodetree.nodes:
                                                            if node_gb.type == "TEX_IMAGE":
                                                                for tekstura_GB in RGH:
                                                                    if tekstura_GB.lower() in node_gb.image.name.lower() and any(name.lower() in node_gb.image.name.lower() for name in Nazwy_Back):
                                                                        Rough_b= node_gb
                                                                        back_roughness = True
                                                        if front_roughness and back_roughness:
                                                            Two_sided_roughness = False
                                                            for node_two_sided_roughness in nodetree.nodes:
                                                                if "MixRoughCycles" in node_two_sided_roughness.label:
                                                                    mix_roughnessn = node_two_sided_roughness
                                                                    Two_sided_roughness = True
                                                                    break
                                                            if not Two_sided_roughness:
                                                                mix_roughnessn = nodetree.nodes.new("ShaderNodeMixRGB")
                                                                mix_roughnessn.label = "MixRoughCycles"
                                                                mix_roughnessn.location = 6, 75
                                                                Two_sided_roughness = True
                                                            nodetree.links.new(rough_f.outputs[0], mix_roughnessn.inputs[1])
                                                            nodetree.links.new(Rough_b.outputs[0], mix_roughnessn.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[6], mix_roughnessn.inputs[0])
                                                            nodetree.links.new(mix_roughnessn.outputs[0], group_node.inputs[3])
                                                for tekstura_b in Bumps_maps:
                                                    if tekstura_b.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[4])
                                                        group_node.inputs[16].default_value = 1.0  
                                                        front_bump = False
                                                        back_bump = False
                                                        for node_bf in nodetree.nodes:
                                                            if node_bf.type == "TEX_IMAGE":
                                                                for tekstura_BF in Bumps_maps:
                                                                    if tekstura_BF.lower() in node_bf.image.name.lower() and any(name.lower() in node_bf.image.name.lower() for name in Nazwy_front):
                                                                        bump_f = node_bf
                                                                        front_bump = True
                                                        for node_bb in nodetree.nodes:
                                                            if node_bb.type == "TEX_IMAGE":
                                                                for tekstura_BB in Bumps_maps:
                                                                    if tekstura_BB.lower() in node_bb.image.name.lower() and any(name.lower() in node_bb.image.name.lower() for name in Nazwy_Back):
                                                                        bump_b= node_bb
                                                                        back_bump = True
                                                        if front_bump and back_bump:
                                                            Two_sided_bump = False
                                                            for node_two_sided_bump in nodetree.nodes:
                                                                if "MixBumpCycles" in node_two_sided_bump.label:
                                                                    mix_bump = node_two_sided_bump
                                                                    Two_sided_bump = True
                                                                    break
                                                            if not Two_sided_bump:
                                                                mix_bump = nodetree.nodes.new("ShaderNodeMixRGB")
                                                                mix_bump.label = "MixBumpCycles"
                                                                mix_bump.location = 6, 13
                                                                Two_sided_bump = True
                                                            nodetree.links.new(bump_f.outputs[0], mix_bump.inputs[1])
                                                            nodetree.links.new(bump_b.outputs[0], mix_bump.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[6], mix_bump.inputs[0])
                                                            nodetree.links.new(mix_bump.outputs[0], group_node.inputs[4])
                                                for tekstura_n in Normal_names:
                                                    if tekstura_n.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[4])
                                                        group_node.inputs[16].default_value = 0.0
                                                        front_normal = False
                                                        back_normal = False
                                                        for node_nf in nodetree.nodes:
                                                            if node_nf.type == "TEX_IMAGE":
                                                                for tekstura_NF in Normal_names:
                                                                    if tekstura_NF.lower() in node_nf.image.name.lower() and any(name.lower() in node_nf.image.name.lower() for name in Nazwy_front):
                                                                        normal_f = node_nf
                                                                        front_normal = True
                                                        for node_nb in nodetree.nodes:
                                                            if node_nb.type == "TEX_IMAGE":
                                                                for tekstura_NB in Normal_names:
                                                                    if tekstura_NB.lower() in node_nb.image.name.lower() and any(name.lower() in node_nb.image.name.lower() for name in Nazwy_Back):
                                                                        normal_b= node_nb
                                                                        back_normal = True
                                                        if front_normal and back_normal:
                                                            Two_sided_normal = False
                                                            for node_two_sided_nrm in nodetree.nodes:
                                                                if "MixNormalCycles" in node_two_sided_nrm.label:
                                                                    mix_nrm = node_two_sided_nrm
                                                                    Two_sided_normal = True
                                                                    break
                                                            if not Two_sided_normal:
                                                                mix_nrm = nodetree.nodes.new("ShaderNodeMixRGB")
                                                                mix_nrm.label = "MixNormalCycles"
                                                                mix_nrm.location = 6, -124
                                                                Two_sided_normal = True
                                                            nodetree.links.new(normal_f.outputs[0], mix_nrm.inputs[1])
                                                            nodetree.links.new(normal_b.outputs[0], mix_nrm.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[6], mix_nrm.inputs[0])
                                                            nodetree.links.new(mix_nrm.outputs[0], group_node.inputs[4])
                                                for tekstura_o in Opacity:
                                                    if tekstura_o.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[5])
                                                        front_opacity = False
                                                        back_opacity = False
                                                        for node_of in nodetree.nodes:
                                                            if node_of.type == "TEX_IMAGE":
                                                                for tekstura_OF in Opacity:
                                                                    if tekstura_OF.lower() in node_of.image.name.lower() and any(name.lower() in node_of.image.name.lower() for name in Nazwy_front):
                                                                        opacity_f = node_of
                                                                        front_opacity = True
                                                        for node_ob in nodetree.nodes:
                                                            if node_ob.type == "TEX_IMAGE":
                                                                for tekstura_OB in Opacity:
                                                                    if tekstura_OB.lower() in node_ob.image.name.lower() and any(name.lower() in node_ob.image.name.lower() for name in Nazwy_Back):
                                                                        opacity_b = node_nb
                                                                        back_opacity = True
                                                        if front_opacity and back_opacity:
                                                            Two_sided_opacity = False
                                                            for node_sided_opacity in nodetree.nodes:
                                                                if "MixOpacityCycles" in node_sided_opacity.label:
                                                                    mix_opacity = node_sided_opacity
                                                                    Two_sided_opacity = True
                                                                    break
                                                            if not Two_sided_normal:
                                                                mix_opacity = nodetree.nodes.new("ShaderNodeMixRGB")
                                                                mix_opacity.label = "MixOpacityCycles"
                                                                mix_opacity.location = 6, -126
                                                                Two_sided_opacity = True
                                                            if Two_sided_opacity:
                                                                nodetree.links.new(opacity_f.outputs[0], mix_opacity.inputs[1])
                                                                nodetree.links.new(opacity_b.outputs[0], mix_opacity.inputs[2])
                                                                nodetree.links.new(two_sided_geo.outputs[6], mix_opacity.inputs[0])
                                                                nodetree.links.new(mix_opacity.outputs[0], group_node.inputs[5])
                                                for tekstura_d in Displacement:
                                                    if tekstura_d.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[6])
                                                        front_disp = False
                                                        back_disp = False
                                                        for node_df in nodetree.nodes:
                                                            if node_df.type == "TEX_IMAGE":
                                                                for tekstura_DF in Displacement:
                                                                    if tekstura_DF.lower() in node_df.image.name.lower() and any(name.lower() in node_df.image.name.lower() for name in Nazwy_front):
                                                                        disp_f = node_df
                                                                        front_disp = True
                                                        for node_db in nodetree.nodes:
                                                            if node_db.type == "TEX_IMAGE":
                                                                for tekstura_DB in Displacement:
                                                                    if tekstura_DB.lower() in node_db.image.name.lower() and any(name.lower() in node_db.image.name.lower() for name in Nazwy_Back):
                                                                        disp_b = node_db
                                                                        back_disp = True
                                                        if front_disp and back_disp:
                                                            Two_sided_disp = False
                                                            for node_sided_disp in nodetree.nodes:
                                                                if "MixDispCycles" in node_sided_disp.label:
                                                                    mix_disp = node_sided_disp
                                                                    Two_sided_disp = True
                                                                    break
                                                            if not Two_sided_disp:
                                                                mix_disp = nodetree.nodes.new("ShaderNodeMixRGB")
                                                                mix_disp.label = "MixDispCycles"
                                                                mix_disp.location = 6, -390
                                                                Two_sided_disp = True
                                                            nodetree.links.new(disp_f.outputs[0], mix_disp.inputs[1])
                                                            nodetree.links.new(disp_b.outputs[0], mix_disp.inputs[2])
                                                            nodetree.links.new(two_sided_geo.outputs[6], mix_disp.inputs[0])
                                                            nodetree.links.new(mix_disp.outputs[0], group_node.inputs[6])    
                                    else:
                                        for node_2s in nodetree.nodes:
                                            if node_2s.type == "TEX_IMAGE":
                                                for tekstura in Albedo:
                                                    if tekstura.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[0])
                                                for tekstura_t in Trans:
                                                    if tekstura_t.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[1])
                                                for tekstura_r in Reflection:
                                                    if tekstura_r.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[2])
                                                for tekstura_g in RGH:
                                                    if tekstura_g.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[3])
                                                        group_node.inputs[12].default_value = 0.0  
                                                        if "gloss" in node_2s.image.name.lower():
                                                            group_node.inputs[12].default_value = 1.0 
                                                for tekstura_b in Bumps_maps:
                                                    if tekstura_b.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[4])
                                                        group_node.inputs[16].default_value = 1.0 
                                                for tekstura_n in Normal_names:
                                                    if tekstura_n.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[4])
                                                        group_node.inputs[16].default_value = 0.0    
                                                for tekstura_o in Opacity:
                                                    if tekstura_o.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[5]) 
                                                for tekstura_d in Displacement:
                                                    if tekstura_d.lower() in node_2s.image.name.lower():
                                                        nodetree.links.new(node_2s.outputs[0], group_node.inputs[6])  
        import os
        # Otwórz plik Blend
        blend_file = bpy.data.filepath
        # Rozpakuj tekstury
        bpy.ops.file.unpack_all(method='USE_LOCAL')
        # Ustaw względną ścieżkę do folderu "maps"
        dirname = os.path.dirname(blend_file)
        maps_folder = os.path.join(dirname, 'maps')
        # Zmień nazwę folderu na "maps"
        os.rename(os.path.join(dirname, 'textures'), maps_folder)
        # Znajdź brakujące pliki w katalogu "maps"
        bpy.ops.file.find_missing_files(directory=maps_folder)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Cg_Mood_D29Ff(bpy.types.Operator):
    bl_idname = "sna.cg_mood_d29ff"
    bl_label = "CG_Mood"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import os
        # Ścieżka do folderu z teksturami
        #texture_folder = r"C:\Users\adam\Downloads\set-of-european-fan-palm-treeschamaerops-humilis-cgmood\maps"
        #print("Test nowy")
        texture_folder = os.path.join(bpy.path.abspath("//"), "textures")
        #print(moje_tekstury)
        # Funkcja do tworzenia węzłów Shader Node Texture Image i przesuwania ich

        def create_texture_nodes(material, texture_name, offset):
            node_tree = material.node_tree
            # Dodaj węzeł ShaderNodeTexImage
            texture_node = node_tree.nodes.new(type='ShaderNodeTexImage')
            texture_node.location = (-200, -offset)  # Pozycja węzła na schemacie węzłów
            # Ustaw teksturę w węźle
            texture_path = os.path.join(texture_folder, texture_name)
            if os.path.isfile(texture_path):
                texture_node.image = bpy.data.images.load(texture_path)
        # Przechodzenie przez wszystkie materiały w scenie
        for material in bpy.data.materials:
            if material.use_nodes and material.name != "Dots Stroke":
                name_parts = material.name.split("_")
                print(name_parts)
                if len(name_parts) >= 2:
                    texture_prefix = name_parts[0] + "_" + name_parts[1]
                    print(f"Material: {material.name}, Prefix: {texture_prefix}")
                    offset = 0  # Początkowy offset
                    added_textures = set()  # Zbiór do śledzenia już dodanych tekstur
                    first_texture = True  # Flaga do oznaczenia pierwszej znalezionej tekstury w materiale
                    for file in os.listdir(texture_folder):
                        if file.startswith(texture_prefix):
                            texture_name = file  # Ustawić pełną nazwę pliku tekstury
                            if first_texture:
                                # Dodaj sufix "albedo" przed kropką w nazwie każdej pierwszej tekstury w węźle
                                for node in material.node_tree.nodes:
                                    if node.type == 'TEX_IMAGE':
                                        image = node.image
                                        if '.' in image.name:
                                            name_parts = image.name.split('.')
                                            image.name = name_parts[0] + "_albedo." + name_parts[1]
                                        else:
                                            image.name = image.name + "_albedo"
                                        first_texture = False  # Ustawić flagę na False po pierwszej znalezionej teksturze
                                        break  # Przerwij pętlę po dodaniu sufixu
                            if texture_name not in added_textures:
                                create_texture_nodes(material, texture_name, offset)
                                offset += 400  # Zwiększ offset dla następnej tekstury
                                added_textures.add(texture_name)  # Dodaj teksturę do zbioru już dodanych
                                print(f"Texture: {texture_name}")  # Drukuj nazwę tekstury
                else:
                    print(f"Material: {material.name} - Niepoprawna nazwa materiału, brak wymaganej liczby podkreślników")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Albedo_00307(bpy.types.Operator):
    bl_idname = "sna.albedo_00307"
    bl_label = "Albedo"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # Przechodzenie przez wszystkie materiały w scenie
        for material in bpy.data.materials:
            if material.use_nodes and material.name != "Dots Stroke":
                first_texture = True  # Flaga do oznaczenia pierwszej znalezionej tekstury w materiale
                for node in material.node_tree.nodes:
                    if node.type == 'TEX_IMAGE' and node.name == "Image Texture":
                        image = node.image
                        if first_texture:
                            if '.' in image.name:
                                name_parts = image.name.split('.')
                                if "_albedo" not in name_parts[0]:
                                    image.name = name_parts[0] + "_albedo." + ".".join(name_parts[1:])
                            else:
                                if "_albedo" not in image.name:
                                    image.name = image.name + "_albedo"
                            first_texture = False  # Ustawić flagę na False po pierwszej znalezionej teksturze
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Delet_Dupli_Da0Af(bpy.types.Operator):
    bl_idname = "sna.delet_dupli_da0af"
    bl_label = "Delet_Dupli"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # Przygotuj słownik do mapowania starych nazw materiałów na nowe
        material_mapping = {}
        # Iteruj przez wszystkie materiały w scenie
        for material in bpy.data.materials:
            old_material_name = material.name
            new_material_name = old_material_name.split(".")[0]  # Usuń sufiks
            material_mapping[old_material_name] = new_material_name
        # Iteruj przez wszystkie obiekty w scenie
        for obj in bpy.context.scene.objects:
            if obj.type == 'MESH':
                # Iteruj przez sloty materiałów w obiekcie
                for material_slot in obj.material_slots:
                    material_slot.material = bpy.data.materials[material_mapping[material_slot.material.name]]
        # Usuń niepotrzebne materiały
        for old_material_name in material_mapping.keys():
            if old_material_name != material_mapping[old_material_name]:
                bpy.data.materials.remove(bpy.data.materials[old_material_name])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Gamma_3Ea7B(bpy.types.Operator):
    bl_idname = "sna.gamma_3ea7b"
    bl_label = "Gamma"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        slownik_Color = {"gloss", "normal", "roughness", "Specu", "bump", "Displacement", "Ior", "Opaci"}  # Poprawiłem na zbiór
        # Przechodzenie przez wszystkie materiały w scenie
        for material in bpy.data.materials:
            if material.use_nodes and material.name != "Dots Stroke":
                for node in material.node_tree.nodes:
                    if node.type == 'TEX_IMAGE':
                        image = node.image
                        for keyword in slownik_Color:
                            if keyword.lower() in image.name.lower():
                                image.colorspace_settings.name = "Non-Color"
                #for node_oct in material.node_tree.nodes:
                    if node.bl_idname == "OctaneRGBImage":
                        Octane_image = node
                        set_non_color = True
                        for keyword in slownik_Color:
                            if keyword.lower() in Octane_image.last_image_name.lower():
                               Octane_image.inputs[2].default_value = 1
                               set_non_color = False
                            if set_non_color:
                               Octane_image.inputs[2].default_value = 2.2
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_ADVANCED_CONVERTER_32050(bpy.types.Panel):
    bl_label = 'Advanced_Converter'
    bl_idname = 'SNA_PT_ADVANCED_CONVERTER_32050'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'MojKonwerter'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_47452 = layout.box()
        box_47452.alert = True
        box_47452.enabled = True
        box_47452.active = True
        box_47452.use_property_split = False
        box_47452.use_property_decorate = False
        box_47452.alignment = 'Expand'.upper()
        box_47452.scale_x = 1.0
        box_47452.scale_y = 1.0
        if not True: box_47452.operator_context = "EXEC_DEFAULT"
        op = box_47452.operator('sna.cycles_import_7fcb0', text='Textures import ', icon_value=165, emboss=True, depress=False)
        op = box_47452.operator('sna.operator001_9eadc', text='Cycles Materials Creation ', icon_value=165, emboss=True, depress=False)
        split_54704 = box_47452.split(factor=0.5, align=False)
        split_54704.alert = False
        split_54704.enabled = True
        split_54704.active = True
        split_54704.use_property_split = False
        split_54704.use_property_decorate = False
        split_54704.scale_x = 1.0
        split_54704.scale_y = 2.0
        split_54704.alignment = 'Expand'.upper()
        if not True: split_54704.operator_context = "EXEC_DEFAULT"
        op = split_54704.operator('sna.cycles_basic_2c7a2', text='Base shader', icon_value=165, emboss=True, depress=False)
        op = split_54704.operator('sna.metal_cycles_10800', text='Metal Shader', icon_value=165, emboss=True, depress=False)
        split_8AEBB = box_47452.split(factor=0.5, align=False)
        split_8AEBB.alert = False
        split_8AEBB.enabled = True
        split_8AEBB.active = True
        split_8AEBB.use_property_split = False
        split_8AEBB.use_property_decorate = False
        split_8AEBB.scale_x = 1.0
        split_8AEBB.scale_y = 2.0
        split_8AEBB.alignment = 'Expand'.upper()
        if not True: split_8AEBB.operator_context = "EXEC_DEFAULT"
        op = split_8AEBB.operator('sna.cycles_glass_9fedc', text='Glass Shader', icon_value=165, emboss=True, depress=False)
        op = split_8AEBB.operator('sna.cycles_trans_c703b', text='Transmission Shader', icon_value=165, emboss=True, depress=False)
        split_89D5F = box_47452.split(factor=0.5, align=False)
        split_89D5F.alert = False
        split_89D5F.enabled = True
        split_89D5F.active = True
        split_89D5F.use_property_split = False
        split_89D5F.use_property_decorate = False
        split_89D5F.scale_x = 1.0
        split_89D5F.scale_y = 2.0
        split_89D5F.alignment = 'Expand'.upper()
        if not True: split_89D5F.operator_context = "EXEC_DEFAULT"
        op = split_89D5F.operator('sn.dummy_button_operator', text='Cloth Shader', icon_value=165, emboss=True, depress=False)
        op = split_89D5F.operator('sn.dummy_button_operator', text='Emission Shader', icon_value=165, emboss=True, depress=False)
        op = box_47452.operator('sna.cycles_popup_fedda', text='Cleaning Cycles Nodes', icon_value=151, emboss=True, depress=False)
        op = box_47452.operator('sna.reset_rotacji_operator_222c2', text='Reset Rotacji modelu ', icon_value=151, emboss=True, depress=False)
        op = box_47452.operator('sna.cg_mood_d29ff', text='CG Moood Textures', icon_value=165, emboss=True, depress=False)
        op = box_47452.operator('sna.albedo_00307', text='Dodanie_Albedo_Do_Nazwy', icon_value=165, emboss=True, depress=False)
        op = box_47452.operator('sna.albedo_00307', text='Usuwanie_Duplikatow_Materialow', icon_value=165, emboss=True, depress=False)
        op = box_47452.operator('sna.gamma_3ea7b', text='Poprawa Colorspace Gamma', icon_value=165, emboss=True, depress=False)
        box_8066C = layout.box()
        box_8066C.alert = False
        box_8066C.enabled = True
        box_8066C.active = True
        box_8066C.use_property_split = False
        box_8066C.use_property_decorate = False
        box_8066C.alignment = 'Center'.upper()
        box_8066C.scale_x = 1.0
        box_8066C.scale_y = 1.0
        if not True: box_8066C.operator_context = "EXEC_DEFAULT"
        box_3D3B6 = box_8066C.box()
        box_3D3B6.alert = False
        box_3D3B6.enabled = True
        box_3D3B6.active = True
        box_3D3B6.use_property_split = True
        box_3D3B6.use_property_decorate = False
        box_3D3B6.alignment = 'Center'.upper()
        box_3D3B6.scale_x = 1.0
        box_3D3B6.scale_y = 1.0
        if not True: box_3D3B6.operator_context = "EXEC_DEFAULT"
        op = box_3D3B6.operator('sna.luxcore1_70fba', text='Luxcore Materials Creation ', icon_value=127, emboss=True, depress=False)
        op = box_3D3B6.operator('sna.luscore_textures_migrate_7abe2', text='Migrate All Textures to Luxcore', icon_value=127, emboss=True, depress=False)
        box_05167 = box_8066C.box()
        box_05167.alert = False
        box_05167.enabled = True
        box_05167.active = True
        box_05167.use_property_split = True
        box_05167.use_property_decorate = False
        box_05167.alignment = 'Center'.upper()
        box_05167.scale_x = 1.0
        box_05167.scale_y = 1.0
        if not True: box_05167.operator_context = "EXEC_DEFAULT"
        split_83212 = box_05167.split(factor=0.5, align=False)
        split_83212.alert = False
        split_83212.enabled = True
        split_83212.active = True
        split_83212.use_property_split = False
        split_83212.use_property_decorate = False
        split_83212.scale_x = 1.0
        split_83212.scale_y = 1.9900000095367432
        split_83212.alignment = 'Expand'.upper()
        if not True: split_83212.operator_context = "EXEC_DEFAULT"
        op = split_83212.operator('sna.luxcore_mapping_ad5cc', text='2d Mapping ', icon_value=455, emboss=True, depress=False)
        op = split_83212.operator('sna.luxcore_materials_0c4ac', text='Disney Materials', icon_value=127, emboss=True, depress=False)
        split_FE81B = box_05167.split(factor=0.5, align=False)
        split_FE81B.alert = False
        split_FE81B.enabled = True
        split_FE81B.active = True
        split_FE81B.use_property_split = False
        split_FE81B.use_property_decorate = False
        split_FE81B.scale_x = 1.0
        split_FE81B.scale_y = 1.9900000095367432
        split_FE81B.alignment = 'Expand'.upper()
        if not True: split_FE81B.operator_context = "EXEC_DEFAULT"
        op = split_FE81B.operator('sna.luxcore_transmission_e9cf2', text='Transmission Materials', icon_value=127, emboss=True, depress=False)
        op = split_FE81B.operator('sna.luxcore_glass_creation_12d41', text='Glass Materials', icon_value=127, emboss=True, depress=False)
        split_9076A = box_05167.split(factor=0.5, align=False)
        split_9076A.alert = False
        split_9076A.enabled = True
        split_9076A.active = True
        split_9076A.use_property_split = False
        split_9076A.use_property_decorate = False
        split_9076A.scale_x = 1.0
        split_9076A.scale_y = 1.9900000095367432
        split_9076A.alignment = 'Expand'.upper()
        if not True: split_9076A.operator_context = "EXEC_DEFAULT"
        op = split_9076A.operator('sna.luxcore_metals_creation_7d699', text='Metal Materials', icon_value=127, emboss=True, depress=False)
        op = split_9076A.operator('sna.luxcore_cloth_862c1', text='Cloth Materials', icon_value=165, emboss=True, depress=False)
        op = box_8066C.operator('sna.cleaning_luxcor_nodes_6a712', text='Cleaning Luxcore nodes', icon_value=152, emboss=True, depress=False)
        op = box_8066C.operator('sna.lux_to_cyc_8902c', text='Goes back to Cycles', icon_value=152, emboss=True, depress=False)
        box_58D59 = layout.box()
        box_58D59.alert = False
        box_58D59.enabled = True
        box_58D59.active = True
        box_58D59.use_property_split = False
        box_58D59.use_property_decorate = False
        box_58D59.alignment = 'Expand'.upper()
        box_58D59.scale_x = 1.0
        box_58D59.scale_y = 1.0
        if not True: box_58D59.operator_context = "EXEC_DEFAULT"
        box_2CC82 = box_58D59.box()
        box_2CC82.alert = False
        box_2CC82.enabled = True
        box_2CC82.active = True
        box_2CC82.use_property_split = False
        box_2CC82.use_property_decorate = False
        box_2CC82.alignment = 'Expand'.upper()
        box_2CC82.scale_x = 1.0
        box_2CC82.scale_y = 1.0
        if not True: box_2CC82.operator_context = "EXEC_DEFAULT"
        op = box_2CC82.operator('sna.octane_all_007d9', text='Octane Materials Creation ', icon_value=79, emboss=True, depress=False)
        op = box_2CC82.operator('sna.octane_textures_80ea7', text='Migrate all Cycles texture to Octane', icon_value=79, emboss=True, depress=False)
        split_3113F = box_58D59.split(factor=0.5, align=False)
        split_3113F.alert = False
        split_3113F.enabled = True
        split_3113F.active = True
        split_3113F.use_property_split = False
        split_3113F.use_property_decorate = False
        split_3113F.scale_x = 1.0
        split_3113F.scale_y = 2.0
        split_3113F.alignment = 'Expand'.upper()
        op = split_3113F.operator('sna.octane_base_7c132', text='Octane Basic', icon_value=0, emboss=True, depress=False)
        op = split_3113F.operator('sna.octane_metal_5f679', text='Octane Metal', icon_value=0, emboss=True, depress=False)
        split_B649A = box_58D59.split(factor=0.5, align=False)
        split_B649A.alert = False
        split_B649A.enabled = True
        split_B649A.active = True
        split_B649A.use_property_split = False
        split_B649A.use_property_decorate = False
        split_B649A.scale_x = 1.0
        split_B649A.scale_y = 2.0
        split_B649A.alignment = 'Expand'.upper()
        op = split_B649A.operator('sna.octane_glass_4cd6d', text='Octane Glass', icon_value=0, emboss=True, depress=False)
        op = split_B649A.operator('sna.octane_trans_84db7', text='Octane Transmission', icon_value=0, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_PT_OCTANE_MATERIAL_CONVERTER_AE697)
    bpy.utils.register_class(SNA_OT_Convert_7Ac2F)
    bpy.utils.register_class(SNA_OT_Cycles_Glass_9Fedc)
    bpy.utils.register_class(SNA_OT_Cycles_Trans_C703B)
    bpy.utils.register_class(SNA_OT_Luscore_Textures_Migrate_7Abe2)
    bpy.utils.register_class(SNA_OT_Luxcore_Transmission_E9Cf2)
    bpy.utils.register_class(SNA_OT_Luxcore_Glass_Creation_12D41)
    bpy.utils.register_class(SNA_OT_Octane_Metal_5F679)
    bpy.utils.register_class(SNA_OT_Luxcore1_70Fba)
    bpy.utils.register_class(SNA_OT_Luxcore_Metals_Creation_7D699)
    bpy.utils.register_class(SNA_OT_Octane_Trans_84Db7)
    bpy.utils.register_class(SNA_OT_Octane_Glass_4Cd6D)
    bpy.utils.register_class(SNA_OT_Octane_Textures_80Ea7)
    bpy.utils.register_class(SNA_OT_Metal_Cycles_10800)
    bpy.utils.register_class(SNA_OT_Cycles_Basic_2C7A2)
    bpy.utils.register_class(SNA_OT_Luxcore_Cloth_862C1)
    bpy.utils.register_class(SNA_OT_Luxcore_Materials_0C4Ac)
    bpy.utils.register_class(SNA_OT_Luxcore_Mapping_Ad5Cc)
    bpy.utils.register_class(SNA_OT_Octane_Base_7C132)
    bpy.utils.register_class(SNA_OT_Cycles_Popup_Fedda)
    bpy.utils.register_class(SNA_OT_Reset_Rotacji_Operator_222C2)
    bpy.utils.register_class(SNA_OT_Octane_All_007D9)
    bpy.utils.register_class(SNA_OT_Cleaning_Luxcor_Nodes_6A712)
    bpy.utils.register_class(SNA_OT_Lux_To_Cyc_8902C)
    bpy.utils.register_class(SNA_OT_Cycles_Import_7Fcb0)
    bpy.utils.register_class(SNA_OT_Operator001_9Eadc)
    bpy.utils.register_class(SNA_OT_Cg_Mood_D29Ff)
    bpy.utils.register_class(SNA_OT_Albedo_00307)
    bpy.utils.register_class(SNA_OT_Delet_Dupli_Da0Af)
    bpy.utils.register_class(SNA_OT_Gamma_3Ea7B)
    bpy.utils.register_class(SNA_PT_ADVANCED_CONVERTER_32050)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_PT_OCTANE_MATERIAL_CONVERTER_AE697)
    bpy.utils.unregister_class(SNA_OT_Convert_7Ac2F)
    bpy.utils.unregister_class(SNA_OT_Cycles_Glass_9Fedc)
    bpy.utils.unregister_class(SNA_OT_Cycles_Trans_C703B)
    bpy.utils.unregister_class(SNA_OT_Luscore_Textures_Migrate_7Abe2)
    bpy.utils.unregister_class(SNA_OT_Luxcore_Transmission_E9Cf2)
    bpy.utils.unregister_class(SNA_OT_Luxcore_Glass_Creation_12D41)
    bpy.utils.unregister_class(SNA_OT_Octane_Metal_5F679)
    bpy.utils.unregister_class(SNA_OT_Luxcore1_70Fba)
    bpy.utils.unregister_class(SNA_OT_Luxcore_Metals_Creation_7D699)
    bpy.utils.unregister_class(SNA_OT_Octane_Trans_84Db7)
    bpy.utils.unregister_class(SNA_OT_Octane_Glass_4Cd6D)
    bpy.utils.unregister_class(SNA_OT_Octane_Textures_80Ea7)
    bpy.utils.unregister_class(SNA_OT_Metal_Cycles_10800)
    bpy.utils.unregister_class(SNA_OT_Cycles_Basic_2C7A2)
    bpy.utils.unregister_class(SNA_OT_Luxcore_Cloth_862C1)
    bpy.utils.unregister_class(SNA_OT_Luxcore_Materials_0C4Ac)
    bpy.utils.unregister_class(SNA_OT_Luxcore_Mapping_Ad5Cc)
    bpy.utils.unregister_class(SNA_OT_Octane_Base_7C132)
    bpy.utils.unregister_class(SNA_OT_Cycles_Popup_Fedda)
    bpy.utils.unregister_class(SNA_OT_Reset_Rotacji_Operator_222C2)
    bpy.utils.unregister_class(SNA_OT_Octane_All_007D9)
    bpy.utils.unregister_class(SNA_OT_Cleaning_Luxcor_Nodes_6A712)
    bpy.utils.unregister_class(SNA_OT_Lux_To_Cyc_8902C)
    bpy.utils.unregister_class(SNA_OT_Cycles_Import_7Fcb0)
    bpy.utils.unregister_class(SNA_OT_Operator001_9Eadc)
    bpy.utils.unregister_class(SNA_OT_Cg_Mood_D29Ff)
    bpy.utils.unregister_class(SNA_OT_Albedo_00307)
    bpy.utils.unregister_class(SNA_OT_Delet_Dupli_Da0Af)
    bpy.utils.unregister_class(SNA_OT_Gamma_3Ea7B)
    bpy.utils.unregister_class(SNA_PT_ADVANCED_CONVERTER_32050)
